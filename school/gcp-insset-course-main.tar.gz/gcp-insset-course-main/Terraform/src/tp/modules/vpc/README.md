<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_google"></a> [google](#requirement\_google) | 4.49.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.49.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_compute_network.my_vpc](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_network) | resource |
| [google_compute_subnetwork.vpc_subnet](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_subnetwork) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_my_vpc_name"></a> [my\_vpc\_name](#input\_my\_vpc\_name) | Vnet's name | `string` | `"project-vpc"` | no |
| <a name="input_subnet_ip_range"></a> [subnet\_ip\_range](#input\_subnet\_ip\_range) | Vnet's region | `string` | n/a | yes |
| <a name="input_subnet_name"></a> [subnet\_name](#input\_subnet\_name) | Vnet's name | `string` | n/a | yes |
| <a name="input_vpc_region"></a> [vpc\_region](#input\_vpc\_region) | Vnet's region | `string` | `"europe-central2"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_vpc_id"></a> [vpc\_id](#output\_vpc\_id) | The vpc id |
| <a name="output_vpc_name"></a> [vpc\_name](#output\_vpc\_name) | The vpc name |
| <a name="output_vpc_self_link"></a> [vpc\_self\_link](#output\_vpc\_self\_link) | The vpc self link |
| <a name="output_vpc_subnet_name"></a> [vpc\_subnet\_name](#output\_vpc\_subnet\_name) | The vpc subnet name |
<!-- END_TF_DOCS -->