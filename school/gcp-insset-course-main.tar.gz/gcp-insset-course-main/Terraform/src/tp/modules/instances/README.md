<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_google"></a> [google](#requirement\_google) | 4.49.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.49.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_compute_instance.instance](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_instance) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_instance-disk-project-label"></a> [instance-disk-project-label](#input\_instance-disk-project-label) | Instance's disk label project value | `string` | n/a | yes |
| <a name="input_instance_name"></a> [instance\_name](#input\_instance\_name) | Instance's name | `string` | `"my-instance"` | no |
| <a name="input_instance_network_name"></a> [instance\_network\_name](#input\_instance\_network\_name) | Instance's vpc name | `string` | n/a | yes |
| <a name="input_instance_network_tag"></a> [instance\_network\_tag](#input\_instance\_network\_tag) | Instance's network tag | `string` | n/a | yes |
| <a name="input_instance_subnet_name"></a> [instance\_subnet\_name](#input\_instance\_subnet\_name) | Instance's vpc subnet name | `string` | n/a | yes |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | Instance's size (e2-micro or else) | `string` | `"e2-micro"` | no |
| <a name="input_ssh_key"></a> [ssh\_key](#input\_ssh\_key) | The ssh public key | `string` | `"sharonnelfride:ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILy2eKZlqwoKVi7Mh69iK551qf7NlTvltgfXLDwWAN9s"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_instance_id"></a> [instance\_id](#output\_instance\_id) | The instance id |
| <a name="output_instance_ip_address"></a> [instance\_ip\_address](#output\_instance\_ip\_address) | The instance IP address |
| <a name="output_instance_name"></a> [instance\_name](#output\_instance\_name) | The instance name |
| <a name="output_instance_network_tag"></a> [instance\_network\_tag](#output\_instance\_network\_tag) | The instance network tag |
<!-- END_TF_DOCS -->