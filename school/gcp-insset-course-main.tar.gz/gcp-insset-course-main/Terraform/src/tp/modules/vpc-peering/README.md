<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_google"></a> [google](#requirement\_google) | 4.49.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.49.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_compute_network_peering.vpc-peering](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_network_peering) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_vpc_peering_name"></a> [vpc\_peering\_name](#input\_vpc\_peering\_name) | The vcp peering name | `string` | `"project-vpc-peering"` | no |
| <a name="input_vpc_peering_network"></a> [vpc\_peering\_network](#input\_vpc\_peering\_network) | The first network for the vpc peering | `string` | n/a | yes |
| <a name="input_vpc_peering_peer_network"></a> [vpc\_peering\_peer\_network](#input\_vpc\_peering\_peer\_network) | The second network for the vpc peering | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_vpc_peering_id"></a> [vpc\_peering\_id](#output\_vpc\_peering\_id) | The vpc peering id |
| <a name="output_vpc_peering_name"></a> [vpc\_peering\_name](#output\_vpc\_peering\_name) | The vpc peering name |
| <a name="output_vpc_peering_network"></a> [vpc\_peering\_network](#output\_vpc\_peering\_network) | The vpc peering network |
| <a name="output_vpc_peering_peer_network"></a> [vpc\_peering\_peer\_network](#output\_vpc\_peering\_peer\_network) | The vpc peering peer network |
<!-- END_TF_DOCS -->