<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_google"></a> [google](#requirement\_google) | 4.49.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.49.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_sql_database.sql-db](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/sql_database) | resource |
| [google_sql_database_instance.sql-db-instance](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/sql_database_instance) | resource |
| [google_sql_user.admin-user](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/sql_user) | resource |
| [random_password.db_user_passwd](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_sql-database-instance-name"></a> [sql-database-instance-name](#input\_sql-database-instance-name) | The sql database instance name | `string` | n/a | yes |
| <a name="input_sql-database-instance-region"></a> [sql-database-instance-region](#input\_sql-database-instance-region) | The sql database instance region | `string` | `"europe-central2"` | no |
| <a name="input_sql-database-instance-settings-tier"></a> [sql-database-instance-settings-tier](#input\_sql-database-instance-settings-tier) | The sql database instance tier | `string` | `"db-custom-4-15360"` | no |
| <a name="input_sql-database-instance-version"></a> [sql-database-instance-version](#input\_sql-database-instance-version) | The sql database instance db version | `string` | `"POSTGRES_14"` | no |
| <a name="input_sql-database-name"></a> [sql-database-name](#input\_sql-database-name) | The sql database name | `string` | n/a | yes |
| <a name="input_sql-database-user-name"></a> [sql-database-user-name](#input\_sql-database-user-name) | The sql database user name | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_database-instance-id"></a> [database-instance-id](#output\_database-instance-id) | The database instance id |
| <a name="output_database-instance-name"></a> [database-instance-name](#output\_database-instance-name) | The database instance name |
| <a name="output_database-name"></a> [database-name](#output\_database-name) | The database name |
| <a name="output_database-user-id"></a> [database-user-id](#output\_database-user-id) | The database user id |
| <a name="output_database-user-name"></a> [database-user-name](#output\_database-user-name) | The database user name |
| <a name="output_database-user-password-secret"></a> [database-user-password-secret](#output\_database-user-password-secret) | The database user password |
<!-- END_TF_DOCS -->