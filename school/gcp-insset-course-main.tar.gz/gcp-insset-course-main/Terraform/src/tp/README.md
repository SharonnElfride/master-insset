<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_google"></a> [google](#requirement\_google) | 4.49.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.49.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_app1"></a> [app1](#module\_app1) | ./modules/instances | n/a |
| <a name="module_app2"></a> [app2](#module\_app2) | ./modules/instances | n/a |
| <a name="module_bastion"></a> [bastion](#module\_bastion) | ./modules/instances | n/a |
| <a name="module_cloud-sql"></a> [cloud-sql](#module\_cloud-sql) | ./modules/cloud-sql | n/a |
| <a name="module_project_vpc_a"></a> [project\_vpc\_a](#module\_project\_vpc\_a) | ./modules/vpc | n/a |
| <a name="module_project_vpc_b"></a> [project\_vpc\_b](#module\_project\_vpc\_b) | ./modules/vpc | n/a |
| <a name="module_project_vpc_peering_1"></a> [project\_vpc\_peering\_1](#module\_project\_vpc\_peering\_1) | ./modules/vpc-peering | n/a |
| <a name="module_project_vpc_peering_2"></a> [project\_vpc\_peering\_2](#module\_project\_vpc\_peering\_2) | ./modules/vpc-peering | n/a |

## Resources

| Name | Type |
|------|------|
| [google_compute_backend_service.backend-service](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_backend_service) | resource |
| [google_compute_firewall.bastion_to_app1_ssh](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_firewall) | resource |
| [google_compute_firewall.us_to_bastion_ssh](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_firewall) | resource |
| [google_compute_global_forwarding_rule.global-forwarding-rule](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_global_forwarding_rule) | resource |
| [google_compute_health_check.hc](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_health_check) | resource |
| [google_compute_instance_group.apps-group](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_instance_group) | resource |
| [google_compute_target_http_proxy.target-http-proxy](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_target_http_proxy) | resource |
| [google_compute_url_map.url-map](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/compute_url_map) | resource |
| [google_dns_managed_zone.prod](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/dns_managed_zone) | resource |
| [google_dns_record_set.app](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/dns_record_set) | resource |
| [google_secret_manager_secret.secret-basic](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/secret_manager_secret) | resource |
| [google_secret_manager_secret_iam_binding.binding](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/secret_manager_secret_iam_binding) | resource |
| [google_secret_manager_secret_version.admin-password](https://registry.terraform.io/providers/hashicorp/google/4.49.0/docs/resources/secret_manager_secret_version) | resource |

## Inputs

No inputs.

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_app1_ip_address"></a> [app1\_ip\_address](#output\_app1\_ip\_address) | The app 1 IP address |
| <a name="output_app1_name"></a> [app1\_name](#output\_app1\_name) | The app 1 name |
| <a name="output_app2_ip_address"></a> [app2\_ip\_address](#output\_app2\_ip\_address) | The app 2 IP address |
| <a name="output_app2_name"></a> [app2\_name](#output\_app2\_name) | The app 2 name |
| <a name="output_bastion_ip_address"></a> [bastion\_ip\_address](#output\_bastion\_ip\_address) | The bastion IP address |
| <a name="output_bastion_name"></a> [bastion\_name](#output\_bastion\_name) | The bastion name |
<!-- END_TF_DOCS -->