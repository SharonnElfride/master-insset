## VPC

Vpc with only public subnetworks by default <br />
Network rules <br />

For VPC, not take 192.168.X.X/X !!! <br>
So check the existing VPCs cidr first

Vpc is the base (?) of an architecture.
vpc 172.20.0.0/16 (0..65535)
