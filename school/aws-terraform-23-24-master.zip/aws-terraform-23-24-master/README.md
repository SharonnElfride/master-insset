# aws-terraform-23-24
AWS + Terraform course Master 2
