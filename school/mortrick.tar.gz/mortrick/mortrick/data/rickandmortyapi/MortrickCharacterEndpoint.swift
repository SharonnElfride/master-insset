//
//  MortrickCharacterEndpoint.swift
//  mortrick
//
//  Created by Sharonn Zounon on 31/12/2023.
//

import Foundation

class MortrickCharacterEndpoint: ObservableObject {
    // Get a single character: https://rickandmortyapi.com/api/character/2
    // Get all characters: https://rickandmortyapi.com/api/character
    // Get multiple characters: https://rickandmortyapi.com/api/character/1,183
    // Filter characters: https://rickandmortyapi.com/api/character/?name=rick&status=alive
    
    // Enter characteristics & search based on them !
    
    @Published var singleCharacter: Character = Character.example()
    @Published var characters: [Character] = []
    @Published var filterResult: [Character] = []
    
    @Published var allCharacters: Int = 0
    
    var totalCharacters = 0
    var totalPages = 0
    var page = 0
    
    init() {
        filterResult.append(Character.example())
        getAllCharactersTotal()
    }
    
    private func getAllCharactersTotal() {
        guard let url = URL(string: "\(CHARACTERS_BASE_URL)") else { fatalError("Missing URL") }
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedResults = try JSONDecoder().decode(CharacterEndpointFilterResult.self, from: data)
                        self.allCharacters = decodedResults.info.count
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    func getMultipleCharacters(ids: [Int]) {
        let chIds = ids.join(separator: ",")
        
        guard let url = URL(string: "\(CHARACTERS_BASE_URL)/\(chIds)") else { fatalError("Missing URL") }
        
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedCharacters = try JSONDecoder().decode([CharacterEndpoint].self, from: data)
                        self.characters = decodedCharacters.toCharacters()
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    func getSingleCharacter(id: Int) {
        guard let url = URL(string: "\(CHARACTERS_BASE_URL)/\(id)") else { fatalError("Missing URL") }
        
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedCharacter = try JSONDecoder().decode(CharacterEndpoint.self, from: data)
                        self.singleCharacter = decodedCharacter.toCharacter()
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    // The API will automatically paginate the responses. You will receive up to 20 documents per page.
    func filterCharacters(
        page: Int = 1,
        name: String = "",
        status: String = "",
        species: String = "",
        type: String = "",
        gender: String = ""
    ) {
        let pageFilter = "page=\((page == 0) ? 1 : page)"
        var filter: String = ((!name.isEmpty) ? "&name=\(name.lowercased())" : "") +
            ((!status.isEmpty) ? "&status=\(status.lowercased())" : "") +
            ((!species.isEmpty) ? "&species=\(species.lowercased())" : "") +
            ((!type.isEmpty) ? "&type=\(type.lowercased())" : "") +
        ((!gender.isEmpty) ? "&gender=\(gender.lowercased())" : "")
        
        filter = (filter.isEmpty) ? pageFilter : (pageFilter + filter)
        
        guard let url = URL(string: "\(CHARACTERS_BASE_URL)/?\(filter)") else { fatalError("Missing URL") }
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedResults = try JSONDecoder().decode(CharacterEndpointFilterResult.self, from: data)
                        
                        self.totalPages = decodedResults.info.pages
                        self.totalCharacters = decodedResults.info.count
                        
                        decodedResults.results.forEach { ch in
                            if(!self.filterResult.contains(where: { c in c.id == ch.id })) {
                                self.filterResult.append(ch.toCharacter())
                            }
                        }
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    func loadMoreContent(
        currentItem item: Character,
        name: String = "",
        status: String = "",
        species: String = "",
        type: String = "",
        gender: String = ""
    ){
        let thresholdIndex = self.filterResult.last?.id ?? 0
        
        if ((filterResult.count == 1 && filterResult[0].id == 0) || ((thresholdIndex == item.id) && (page + 1) <= totalPages)) {
            page += 1
            filterCharacters(
                page: page,
                name: name,
                status: status,
                species: species,
                type: type,
                gender: gender
            )
        }
        
        if(filterResult.count > 1) {
            filterResult.removeAll(where: {ch in ch.id == 0})
        }
    }
}
