//
//  MortrickLocationEndpoint.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import Foundation

class MortrickLocationEndpoint: ObservableObject {
    // Get a single location: https://rickandmortyapi.com/api/location/3
    // Get all locations: https://rickandmortyapi.com/api/location
    // Get multiple locations: https://rickandmortyapi.com/api/location/4,111
    // Filter locations: https://rickandmortyapi.com/api/location/?type=Dimension
    
    @Published var singleLocation: Location = Location.example()
    @Published var locations: [Location] = []
    @Published var filterResult: [Location] = []
    
    @Published var allLocations: Int = 0
    
    var totalLocations = 0
    var totalPages = 0
    var page = 0
    
    init() {
        filterResult.append(Location.example())
        getAllLocationsTotal()
    }
    
    private func getAllLocationsTotal() {
        guard let url = URL(string: "\(LOCATIONS_BASE_URL)") else { fatalError("Missing URL") }
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedResults = try JSONDecoder().decode(LocationEndpointFilterResult.self, from: data)
                        self.allLocations = decodedResults.info.count
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    func getMultipleLocations(ids: [Int]) {
        let locIds = ids.join(separator: ",")
        
        guard let url = URL(string: "\(LOCATIONS_BASE_URL)/\(locIds)") else { fatalError("Missing URL") }
        
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedLocations = try JSONDecoder().decode([Location].self, from: data)
                        self.locations = decodedLocations
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    func getSingleLocation(id: Int) {
        guard let url = URL(string: "\(LOCATIONS_BASE_URL)/\(id)") else { fatalError("Missing URL") }
        
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedLocation = try JSONDecoder().decode(Location.self, from: data)
                        self.singleLocation = decodedLocation
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    // The API will automatically paginate the responses. You will receive up to 20 documents per page.
    func filterLocations(
        page: Int = 1,
        name: String = "",
        type: String = "",
        dimension: String = ""
    ) {
        let pageFilter = "page=\((page == 0) ? 1 : page)"
        var filter: String = ((!name.isEmpty) ? "&name=\(name.lowercased())" : "") +
        ((!type.isEmpty) ? "&type=\(type.lowercased())" : "") +
        ((!dimension.isEmpty) ? "&dimension=\(dimension.lowercased())" : "")
        
        filter = (filter.isEmpty) ? pageFilter : (pageFilter + filter)
        
        guard let url = URL(string: "\(LOCATIONS_BASE_URL)/?\(filter)") else { fatalError("Missing URL") }
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedResults = try JSONDecoder().decode(LocationEndpointFilterResult.self, from: data)
                        
                        self.totalPages = decodedResults.info.pages
                        self.totalLocations = decodedResults.info.count
                        
                        decodedResults.results.forEach { ch in
                            if(!self.filterResult.contains(where: { c in c.id == ch.id })) {
                                self.filterResult.append(ch)
                            }
                        }
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    func loadMoreContent(
        currentItem item: Location,
        name: String = "",
        type: String = "",
        dimension: String = ""
    ){
        let thresholdIndex = self.filterResult.last?.id ?? 0
        
        if ((filterResult.count == 1 && filterResult[0].id == 0) || ((thresholdIndex == item.id) && (page + 1) <= totalPages)) {
            page += 1
            filterLocations(
                page: page,
                name: name,
                type: type,
                dimension: dimension
            )
        }
        
        if(filterResult.count > 1) {
            filterResult.removeAll(where: {ch in ch.id == 0})
        }
    }
}
