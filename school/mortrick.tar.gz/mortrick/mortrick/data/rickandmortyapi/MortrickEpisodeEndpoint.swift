//
//  EpisodeEndpoint.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import Foundation

class MortrickEpisodeEndpoint: ObservableObject {
    // Get a single episode: https://rickandmortyapi.com/api/episode/3
    // Get all episodes: https://rickandmortyapi.com/api/episode
    // Get multiple episodes: https://rickandmortyapi.com/api/episode/4,37
    // Filter episodes: https://rickandmortyapi.com/api/episode/?name=rick-counters
    
    @Published var singleEpisode: Episode = Episode.example()
    @Published var episodes: [Episode] = []
    @Published var filterResult: [Episode] = []
    
    @Published var allEpisodes: Int = 0
    
    var totalEpisodes = 0
    var totalPages = 0
    var page = 0
    
    init() {
        filterResult.append(Episode.example())
        getAllEpisodesTotal()
    }
    
    private func getAllEpisodesTotal() {
        guard let url = URL(string: "\(EPISODES_BASE_URL)") else { fatalError("Missing URL") }
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedResults = try JSONDecoder().decode(EpisodeEndpointFilterResult.self, from: data)
                        self.allEpisodes = decodedResults.info.count
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    func getMultipleEpisodes(ids: [Int]) {
        let epIds = ids.join(separator: ",")
        
        guard let url = URL(string: "\(EPISODES_BASE_URL)/\(epIds)") else { fatalError("Missing URL") }
        
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedEpisodes = try JSONDecoder().decode([Episode].self, from: data)
                        self.episodes = decodedEpisodes
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    func getSingleEpisode(id: Int) {
        guard let url = URL(string: "\(EPISODES_BASE_URL)/\(id)") else { fatalError("Missing URL") }
        
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedEpisode = try JSONDecoder().decode(Episode.self, from: data)
                        self.singleEpisode = decodedEpisode
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    // The API will automatically paginate the responses. You will receive up to 20 documents per page.
    func filterEpisodes(
        page: Int = 1,
        name: String = "",
        episodeCode: String = ""
    ) {
        let pageFilter = "page=\((page == 0) ? 1 : page)"
        var filter: String = ((!name.isEmpty) ? "&name=\(name.lowercased())" : "") +
        ((!episodeCode.isEmpty) ? "&episodeCode=\(episodeCode.lowercased())" : "")
        
        filter = (filter.isEmpty) ? pageFilter : (pageFilter + filter)
        
        guard let url = URL(string: "\(EPISODES_BASE_URL)/?\(filter)") else { fatalError("Missing URL") }
        let urlRequest = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }
            
            guard let response = response as? HTTPURLResponse else { return }
            
            if response.statusCode == 200 {
                guard let data = data else { return }
                DispatchQueue.main.async {
                    do {
                        let decodedResults = try JSONDecoder().decode(EpisodeEndpointFilterResult.self, from: data)
                        
                        self.totalPages = decodedResults.info.pages
                        self.totalEpisodes = decodedResults.info.count
                        
                        decodedResults.results.forEach { ch in
                            if(!self.filterResult.contains(where: { c in c.id == ch.id })) {
                                self.filterResult.append(ch)
                            }
                        }
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }
        
        dataTask.resume()
    }
    
    func loadMoreContent(
        currentItem item: Episode,
        name: String = "",
        episodeCode: String = ""
    ){
        let thresholdIndex = self.filterResult.last?.id ?? 0
        
        if ((filterResult.count == 1 && filterResult[0].id == 0) || ((thresholdIndex == item.id) && (page + 1) <= totalPages)) {
            page += 1
            filterEpisodes(
                page: page,
                name: name,
                episodeCode: episodeCode
            )
        }
        
        if(filterResult.count > 1) {
            filterResult.removeAll(where: {ch in ch.id == 0})
        }
    }
}


