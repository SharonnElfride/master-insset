//
//  AuthController.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import Foundation
import FirebaseAuth

class AuthController: ObservableObject {
    @Published private (set) var authState = AuthState.unauthenticated
    @Published private (set) var authUser = AuthUser.empty
    
    init() {
        Auth.auth().addStateDidChangeListener { _ , user in
            if let user {
                self.authUser = AuthUser(id: user.uid, email: user.email, username: user.displayName, imageUrl: "", phone: user.phoneNumber)
                self.authState = .authenticated
            } else {
                self.authState = .unauthenticated
            }
        }
    }
    
    func signOut() {
        do {
            try Auth.auth().signOut()
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func deleteAccount() async -> Bool {
        do {
            try await Auth.auth().currentUser?.delete()
            self.authState = .unauthenticated
            self.authUser = AuthUser.empty
            return true
        } catch {
            print(error.localizedDescription)
            self.authState = .unauthenticated
            self.authUser = AuthUser.empty
            return false
        }
    }
}
