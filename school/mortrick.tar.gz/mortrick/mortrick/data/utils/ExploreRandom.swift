//
//  ExploreRandom.swift
//  mortrick
//
//  Created by Sharonn Zounon on 07/01/2024.
//

import Foundation

func exploreRandom (
    arrayLength: Int = 5,
    maxNumber: Int
) -> [Int] {
    var finalList: [Int] = [Int]()
    
    repeat {
        let rand = Int.random(in: 1...maxNumber)
        if(!finalList.contains(where: { x in x == rand })) {
            finalList.append(rand)
        }
    } while (finalList.count < arrayLength)
    
    return finalList
}
