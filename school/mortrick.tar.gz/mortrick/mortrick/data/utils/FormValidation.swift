//
//  FormValidation.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import Foundation

fileprivate protocol FormValidation {
    var isValid: Bool { get }
    var value: String { get set }
    var error: String { get }
    var isSubmitted: Bool { get }  // Whether the user finished typing or not
    func submitted()
}

class AuthFieldClass: FormValidation, ObservableObject {
    @Published private(set) var isValid: Bool = true
    @Published var value: String = ""
    @Published private (set) var error: String = ""
    
    // fileprivate helps making sure that the value is not changed outside this file
    @Published fileprivate var isSubmitted: Bool = false
    
    init(emptyAuthErrorMessage: String, validateAuthErrorMessage: String, validateAuth: @escaping (_ auth: String) -> Bool) {
        $value.combineLatest($isSubmitted)
            .map { auth, isSubmitted in
                if(!isSubmitted) {
                    return true
                }
                
                if auth.isEmpty {
                    self.error = emptyAuthErrorMessage
                    return false
                } else if validateAuth(auth) {
                    return true
                } else {
                    self.error = validateAuthErrorMessage
                    return false
                }
                
            }.assign(to: &$isValid)
    }
    
    func submitted() {
        isSubmitted = true
    }
}

class Email: AuthFieldClass {
    init() {
        super.init(emptyAuthErrorMessage: "Empty email", validateAuthErrorMessage: "Invalid email", validateAuth: { email in
            let emailRegex = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$"
            let regex = try! NSRegularExpression(pattern: emailRegex, options: [.caseInsensitive])
            
            return regex.firstMatch(in: email, options: [], range: NSRange(location: 0, length: email.count)) != nil
        })
    }
}

class Username: AuthFieldClass {
    init() {
        super.init(emptyAuthErrorMessage: "Empty username", validateAuthErrorMessage: "Username must be at least 3 characters long.", validateAuth: { username in
            return username.count >= 3
        })
    }
}

class Password: AuthFieldClass {
    init() {
        super.init(emptyAuthErrorMessage: "Empty password", validateAuthErrorMessage: "Password must be at least 6 characters long.", validateAuth: { password in
            return password.count >= 6
        })
    }
}
