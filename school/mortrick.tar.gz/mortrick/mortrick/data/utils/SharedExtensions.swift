//
//  SharedExtensions.swift
//  mortrick
//
//  Created by Sharonn Zounon on 31/12/2023.
//

import Foundation

extension [Int] {
    func join(separator: String = "") -> String {
        return self.map { x in
            String(x)
        }.joined(separator: separator)
    }
}

extension String {
    func trim() -> String {
        return self.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
    }
}

extension String {
    func formatTextfieldValue() -> String {
        var regexMatch = /(\ )(.+)/.ignoresCase()
        return self.replacing(regexMatch, with: String(""))
    }
}

