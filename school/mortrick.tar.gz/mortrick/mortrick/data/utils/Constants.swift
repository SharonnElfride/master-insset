//
//  Constants.swift
//  mortrick
//
//  Created by Sharonn Zounon on 24/12/2023.
//

import Foundation
import SwiftUI

let ANIME_COLLECTION = "ios-mortrick-animes"
let ACCOUNT_COLLECTION = "ios-mortrick-accounts"
let NOTES_COLLECTION = "ios-mortrick-notes"
let DIARY_COLLECTION = "ios-mortrick-diary"

let CHARACTERS_COLLECTION = "ios-mortrick-characters"
let LOCATIONS_COLLECTION = "ios-mortrick-locations"
let EPISODES_COLLECTION = "ios-mortrick-episodes"

let primaryColor = Color("selfPrimaryColor")
let secondaryColor = Color("selfSecondaryColor")
let tertiaryColor = Color("tertiaryColor")
let fourthColor = Color("fourthColor")

let CHARACTERS_BASE_URL = "https://rickandmortyapi.com/api/character"
let LOCATIONS_BASE_URL = "https://rickandmortyapi.com/api/location"
let EPISODES_BASE_URL = "https://rickandmortyapi.com/api/episode"

/*
 //struct DiaryEntry{
 //    var id: String = ""
 //    var title: String = ""
 //    var imageUrl: String = ""
 //    var userId: String
 //    var favorites: Set<String> = Set<String>()
 //    var createdDate: String
 //    var updatedDate: String
 //    var deletedDate: String? = ""
 //}
 */
