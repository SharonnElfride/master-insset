//
//  AvailableEntity.swift
//  mortrick
//
//  Created by Sharonn Zounon on 07/01/2024.
//

import Foundation

enum AvailableEntity : String, CaseIterable {
    case characters = "Characters"
    case locations = "Locations"
    case episodes = "Episodes"
}
