//
//  Account.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import Foundation

struct AuthUser {
    var id: String
    var email: String? = ""
    var username: String? = ""
    var imageUrl: String? = ""
    var phone: String? = ""
    
    static var empty = AuthUser(
        id: String(),
        email: String(),
        username: String(),
        imageUrl: String(),
        phone: String()
    )
}
