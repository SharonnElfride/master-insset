//
//  Location.swift
//  mortrick
//
//  Created by Sharonn Zounon on 31/12/2023.
//

import Foundation

/* There is a total of 126 locations sorted by id. */
struct Location: Identifiable, Decodable, Hashable {
    var id: Int
    var name: String
    var type: String
    var dimension: String
    var residents: [String]  // List of character who have been last seen in the location.
    var url: String
    var created: String
    
    static func example() -> Location {
        return Location(
            id: 0,
            name: "",
            type: "",
            dimension: "lolo",
            residents: [],
            url: "",
            created: ""
        )
    }
}

struct LocationEndpointFilterResult: Decodable {
    var info: InfoEndpoint
    var results: [Location]
}
