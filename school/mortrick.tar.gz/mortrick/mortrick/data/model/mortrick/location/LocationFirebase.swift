//
//  LocationFirebase.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import Foundation

struct LocationFirebase {
    var id: Int
    var url: String
    var createdOn: String
}
