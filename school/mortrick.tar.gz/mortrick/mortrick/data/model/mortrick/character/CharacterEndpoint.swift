//
//  CharacterEndpoint.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import Foundation

struct CharacterEndpointFilterResult: Decodable {
    var info: InfoEndpoint
    var results: [CharacterEndpoint]
}

struct CharacterEndpoint: Identifiable, Decodable {
    var id: Int
    var name: String
    var status: String
    var species: String
    var type: String
    var gender: String
    
    var origin: OriginEndpoint
    var location: MtLocationEndpoint
    
    var image: String
    var episode: [String]
    var url: String
    var created: String
    
    struct OriginEndpoint: Decodable {
        var name: String
        var url: String
    }
    
    struct MtLocationEndpoint: Decodable {
        var name: String
        var url: String
    }
}

extension CharacterEndpoint {
    func toCharacter() -> Character {
        return Character(
            id: self.id,
            name: self.name,
            status: Status.getStatus(value: self.status),
            species: self.species,
            type: self.type,
            gender: Gender.getGender(value: self.gender),
            origin: Origin(name: self.origin.name, url: self.origin.url),
            lastKnownLocation: MtLocation(name: self.location.name, url: self.location.url),
            image: self.image,
            episode: self.episode,
            url: self.url,
            createdDate: self.created
        )
    }
}

extension [CharacterEndpoint] {
    func toCharacters() -> [Character] {
        return self.map { ch in
            ch.toCharacter()
        }
    }
}
