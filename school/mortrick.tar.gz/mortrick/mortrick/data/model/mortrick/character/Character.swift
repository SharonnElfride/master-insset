//
//  Character.swift
//  mortrick
//
//  Created by Sharonn Zounon on 31/12/2023.
//

import Foundation
import SwiftUI

/* There is a total of 826 characters sorted by id. */
struct Character: Identifiable, Hashable {
    static func == (lhs: Character, rhs: Character) -> Bool {
        return lhs.id == rhs.id && lhs.name == rhs.name
    }
    
    var id: Int
    var name: String
    
    var status: Status
    
    var species: String
    var type: String
    
    var gender: Gender
    var origin: Origin
    var lastKnownLocation: MtLocation
    
    var image: String
    var episode: [String]
    var url: String
    var createdDate: String
    
    static func example() -> Character {
        return Character(
            id: 0,
            name: "",
            status: .UNKNOWN,
            species: "",
            type: "",
            gender: .UNKNOWN,
            origin: Origin.example(),
            lastKnownLocation: MtLocation.example(),
            image: "",
            episode: [],
            url: "",
            createdDate: ""
        )
    }
}

enum Status {
    case ALIVE
    case DEAD
    case UNKNOWN
    case NONE
    
    var title: String {
        switch self {
        case .ALIVE:
            return "Alive"
        case .DEAD:
            return "Dead"
        case .UNKNOWN:
            return "Unknown"
        case .NONE:
            return "None"
        }
    }
    
    var color: Color {
        switch self {
        case .ALIVE:
            return Color(hexStringToUIColor(hex: "#AACA14"))
        case .DEAD:
            return Color(hexStringToUIColor(hex: "#CA3414"))
        default:
            return .gray
        }
    }
    
    static func getStatus(value: String) -> Status {
        switch value.lowercased() {
        case "alive":
            return .ALIVE
        case "dead":
            return .DEAD
        default:
            return .UNKNOWN
        }
    }
}

enum Gender {
    case FEMALE
    case MALE
    case GENDERLESS
    case UNKNOWN
    case NONE
    
    var title: String {
        switch self {
        case .FEMALE:
            return "Female"
        case .MALE:
            return "Male"
        case .GENDERLESS:
            return "Genderless"
        case .UNKNOWN:
            return "Unknown"
        case .NONE:
            return "None"
        }
    }
    
    static func getGender(value: String) -> Gender {
        switch value.lowercased() {
        case "female":
            return .FEMALE
        case "male":
            return .MALE
        case "genderless":
            return .GENDERLESS
        default:
            return .UNKNOWN
        }
    }
}

struct Origin: Hashable {
    var name: String
    var url: String
    
    static func example() -> Origin {
        return Origin(name: "", url: "")
    }
}

struct MtLocation: Hashable {
    var name: String
    var url: String
    
    static func example() -> MtLocation {
        return MtLocation(name: "", url: "")
    }
}
