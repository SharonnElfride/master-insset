//
//  Episodes.swift
//  mortrick
//
//  Created by Sharonn Zounon on 31/12/2023.
//

import Foundation

/* There is a total of 51 episodes sorted by id (which is of course the order of the episodes). */
struct Episode: Identifiable, Decodable {
    var id: Int
    var name: String
    var air_date: String
    var episode: String  // The code of the episode.
    var characters: [String]
    var url: String
    var created: String
    
    static func example() -> Episode {
        return Episode(
            id: 0,
            name: "",
            air_date: "",
            episode: "",
            characters: [],
            url: "",
            created: ""
        )
    }
}

struct EpisodeEndpointFilterResult: Decodable {
    var info: InfoEndpoint
    var results: [Episode]
}
