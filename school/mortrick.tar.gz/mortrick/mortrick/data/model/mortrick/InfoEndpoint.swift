//
//  InfoEndpoint.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import Foundation

struct InfoEndpoint: Decodable {
    var count: Int
    var pages: Int
    var next: String?
    var prev: String?
}
