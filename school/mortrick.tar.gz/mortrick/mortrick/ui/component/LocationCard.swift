//
//  LocationCard.swift
//  mortrick
//
//  Created by Sharonn Zounon on 31/12/2023.
//

import SwiftUI

struct LocationCard: View {
    var location: Location
    var isFavorite: Bool = false
    var isFilterResult: Bool = false
    
    var body: some View {
        CardView(location: location, isFavorite: isFavorite, isFilterResult: isFilterResult)
    }
}

fileprivate struct CardView: View {
    var location: Location
    @State var isFavorite: Bool
    var isFilterResult: Bool
    
    let cardWidth: CGFloat = 350
    let imageWidth: CGFloat = 150
    let cardHeight: CGFloat = 250
    let imageHeight: CGFloat = 250
    let cornerRadius: CGFloat = 20
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: cornerRadius)
                .strokeBorder(Color.gray, lineWidth: 1)
                .frame(width: cardWidth, height: cardHeight)
                .background(Color.selfPrimary)
                .cornerRadius(cornerRadius)
                .shadow(radius: 5)
            
            HStack(alignment: .top, spacing: 10) {
                AsyncImage(url: URL(string: "https://cdn.pixabay.com/photo/2023/11/06/13/17/baby-8369586_1280.png")) { image in
                    image.resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: imageWidth, height: imageHeight)
                        .clipped()
                } placeholder: {
                    ModernCircularLoader(loaderImage: "pngegg")
                }
                
                VStack(alignment: .leading, spacing: 10) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(location.name.isEmpty ? "No Name" : location.name.localizedCapitalized)
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(Color.white)
                        
                        Text("\(!location.type.isEmpty ? location.type.localizedCapitalized : "No Type")")
                            .font(.system(size: 12, weight: .regular, design: .rounded))
                            .foregroundStyle(.white)
                    }
                    
                    Divider()
                        .overlay(Color.white)
                    
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Dimension")
                            .font(.system(size: 12, weight: .regular, design: .rounded))
                            .foregroundColor(.white.opacity(0.5))
                        
                        Text(location.dimension.localizedCapitalized)
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                            .foregroundColor(Color.white)
                    }
                    
                    Text(String(location.residents.count) + " last seen character(s) at this place.")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.leading)
                    
                    Text("[ ID = \(location.id) ]")
                        .font(.system(size: 11, weight: .bold, design: .rounded))
                        .foregroundColor(Color.white)
                    
                    if(!isFilterResult) {
                        Spacer()
                    }
                    
                    HStack (alignment: .center) {
                        if(!isFilterResult) {
                            Spacer()
                            
                            NavigationLink(destination: Text("Detail View")) {
                                Image(systemName: "eye")
                                    .frame(width: 10, height: 10)
                                    .foregroundColor(Color.white)
                            }
                            
                            Spacer()
                            Button (action: {
                                // set to favorite
                                isFavorite = !isFavorite
                            }) {
                                Image(systemName: isFavorite ? "heart.fill" : "heart")
                                    .frame(width: 10, height: 10)
                                    .foregroundColor(.white)
                            }
                            
                            Spacer()
                            Button (action: {
                                // delete
                            }) {
                                Image(systemName: "trash")
                                    .frame(width: 10, height: 10)
                                    .foregroundColor(Color.white)
                            }
                            
                            Spacer()
                        } else {
                            Button (action: {
                                // save
                            }) {
                                Text("Save")
                                    .font(.system(size: 15, weight: .regular, design: .rounded))
                                    .foregroundColor(.black)
                                    .frame(width: 100)
                                    .padding(.horizontal)
                                    .padding(.vertical, 5)
                                    .background(.white.opacity(0.5))
                                    .clipShape(RoundedRectangle(cornerRadius: 15))
                            }
                        }
                    }
                    .padding(.bottom)
                }
                .padding(.top)
                .padding(.horizontal,12)
                .padding(.bottom,11)
                
                Spacer()
            }
            .frame(width: cardWidth, height: cardHeight)
            .cornerRadius(cornerRadius)
            .padding(.horizontal)
        }
    }
}

#Preview {
    LocationCard(location: Location.example())
}
