//
//  Forms.swift
//  mortrick
//
//  Created by Sharonn Zounon on 07/01/2024.
//

import SwiftUI

struct FormExample: View {
    @State var notifyMeAbout: NotifyMeAboutType = .directMessages
    @State var profileImageSize: ProfileImageSize = .medium
    
    @State var playNotificationSounds: Bool = false
    @State var sendReadReceipts: Bool = false
    
    enum NotifyMeAboutType {
        case directMessages
        case mentions
        case anything
    }
    
    enum ProfileImageSize {
        case large
        case medium
        case small
    }
    
    var body: some View {
        Form {
            Section(header: Text("Notifications")) {
                Picker("Notify Me About", selection: $notifyMeAbout) {
                    Text("Direct Messages").tag(NotifyMeAboutType.directMessages)
                    Text("Mentions").tag(NotifyMeAboutType.mentions)
                    Text("Anything").tag(NotifyMeAboutType.anything)
                }
                Toggle("Play notification sounds", isOn: $playNotificationSounds)
                Toggle("Send read receipts", isOn: $sendReadReceipts)
            }
            Section(header: Text("User Profiles")) {
                Picker("Profile Image Size", selection: $profileImageSize) {
                    Text("Large").tag(ProfileImageSize.large)
                    Text("Medium").tag(ProfileImageSize.medium)
                    Text("Small").tag(ProfileImageSize.small)
                }
                Button("Clear Image Cache") {}
            }
        }
        .scrollContentBackground(.hidden)
        .background(Color.clear.edgesIgnoringSafeArea(.all))
    }
}
