//
//  ListTitle.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import SwiftUI

struct ListTitle: View {
    var title: String
//    var isEmptyList: Bool = false
    
    var body: some View {
        Text(title)
            .font(.title)
            .bold()
            .padding(.top)
    }
}

struct CustomProgressView: View {
    var color: Color = .selfPrimary
    
    var body: some View {
        ProgressView()
            .progressViewStyle(CircularProgressViewStyle(tint: color))
    }
}
