//
//  CharacterList.swift
//  mortrick
//
//  Created by Sharonn Zounon on 02/01/2024.
//

import SwiftUI

struct CharacterList: View {
    @EnvironmentObject private var chEndpoint: MortrickCharacterEndpoint
    
    // get ids saved from firebase
    var idsToSearch: [Int] = [Int](1...5)
    
    var body: some View {
        VStack(alignment: .center, spacing: 0) {
            if(chEndpoint.characters.isEmpty) {
                ListTitle(title: "All saved characters")
                
                NoData()
            } else {
                ScrollView {
                    ListTitle(title: "All saved characters")
                    
                    LazyVStack(alignment: .leading) {
                        ForEach(chEndpoint.characters) { ch in
                            CharacterCard(character: ch)
                        }
                    }
                    .padding(.top)
                    .padding(.bottom)
                }
                .padding(.bottom, 2)
            }
        }
        .onAppear {
            chEndpoint.getMultipleCharacters(ids: idsToSearch)
        }
    }
}
