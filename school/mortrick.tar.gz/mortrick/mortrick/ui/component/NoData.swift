//
//  NoData.swift
//  mortrick
//
//  Created by Sharonn Zounon on 05/01/2024.
//

import SwiftUI

struct NoData: View {
    var body: some View {
        VStack(alignment: .center) {
            Spacer()
            
            Text("No Data %")
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .frame(alignment: .center)
            
            Spacer()
        }
    }
}
