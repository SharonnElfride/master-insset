//
//  FilteredEpisodeList.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import SwiftUI

struct FilteredEpisodeList: View {
    @EnvironmentObject private var epEndpoint: MortrickEpisodeEndpoint
    
    var name: String = ""
    var episodeCode: String = ""
    
    var body: some View {
        ZStack {
            Color.aliceBlue
            
            VStack(alignment: .center) {
                Text("Episodes found (\(epEndpoint.totalEpisodes))")
                    .font(.system(size: 15, weight: .regular, design: .rounded))
                    .bold()
                    .padding(.top)
                
                if(epEndpoint.filterResult.isEmpty) {
                    NoData()
                } else {
                    ScrollView {
                        LazyVStack(alignment: .leading) {
                            ForEach(epEndpoint.filterResult) { ep in
                                EpisodeCard(
                                    episode: ep,
                                    isFilterResult: true
                                )
                                .onAppear {
                                    epEndpoint.loadMoreContent(
                                        currentItem: ep,
                                        name: name,
                                        episodeCode: episodeCode
                                    )
                                }
                            }
                        }
                        .padding(.bottom)
                    }
                    .padding(.bottom, 2)
                }
            }
            .onAppear {
                epEndpoint.filterResult = []
                epEndpoint.totalEpisodes = 0
                
                epEndpoint.filterEpisodes(
                    name: name,
                    episodeCode: episodeCode
                )
            }
        }
    }
}
