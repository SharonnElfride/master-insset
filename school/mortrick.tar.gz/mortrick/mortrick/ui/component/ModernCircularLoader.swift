//
//  ModernCircularLoader.swift
//  mortrick
//
//  Created by Sharonn Zounon on 01/01/2024.
//

import SwiftUI


struct ModernCircularLoader: View {
    @State private var trimEnd = 0.6
    @State private var animate = false
    
    var loaderImage: String
    
    var body: some View {
        ZStack {
            Image(loaderImage)
                .resizable()
                .frame(width: 70, height: 70)
                .clipShape(.circle)
            
            Circle()
                .trim(from: 0.0,to: trimEnd)
                .stroke(.selfSecondary, style: StrokeStyle(lineWidth: 7,lineCap: .round,lineJoin:.round))
                .animation(
                    Animation.easeIn(duration: 1.5)
                        .repeatForever(autoreverses: true),
                    value: trimEnd
                )
                .frame(width: 100,height: 100)
                .rotationEffect(Angle(degrees: animate ? 270 + 360 : 270))
                .animation(
                    Animation.linear(duration: 1)
                        .repeatForever(autoreverses: false),
                    value: animate
                )
                .onAppear{
                    animate = true
                    trimEnd = 0
                }
        }
    }
}

#Preview {
    ModernCircularLoader(loaderImage: "pngegg")
}
