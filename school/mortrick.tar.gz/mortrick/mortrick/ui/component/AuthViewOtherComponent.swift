//
//  AuthViewTitle.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import SwiftUI

struct AuthViewTitle: View {
    var title: String
    
    var body: some View {
        Text(title)
            .frame(maxWidth: .infinity, alignment: .leading)
            .font(.system(size: 25, weight: .bold))
            .foregroundColor(.white)
            .padding()
            .padding(.bottom, 8)
    }
}

struct AuthViewButton: View {
    @Binding var showAlert: Bool
    
    var buttonText: String
    var buttonColor: Color = secondaryColor
    var alertError: String
    var onButtonClick: () -> ()
    
    var body: some View {
        Button(action: onButtonClick) {
            HStack(alignment: .center, spacing: 5) {
                Text(buttonText)
                    .font(.system(size: 18, weight: .bold))
                    .frame(maxWidth: .infinity, minHeight: 35)
                    .background(buttonColor)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .foregroundColor(.white)
            }
            .padding(.horizontal)
        }
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Failed"),
                message: Text(alertError),
                dismissButton: .default(Text("Okay"))
            )
        }
    }
}
