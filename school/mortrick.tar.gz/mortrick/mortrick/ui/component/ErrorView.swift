//
//  Error.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import SwiftUI

struct ErrorView: View {
    var errorMessage: String
    
    var body: some View {
        VStack(alignment: .center) {
            Spacer()
            
            VStack(alignment: .center, spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .resizable()
                    .frame(width: 300, height: 300, alignment: .center)
                    .foregroundColor(.selfSecondary)
                
                Text("ERROR")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .frame(alignment: .center)
                    .padding(.all, 0)
                
                ScrollView {
                    Text(errorMessage)
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                        .frame(alignment: .center)
                        .padding()
                        .multilineTextAlignment(.center)
                }
            }
            
            Spacer()
        }
        .background(.aliceBlue)
    }
}

#Preview {
    ErrorView(errorMessage: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam lacus leo, accumsan a sapien vitae, congue varius eros. Suspendisse sed eros risus. In tincidunt tristique magna vitae scelerisque. Phasellus erat metus, vulputate maximus ultricies sit amet, cursus non enim. Duis cursus justo id ornare finibus. Curabitur molestie, dui in finibus viverra, diam augue tempus lorem, in varius lorem diam vitae neque. Sed commodo viverra feugiat.")
}
