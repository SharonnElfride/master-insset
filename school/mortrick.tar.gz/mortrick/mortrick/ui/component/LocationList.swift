//
//  LocationList.swift
//  mortrick
//
//  Created by Sharonn Zounon on 02/01/2024.
//

import SwiftUI

struct LocationList: View {
    @EnvironmentObject private var locEndpoint: MortrickLocationEndpoint
    
    // get ids saved from firebase
    var idsToSearch: [Int] = [Int](1...5)
    
    var body: some View {
        VStack(alignment: .center, spacing: 0) {
            if(locEndpoint.locations.isEmpty) {
                ListTitle(title: "All saved locations")
                
                NoData()
            } else {
                ScrollView {
                    ListTitle(title: "All saved locations")
                    
                    LazyVStack(alignment: .leading) {
                        ForEach(locEndpoint.locations) { loc in
                            LocationCard(location: loc)
                        }
                    }
                    .padding(.top)
                    .padding(.bottom)
                }
                .padding(.bottom, 2)
            }
        }
        .onAppear {
            locEndpoint.getMultipleLocations(ids: idsToSearch)
        }
    }
}
