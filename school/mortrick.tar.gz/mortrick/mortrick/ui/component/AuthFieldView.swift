//
//  AuthFieldView.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import SwiftUI

struct AuthEmailFieldView: View {
    @ObservedObject var email: Email
    
    var body: some View {
        VStack {
            HStack(alignment: .top) {
                Image(systemName: "envelope.circle")
                    .resizable()
                    .frame(width: 24, height: 24)
                    .foregroundColor(.white)
                
                TextField("Email", text: $email.value)
                    .textInputAutocapitalization(.never)
                    .foregroundColor(.white)
                    .onSubmit {
                        email.submitted()
                    }
            }
            .padding()
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(email.isValid ? .white : .red, lineWidth: 1)
            )
            .padding(.horizontal, 20)
            
            if !email.isValid {
                Text(email.error)
                    .fontWeight(.medium)
                    .foregroundColor(.red)
                    .padding(.horizontal, 20)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}

struct AuthUsernameFieldView: View {
    @ObservedObject var username: Username
    
    var body: some View {
        VStack {
            TextField("Username", text: $username.value)
                .textInputAutocapitalization(.never)
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(username.isValid ? .white : .red, lineWidth: 2)
                )
                .padding(.horizontal, 20)
                .foregroundColor(.white)
                .onSubmit {
                    username.submitted()
                }
            
            
            if !username.isValid {
                Text(username.error)
                    .fontWeight(.medium)
                    .foregroundColor(.red)
                    .padding(.horizontal, 20)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}

struct AuthPasswordFieldView: View {
    @ObservedObject var password: Password
    
    var body: some View {
        VStack {
            
            HStack(alignment: .top) {
                Image(systemName: "lock.circle")
                    .resizable()
                    .frame(width: 24, height: 24)
                    .foregroundColor(.white)
                
                SecureField("Password", text: $password.value)
                    .textInputAutocapitalization(.never)
                    .foregroundColor(.white)
                    .disableAutocorrection(true)
                    .onSubmit {
                        password.submitted()
                    }
            }
            .padding()
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(password.isValid ? .white : .red, lineWidth: 1)
            )
            .padding(.horizontal, 20)
            
            if !password.isValid {
                Text(password.error)
                    .fontWeight(.medium)
                    .foregroundColor(.red)
                    .padding(.horizontal, 20)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}
