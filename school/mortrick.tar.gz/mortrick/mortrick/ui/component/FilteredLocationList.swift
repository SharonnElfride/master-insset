//
//  FilteredLocationList.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import SwiftUI

struct FilteredLocationList: View {
    @EnvironmentObject private var locEndpoint: MortrickLocationEndpoint
    
    var name: String = ""
    var type: String = ""
    var dimension: String = ""
    
    var body: some View {
        ZStack {
            Color.aliceBlue
            
            VStack(alignment: .center) {
                Text("Locations found (\(locEndpoint.totalLocations))")
                    .font(.system(size: 15, weight: .regular, design: .rounded))
                    .bold()
                    .padding(.top)
                
                if(locEndpoint.filterResult.isEmpty) {
                    NoData()
                } else {
                    ScrollView {
                        LazyVStack(alignment: .leading) {
                            ForEach(locEndpoint.filterResult) { loc in
                                LocationCard(
                                    location: loc,
                                    isFilterResult: true
                                )
                                .onAppear {
                                    locEndpoint.loadMoreContent(
                                        currentItem: loc,
                                        name: name,
                                        type: type,
                                        dimension: dimension
                                    )
                                }
                            }
                        }
                        .padding(.top, 2)
                        .padding(.bottom)
                    }
                    .padding(.bottom, 2)
                }
            }
            .onAppear {
                locEndpoint.filterResult = []
                locEndpoint.totalLocations = 0
                
                locEndpoint.filterLocations(
                    name: name,
                    type: type,
                    dimension: dimension
                )
            }
        }
    }
}
