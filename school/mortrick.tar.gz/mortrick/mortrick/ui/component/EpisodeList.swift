//
//  EpisodeList.swift
//  mortrick
//
//  Created by Sharonn Zounon on 02/01/2024.
//

import SwiftUI

struct EpisodeList: View {
    @EnvironmentObject private var epEndpoint: MortrickEpisodeEndpoint
    
    // get ids saved from firebase
    var idsToSearch: [Int] = [Int](1...5)
    
    var body: some View {
        VStack(alignment: .center, spacing: 0) {
            if(epEndpoint.episodes.isEmpty) {
                ListTitle(title: "All saved episodes")
                
                NoData()
            } else {
                ScrollView {
                    ListTitle(title: "All saved episodes")
                    
                    LazyVStack(alignment: .leading) {
                        ForEach(epEndpoint.episodes) { ep in
                            EpisodeCard(episode: ep)
                        }
                    }
                    .padding(.top)
                    .padding(.bottom)
                }
                .padding(.bottom, 2)
            }
        }
        .onAppear {
            epEndpoint.getMultipleEpisodes(ids: idsToSearch)
        }
    }
}
