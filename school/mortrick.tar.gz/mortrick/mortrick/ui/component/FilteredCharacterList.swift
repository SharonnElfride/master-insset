//
//  FilteredCharacterList.swift
//  mortrick
//
//  Created by Sharonn Zounon on 06/01/2024.
//

import SwiftUI

struct FilteredCharacterList: View {
    @EnvironmentObject private var chEndpoint: MortrickCharacterEndpoint
    
    var name: String = ""
    var status: String = ""
    var species: String = ""
    var type: String = ""
    var gender: String = ""
    
    var body: some View {
        ZStack {
            Color.aliceBlue
            
            VStack(alignment: .center) {
                Text("Characters found (\(chEndpoint.totalCharacters))")
                    .font(.system(size: 15, weight: .regular, design: .rounded))
                    .bold()
                    .padding(.top)
                
                if(chEndpoint.filterResult.isEmpty) {
                    NoData()
                } else {
                    ScrollView {
                        LazyVStack(alignment: .leading) {
                            ForEach(chEndpoint.filterResult) { ch in
                                CharacterCard(
                                    character: ch,
                                    isFilterResult: true
                                )
                                .onAppear {
                                    chEndpoint.loadMoreContent(
                                        currentItem: ch,
                                        name: name,
                                        status: status,
                                        species: species,
                                        type: type,
                                        gender: gender
                                    )
                                }
                            }
                        }
                        .padding(.bottom)
                    }
                    .padding(.bottom, 2)
                }
            }
            .onAppear {
                chEndpoint.filterResult = []
                chEndpoint.totalCharacters = 0
                
                chEndpoint.filterCharacters(
                    name: name,
                    status: status,
                    species: species,
                    type: type,
                    gender: gender
                )
            }
        }
    }
}
