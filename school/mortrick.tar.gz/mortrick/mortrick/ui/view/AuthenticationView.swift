//
//  AuthenticationView.swift
//  mortrick
//
//  Created by Sharonn Zounon on 30/12/2023.
//

import SwiftUI

struct AuthenticationView: View {
    @State private var isSignUp = false
    
    var accountManagement: AttributedString {
        var result = AttributedString(isSignUp ? "Already have an account?" : "Don't have an account?")
        result.font = .system(size: 15, weight: .medium, design: .rounded)
        result.foregroundColor = .white
        
        //        if let range = result.range(of: "Sign In") {
        //            result[range].foregroundColor = tertiaryColor
        //        }
        //
        //        if let range = result.range(of: "Sign Up") {
        //            result[range].foregroundColor = tertiaryColor
        //        }
        
        return result
    }
    
    var accountManagement2: AttributedString {
        var result = AttributedString(isSignUp ? "Sign In" : "Sign Up")
        result.font = .system(size: 15, weight: .medium, design: .rounded)
        result.foregroundColor = secondaryColor
        
        return result
    }
    
    var screenWidth = UIScreen.main.bounds.size.width
    
    var body: some View {
        ZStack(alignment: .center) {
            primaryColor
            
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .foregroundStyle(.linearGradient(colors: [secondaryColor], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 1000, height: 400)
                .rotationEffect(.degrees(135))
                .offset(y: -350)
            
            VStack(alignment: .center) {
                VStack(spacing: 0) {
                    Text("M⍜☈T☈!☾k")
                        .font(.system(size: 50, weight: .bold, design: .rounded))
                        .fontWeight(.heavy)
                        .padding(.top)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                    
                    Image("rick-and-morty-folder-icon-43819")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .animation(.easeIn, value: 3)
                        .frame(width: 350, height: 250, alignment: .center)
                }
                .padding(.bottom, 0)
                .padding(.top, 30)
                
                ScrollView {
                    VStack {
                        if(isSignUp) {
                            SignUpView().frame(width: screenWidth)
                        } else {
                            SignInView().frame(width: screenWidth)
                        }
                        
                        HStack(spacing: 5) {
                            Text(accountManagement)
                                .foregroundColor(.white)
                            
                            Text(accountManagement2)
                                .foregroundColor(.white)
                                .onTapGesture {
                                    isSignUp.toggle()
                                }
                        }.frame(maxWidth: .infinity)
                            .padding()
                    }
                }
            }
        }
        .ignoresSafeArea()
    }
}

#Preview {
    AuthenticationView()
}
