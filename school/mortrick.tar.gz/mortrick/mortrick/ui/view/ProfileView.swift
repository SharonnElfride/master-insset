//
//  ProfileView.swift
//  mortrick
//
//  Created by Sharonn Zounon on 07/01/2024.
//

import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var authController: AuthController
    var currentUser: AuthUser = AuthUser.empty
    
    var body: some View {
        ZStack {
            Color.aliceBlue.ignoresSafeArea()
            
            ScrollView {
                VStack(alignment: .center, spacing: 10) {
                    AsyncImage(url: URL(string: currentUser.imageUrl ?? "")) { image in
                        image.resizable()
                            .frame(width: 150, height: 150)
                            .clipped()
                            .clipShape(.circle)
                            .overlay(
                                RoundedRectangle(cornerRadius: 100)
                                    .stroke(.selfSecondary, lineWidth: 3)
                            )
                    } placeholder: {
                        Image(.rickAndMortyIcon4)
                            .resizable()
                            .frame(width: 150, height: 150)
                            .clipped()
                            .clipShape(.circle)
                            .overlay(
                                RoundedRectangle(cornerRadius: 100)
                                    .stroke(.selfSecondary, lineWidth: 3)
                            )
                    }
                    .padding(.top)
                    
                    Text(currentUser.email ?? "No Email")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                    
                    Text(currentUser.phone ?? "No Phone")
                        .font(.system(size: 15, weight: .regular, design: .rounded))
                    
                    Divider()
                        .overlay(.selfSecondary)
                    
                    VStack {
                        Spacer()
                        
                        Text("Favourites")
                        
//                        List {
//                            Text("Favourites")
//                        }
//                        .scrollContentBackground(.hidden)
//                        .background(Color.clear.edgesIgnoringSafeArea(.all))
                        
                        Spacer()
                        
                        HStack {
                            Spacer()
                            Image("pngegg-2")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .animation(.easeIn, value: 3)
                                .frame(width: 150, height: 250, alignment: .center)
                            
                            Spacer()
                            
                            VStack {
                                Text("Get out Worm !")
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                
                                Button(action: { authController.signOut() }) {
                                    Text("Sign out")
                                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                                        .frame(minWidth: 100, minHeight: 30)
                                        .background(.selfSecondary)
                                        .clipShape(RoundedRectangle(cornerRadius: 8))
                                        .foregroundColor(.black)
                                        .padding(.horizontal)
                                }
                            }
                            
                            Spacer()
                        }
                        
                        Spacer()
                    }
                    
                    Spacer()
                    
                    // Image(._7)
                    Image(._2)
                        .resizable()
                        .frame(maxWidth: nil)
                        .aspectRatio(contentMode: .fit)
                }
            }
            .padding(.top, 2)
        }
    }
}

#Preview {
    ProfileView(currentUser: AuthUser(id: "aze", email: "az@az.fr", username: "test", imageUrl: "https://lh3.googleusercontent.com/a/ACg8ocLPPBVn0SzVO8Y-QM18Jl9oph_JaalJ6xbYgk-CgwAsOQ=s96-c", phone: "+33 751014587"))
}
