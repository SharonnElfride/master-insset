//
//  ContentView.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var authController: AuthController
    @EnvironmentObject private var chEndpoint: MortrickCharacterEndpoint
    @EnvironmentObject private var locEndpoint: MortrickLocationEndpoint
    @EnvironmentObject private var epEndpoint: MortrickEpisodeEndpoint
    
    @State var selectedTab = 0
    
    var body: some View {
        ZStack(alignment: .bottom){
            TabView(selection: $selectedTab) {
                NavigationView {
                    HomeView()
                        .navigationTitle("M⍜☈T☈!☾k")
                        .navigationBarTitleDisplayMode(.large)
                }
                .navigationViewStyle(StackNavigationViewStyle())
                .tag(0)
                
                NavigationView {
                    LibraryView()
                        .navigationTitle(AvailableScreens.library.title)
                        .navigationBarTitleDisplayMode(.automatic)
                }
                .navigationViewStyle(StackNavigationViewStyle())
                .tag(1)
                
                NavigationView {
                    DiaryView()
                        .navigationTitle(AvailableScreens.diary.title)
                        .navigationBarTitleDisplayMode(.large)
                }
                .navigationViewStyle(StackNavigationViewStyle())
                .tag(2)
                
                NavigationView {
                    ProfileView(currentUser: authController.authUser)
                        .navigationTitle("\(authController.authUser.username ?? AvailableScreens.profile.title)".localizedCapitalized)
                        .navigationBarTitleDisplayMode(.large)
                }
                .navigationViewStyle(StackNavigationViewStyle())
                .tag(3)
            }
            
            ZStack {
                HStack {
                    ForEach((TabBarItems.allCases), id: \.self){ item in
                        Button{
                            selectedTab = item.rawValue
                        } label: {
                            let isActive = (selectedTab == item.rawValue)
                            let iconName = isActive ? item.activeIconName : item.iconName
                            
                            CustomTabItem(imageName: iconName, title: item.title, isActive: isActive)
                        }
                    }
                }
                .padding(6)
            }
            .frame(height: 50)
            .background(primaryColor)
        }
        .background(Color.yellow)
    }
}

extension ContentView {
    func CustomTabItem(imageName: String, title: String, isActive: Bool) -> some View{
        HStack(alignment: .center, spacing: 5){
            Spacer()
            
            Image(systemName: imageName)
                .resizable()
                .renderingMode(.template)
                .foregroundColor(isActive ? .black : .white)
                .frame(width: 20, height: 20)
            
            if isActive{
                Text(title)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundColor(isActive ? .black : .white)
            }
            
            Spacer()
        }
        .frame(width: isActive ? nil : 60, height: 40)
        .background(isActive ? Color.white.opacity(0.5) : .clear)
        .cornerRadius(30)
    }
}

struct DiaryView: View {  // Update block depending on selected date ! (date picker)
    @State private var selectedDate: Date = .now
    
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }()
    
    var body: some View {
        ZStack {
            Color.aliceBlue
            
            VStack(alignment: .leading) {
                VStack(spacing: 5) {
                    DatePicker("Select a Date",
                               selection: $selectedDate,
                               in: ...Date(),
                               displayedComponents: .date
                    )
                    .labelStyle(.titleAndIcon)
                    .datePickerStyle(.graphical)
                    .tint(.selfSecondaryColorDark)
                    .padding(.top, 0)
                    
//                    Text("Selected Date: \(selectedDate, formatter: dateFormatter)")
                    
                    Button(action: {
                        selectedDate = .now
                    }) {
                        HStack(alignment: .center, spacing: 5) {
                            Text("Today")
                                .font(.system(size: 15, weight: .bold, design: .rounded))
                                .frame(minWidth: 150, minHeight: 35)
                                .background(.selfSecondaryColorDark)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal)
                    }
                    .padding(.all, 0)
                }
                
                Divider().background(.selfSecondaryColorDark).padding()
                
                ScrollView {
                    VStack(alignment: .center) {
                        Text("Note data")
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}
