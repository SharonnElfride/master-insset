//
//  LibraryView.swift
//  mortrick
//
//  Created by Sharonn Zounon on 01/01/2024.
//

import SwiftUI

struct LibraryView: View {
    init() {
        UISegmentedControl.appearance().backgroundColor = .selfPrimary.withAlphaComponent(0.2)
        UISegmentedControl.appearance().selectedSegmentTintColor = .selfSecondary
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
        
        /*
         // Sets the background color of the Picker
         UISegmentedControl.appearance().backgroundColor = .red.withAlphaComponent(0.15)
         // Disappears the divider
         UISegmentedControl.appearance().setDividerImage(UIImage(), forLeftSegmentState: .normal, rightSegmentState: .normal, barMetrics: .default)
         // Changes the color for the selected item
         UISegmentedControl.appearance().selectedSegmentTintColor = .red
         // Changes the text color for the selected item
         UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
         */
    }
    
    @State var selectedItem = AvailableEntity.characters
    
    var body: some View {
        ZStack {
            Color.aliceBlue
            
            VStack(spacing: 2) {
                Picker("Pick a language", selection: $selectedItem) {
                    ForEach(AvailableEntity.allCases, id: \.self) { item in
                        Text(item.rawValue)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.bottom, 0)
                
                Group {
                    switch selectedItem {
                    case .locations:
                        LocationList()
                    case .episodes:
                        EpisodeList()
                    case .characters:
                        CharacterList()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.clear)
            }
        }
    }
}
