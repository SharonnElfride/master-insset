//
//  HomeView.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import SwiftUI

struct HomeView: View {
    @EnvironmentObject var authController: AuthController
    @EnvironmentObject private var chEndpoint: MortrickCharacterEndpoint
    @EnvironmentObject private var locEndpoint: MortrickLocationEndpoint
    @EnvironmentObject private var epEndpoint: MortrickEpisodeEndpoint
    
    var body: some View {
        ZStack {
            Color.aliceBlue
            
            VStack(alignment: .center, spacing: 5) {
                HStack (alignment: .center, spacing: 10) {
                    Image("pngegg-5")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .animation(.easeIn, value: 3)
                        .frame(width: 100, height: 100, alignment: .center)
                    
                    Text("Explore the Mortrickverse!")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                }
                .padding(.bottom, 0)
                
                Divider()
                    .frame(width: 5)
                    .overlay(.selfSecondary)
                
                List {
                    Section {
                        ForEach(chEndpoint.characters) { ch in
                            HStack {
                                AsyncImage(url: URL(string: ch.image)) { image in
                                    image.resizable()
                                        .frame(width: 50, height: 50)
                                        .clipped()
                                        .clipShape(.circle)
                                } placeholder: {
                                    CustomProgressView(color: .selfSecondary)
                                        .frame(width: 50, height: 50)
                                }
                                
                                Text(ch.name)
                                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                            }
                        }
                    } header: {
                        Text("Get to know more characters!")
                            .font(.system(size: 15, weight: .regular, design: .rounded))
                    } footer: {
                        NavigationLink(destination: SearchEntityView(entityType: .characters)) {
                            Text("Search characters")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .frame(maxWidth: .infinity, minHeight: 30)
                                .background(.selfSecondary)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .foregroundColor(.white)
                                .padding(.horizontal)
                        }
                    }
                    
                    Section {
                        ForEach(locEndpoint.locations) { loc in
                            HStack {
                                Image(.baby8369586640)
                                    .resizable()
                                    .frame(width: 50, height: 50)
                                    .clipped()
                                    .clipShape(.circle)
                                
                                Text(loc.name)
                                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                            }
                        }
                    } header: {
                        Text("Explore and discover various locations!")
                            .font(.system(size: 13, weight: .regular, design: .rounded))
                    } footer: {
                        NavigationLink(destination: SearchEntityView(entityType: .locations)) {
                            Text("Search locations")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .frame(maxWidth: .infinity, minHeight: 30)
                                .background(.selfSecondary)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .foregroundColor(.white)
                                .padding(.horizontal)
                        }
                    }
                    
                    Section {
                        ForEach(epEndpoint.episodes) { ep in
                            HStack {
                                Image(.camera)
                                    .resizable()
                                    .frame(width: 50, height: 50)
                                    .clipped()
                                    .clipShape(.circle)
                                
                                HStack {
                                    Text(ep.name)
                                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                                    
                                    Text("#\(ep.episode)")
                                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                                        .foregroundColor(.selfPrimary)
                                }
                                
                            }
                        }
                    } header: {
                        Text("Go through numerous episodes!")
                            .font(.system(size: 13, weight: .regular, design: .rounded))
                    } footer: {
                        NavigationLink(destination: SearchEntityView(entityType: .episodes)) {
                            Text("Search episodes")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .frame(maxWidth: .infinity, minHeight: 30)
                                .background(.selfSecondary)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .foregroundColor(.white)
                                .padding(.horizontal)
                        }
                        .padding(.bottom)
                    }
                }
                .scrollContentBackground(.hidden)
                .background(Color.clear.edgesIgnoringSafeArea(.all))
                .onAppear {
                    chEndpoint.getMultipleCharacters(ids: exploreRandom(maxNumber: (chEndpoint.allCharacters != 0 ? chEndpoint.allCharacters : 826)))
                    locEndpoint.getMultipleLocations(ids: exploreRandom(maxNumber: (locEndpoint.allLocations != 0 ? locEndpoint.allLocations : 126)))
                    epEndpoint.getMultipleEpisodes(ids: exploreRandom(maxNumber: (epEndpoint.allEpisodes != 0 ? epEndpoint.allEpisodes : 51)))
                }
            }
        }
    }
}
