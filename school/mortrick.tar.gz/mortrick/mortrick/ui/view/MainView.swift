//
//  MainView.swift
//  mortrick
//
//  Created by Sharonn Zounon on 24/12/2023.
//

import SwiftUI

struct MainView: View {
    @StateObject private var authController = AuthController()
    
    var chEndpoint = MortrickCharacterEndpoint()
    var locEndpoint = MortrickLocationEndpoint()
    var epEndpoint = MortrickEpisodeEndpoint()
    
    var body: some View {
        Group {
            if(authController.authState == .authenticated) {
                ContentView()
            } else {
                AuthenticationView()
            }
        }
        .environmentObject(authController)
        .environmentObject(chEndpoint)
        .environmentObject(locEndpoint)
        .environmentObject(epEndpoint)
    }
}

#Preview {
    MainView()
}

extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content) -> some View {
            
            ZStack(alignment: alignment) {
                placeholder().opacity(shouldShow ? 1 : 0)
                self
            }
        }
}
