//
//  SignInView.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import SwiftUI
import Combine

struct SignInView: View {    
    @StateObject private var email = Email()
    @StateObject private var password = Password()
    @StateObject private var signInViewModel = SignInViewModel()
    
    @Environment(\.dismiss) var dismiss
    
    @State private var showAlert = false
    
    private func signInWithGoogle() {
        Task {
            if await signInViewModel.signInWithGoogle() == true {
                dismiss()
            }
        }
    }
    
    var body: some View {
        VStack(alignment: .center) {
            AuthViewTitle(title: "Welcome Back")
            
            AuthEmailFieldView(email: email)
            
            AuthPasswordFieldView(password: password)
            
            AuthViewButton(
                showAlert: $showAlert,
                buttonText: signInViewModel.signInState == .submitting ? "Loading..." : "Sign in",
                buttonColor: signInViewModel.signInState == .submitting ? Color(.gray) : secondaryColor,
                alertError: signInViewModel.errorMessage,
                onButtonClick: {
                    if (signInViewModel.signInState == .initial || signInViewModel.signInState == .failed) {
                        email.submitted()
                        password.submitted()
                        
                        guard password.isValid && email.isValid else {
                            return
                        }
                        
                        Task {
                            await signInViewModel.signIn(email.value, password.value)
                            showAlert = (signInViewModel.signInState == .failed)
                        }
                    }
                }
            )
            
            HStack {
                VStack { Divider().background(.white) }
                Text("or").bold().foregroundColor(.white)
                VStack { Divider().background(.white) }
            }
            
            Button(action: signInWithGoogle) {
                HStack(spacing: 5) {
                    Image(.icons8Google24)
                        .resizable()
                        .frame(width: 40, height: 40, alignment: .leading)
                    
                    Spacer()
                    
                    Text(signInViewModel.signInState == .submitting ? "Loading..." : "Continue with Google")
                        .font(.system(size: 17, weight: .bold))
                        .foregroundColor(.white)
                    
                    Spacer()
                }
                .frame(width: 250)
                .padding()
                .background(signInViewModel.signInState == .submitting ? Color(.gray) : secondaryColor)
                .clipShape(RoundedRectangle(cornerRadius: 15))
            }
        }
    }
}

//#Preview {
//    Button(action: { }) {
//        HStack(spacing: 5) {
//            Image(.icons8Google24)
//                .resizable()
//                .frame(width: 40, height: 40, alignment: .leading)
//            
//            Spacer()
//            
//            Text("Continue with Google")
//                .font(.system(size: 15, weight: .bold))
//                .foregroundColor(.white)
//            
//            Spacer()
//        }
//        .frame(width: 250)
//        .padding()
//        .background(secondaryColor)
//        .clipShape(RoundedRectangle(cornerRadius: 15))
//    }
//}
