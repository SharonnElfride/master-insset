//
//  SearchEntityView.swift
//  mortrick
//
//  Created by Sharonn Zounon on 07/01/2024.
//

import SwiftUI

struct SearchEntityView: View {
    var entityType: AvailableEntity
    
    @State private var name = ""
    @State private var type = ""
    @State private var status: String = ""
    @State private var species: String = ""
    @State private var gender: String = ""
    @State private var dimension: String = ""
    @State private var episodeCode: String = ""
    
    @State private var state: Status = .NONE
    @State private var genderEnum: Gender = .NONE
    
    var body: some View {
        ZStack {
            Color.aliceBlue.ignoresSafeArea()
            
            VStack(alignment: .center, spacing: 10) {
                Spacer()
                
                Text("Specify the filters")
                    .font(.system(size: 16, weight: .regular, design: .rounded))
                
                Form {
                    Section {
                        TextField("max", text: $name)
                            .disableAutocorrection(true)
                            .onSubmit {
                                name = name.lowercased().formatTextfieldValue()
                            }
                    } header: {
                        Text("Name")
                    }
                    
                    switch entityType {
                        case .characters:
                            Section {
                                TextField("human", text: $species)
                                    .disableAutocorrection(true)
                                    .onSubmit {
                                        species = species.lowercased().formatTextfieldValue()
                                    }
                            } header: {
                                Text("Species")
                            }
                        
                            Section {
                                TextField("fish-person", text: $type)
                                    .disableAutocorrection(true)
                                    .onSubmit {
                                        type = type.lowercased().formatTextfieldValue()
                                    }
                            } header: {
                                Text("Type")
                            }
                            
                            Section {
                                Picker("Pick one", selection: $state) {
                                    Text(Status.ALIVE.title).tag(Status.ALIVE)
                                    Text(Status.DEAD.title).tag(Status.DEAD)
                                    Text(Status.UNKNOWN.title).tag(Status.UNKNOWN)
                                    Text(Status.NONE.title).tag(Status.NONE)
                                }
                                .onSubmit {
                                    status = (state == .NONE) ? "" : state.title.lowercased()
                                }
                            } header: {
                                Text("Status")
                            }
                            
                            Section {
                                Picker("Pick one", selection: $genderEnum) {
                                    Text(Gender.MALE.title).tag(Gender.MALE)
                                    Text(Gender.FEMALE.title).tag(Gender.FEMALE)
                                    Text(Gender.GENDERLESS.title).tag(Gender.GENDERLESS)
                                    Text(Gender.UNKNOWN.title).tag(Gender.UNKNOWN)
                                    Text(Gender.NONE.title).tag(Gender.NONE)
                                }
                                .onSubmit {
                                    gender = (genderEnum == .NONE) ? "" : genderEnum.title.lowercased()
                                }
                            } header: {
                                Text("Gender")
                            }
                        case .locations:
                            Section {
                                TextField("cluster", text: $type)
                                    .disableAutocorrection(true)
                                    .onSubmit {
                                        type = type.lowercased().formatTextfieldValue()
                                    }
                            } header: {
                                Text("Type")
                            }
                        
                            Section {
                                TextField("c-137", text: $dimension)
                                    .disableAutocorrection(true)
                                    .onSubmit {
                                        dimension = dimension.lowercased().formatTextfieldValue()
                                    }
                            } header: {
                                Text("Dimension")
                            }
                        case .episodes:
                            Section {
                                TextField("s01e02", text: $episodeCode)
                                    .disableAutocorrection(true)
                                    .onSubmit {
                                        episodeCode = episodeCode.lowercased().formatTextfieldValue()
                                    }
                            } header: {
                                Text("Episode Code")
                            }
                    }
                }
                .scrollContentBackground(.hidden)
                .background(Color.clear.edgesIgnoringSafeArea(.all))
                
                NavigationLink(
                    destination: FilteredResultView(
                        entityType: entityType,
                        name: name.lowercased().formatTextfieldValue(),
                        type: type.lowercased().formatTextfieldValue(),
                        status: (state == .NONE) ? "" : state.title.lowercased().formatTextfieldValue(),
                        species: species.lowercased().formatTextfieldValue(),
                        gender: (genderEnum == .NONE) ? "" : genderEnum.title.lowercased().formatTextfieldValue(),
                        dimension: dimension.lowercased().formatTextfieldValue(),
                        episodeCode: episodeCode.lowercased().formatTextfieldValue()
                    )
                ) {
                    Text("Search")
                        .font(.system(size: 20, weight: .semibold, design: .rounded))
                        .frame(minWidth: 200, minHeight: 50)
                        .background(.selfSecondary)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .foregroundColor(.white)
                        .padding(.horizontal)
                }
                .padding(.bottom)
                
                Spacer()
            }
        }
    }
}

fileprivate struct FilteredResultView: View {
    var entityType: AvailableEntity
    
    // Shared
    var name: String
    var type: String
    
    // Characters
    var status: String
    var species: String
    var gender: String
    
    // Locations
    var dimension: String
    
    // Episodes
    var episodeCode: String
    
    var body: some View {
        switch entityType {
        case .characters:
            FilteredCharacterList(
                name: name,
                status: status,
                species: species,
                type: type,
                gender: gender
            )
        case .locations:
            FilteredLocationList(
                name: name,
                type: type,
                dimension: dimension
            )
        case .episodes:
            FilteredEpisodeList(
                name: name,
                episodeCode: episodeCode
            )
        }
    }
}
