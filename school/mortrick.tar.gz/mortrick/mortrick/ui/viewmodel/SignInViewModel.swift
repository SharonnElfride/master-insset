//
//  SignInViewModel.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import Foundation
import FirebaseAuth
import FirebaseCore
import GoogleSignIn
import GoogleSignInSwift

@MainActor
class SignInViewModel: ObservableObject {
    @Published private (set) var signInState = SignInState.initial
    @Published private (set) var errorMessage = ""
    
    func signIn(_ email: String, _ password: String) async {
        let formattedEmail = email.lowercased()
        
        signInState = .submitting
        do {
            try await Auth.auth().signIn(withEmail: formattedEmail, password: password)
            signInState = .succeeded
        } catch {
            errorMessage = error.localizedDescription
            signInState = .failed
        }
    }
    
    func signUp(_ email: String, _ password: String) async {
        let formattedEmail = email.lowercased()
        
        signInState = .submitting
        do {
            try await Auth.auth().createUser(withEmail: formattedEmail, password: password)
            signInState = .succeeded
        } catch {
            errorMessage = error.localizedDescription
            signInState = .failed
        }
    }
    
    // signin using google
    func signInWithGoogle() async -> Bool {
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            fatalError("No clientID found in Firebase Configuration")
        }
        
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
        
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let window = windowScene.windows.first,
              let rootViewController = window.rootViewController else {
            print("There is no root view controller")
            return false
        }
        
        signInState = .submitting
        
        do {
            let userAuthentication = try await GIDSignIn.sharedInstance.signIn(withPresenting: rootViewController)
            let user = userAuthentication.user
            
            guard let idToken = user.idToken else {
                throw AuthenticationError.tokenError(message: "ID token is missing")
            }
            
            let accessToken = user.accessToken
            let credential = GoogleAuthProvider.credential(withIDToken: idToken.tokenString, accessToken: accessToken.tokenString)
            
            let result = try await Auth.auth().signIn(with: credential)
            signInState = .succeeded
            
            let firebaseUser: AuthUser = AuthUser(id: result.user.uid, email: result.user.email)
            print(firebaseUser)
            
            return true
        } catch {
            print(error.localizedDescription)
            errorMessage = error.localizedDescription
            signInState = .failed
        }
        
        return false
    }
}

enum AuthenticationError: Error {
    case tokenError(message: String)
}

