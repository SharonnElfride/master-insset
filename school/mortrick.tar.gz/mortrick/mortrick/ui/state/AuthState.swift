//
//  AuthState.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import Foundation

enum AuthState {
    case authenticated, unauthenticated
}
