//
//  SignInState.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import Foundation

enum SignInState {
    case initial, submitting, succeeded, failed
}

