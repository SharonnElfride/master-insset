//
//  AvailableScreens.swift
//  mortrick
//
//  Created by Sharonn Zounon on 30/12/2023.
//

import Foundation

enum AvailableScreens: Int, CaseIterable {
    case home = 0
    case library
    case diary
    case profile
    
    var identifier: String {
        switch self {
        case .home:
            return "home"
        case .library:
            return "library"
        case .diary:
            return "diary"
        case .profile:
            return "profile"
        }
    }
    
    var title: String {
        switch self {
        case .home:
            return "Home"
        case .library:
            return "Library"
        case .diary:
            return "Diary"
        case .profile:
            return "Profile"
        }
    }
}


