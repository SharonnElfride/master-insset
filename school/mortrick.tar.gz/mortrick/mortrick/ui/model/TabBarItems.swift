//
//  TabBarItems.swift
//  mortrick
//
//  Created by Sharonn Zounon on 25/12/2023.
//

import Foundation


enum TabBarItems: Int, CaseIterable {
    case home = 0
    case library
    case diary
    case profile
    
    var title: String{
        switch self {
        case .home:
            return "Home"
        case .library:
            return "Library"
        case .diary:
            return "Diary"
        case .profile:
            return "Profile"
        }
    }
    
    var iconName: String{
        switch self {
        case .home:
            return "house"
        case .library:
            return "books.vertical"
        case .diary:
            return "square.grid.2x2"
        case .profile:
            return "person.circle"
        }
    }
    
    var activeIconName: String{
        switch self {
        case .home:
            return "house.fill"
        case .library:
            return "books.vertical.fill"
        case .diary:
            return "square.grid.2x2.fill"
        case .profile:
            return "person.circle.fill"
        }
    }
}
