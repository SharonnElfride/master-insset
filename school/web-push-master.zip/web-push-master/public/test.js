const button = document.getElementById("myButton");
button.addEventListener("click", function (e) {
  console.log("button was clicked");
  console.log("event => " + e);

  askNotificationPermission();
});

const notifParagraph = document.getElementById("notifs");

function askNotificationPermission() {
  if (Notification?.permission === "granted") {
    // If the user agreed to get notified
    // Let's try to send ten notifications
    // let i = 0;
    // // Using an interval cause some browsers (including Firefox) are blocking notifications if there are too much in a certain time.
    // const interval = setInterval(() => {
    //   // Thanks to the tag, we should only see the "Hi! 9" notification
    //   const n = new Notification(`Hi! ${i}`, { tag: "soManyNotification" });
    //   if (i === 9) {
    //     clearInterval(interval);
    //   }
    //   i++;
    // }, 200);

    notifParagraph.innerHTML = "Permissions granted !";
    button.disabled = true;
    subscribeUserToPush();
  } else if (Notification && Notification.permission !== "denied") {
    // If the user hasn't told if they want to be notified or not
    // Note: because of Chrome, we are not sure the permission property
    // is set, therefore it's unsafe to check for the "default" value.
    Notification.requestPermission().then((status) => {
      // If the user said okay
      if (status === "granted") {
        // let i = 0;
        // // Using an interval cause some browsers (including Firefox) are blocking notifications if there are too much in a certain time.
        // const interval = setInterval(() => {
        //   // Thanks to the tag, we should only see the "Hi! 9" notification
        //   const n = new Notification(`Hi! ${i}`, {
        //     tag: "soManyNotification",
        //   });

        //   if (i === 9) {
        //     clearInterval(interval);
        //   }
        //   i++;
        // }, 200);

        notifParagraph.innerHTML = "Permissions granted !";
        button.disabled = true;
        subscribeUserToPush();
      } else {
        // Otherwise, we can fallback to a regular modal alert
        alert("Hi! not granted!");
        notifParagraph.innerHTML = "Permissions denied !";
        button.disabled = false;
      }
    });
  } else {
    // If the user refuses to get notified, we can fallback to a regular modal alert
    alert("Hi! not granted !");
    notifParagraph.innerHTML = "Permissions denied !";
    button.disabled = false;
  }
}

/* Push subscript:  
{"endpoint":
"https://updates.push.services.mozilla.com/wpush/v1/gAAAAABlCXLgo-NpFjt-fR65j8v1Nm9lQMJfaqLjMKwzPojhGteNMY5pGGws6K_ogJjH1m9KneQ10DcBxrttW_sQWQbw7amEfzojXns5DM-xicBki_3nUPmCYUNhyWFl9XrbIFICwkOy",
"expirationTime":null,"keys":{"auth":"XMUKODv_zY6TBWI1YxwwMg","p256dh":"BNWAvOaVAeX4OM3WKS6HwG49QsVdnYU7D6xdpHXNJuJBAOQU2MuxNJUY7tAMUNcr5rJPhOgVN9x0XAR0oihnxTY"}} */

function subscribeUserToPush() {
  // navigator.serviceWorker.register("service-worker.js", { scope: "./" });
  navigator.serviceWorker
    // .register("service-worker.js", { scope: "./" })
    .register("service-worker.js")
    .then(function (registration) {
      // vapId key (public key & private key)
      const subscriberOpt = {
        userVisibleOnly: true,
        applicationService: urlBase64ToUint8Array(__Application_server_key),
      };

      return registration.pushManager.subscribe(subscriberOpt);
    })
    .then(function (push) {
      console.log("Push subscript: ", JSON.stringify(push));

      sendSubToBackEnd(push);

      return push;
    })
    .catch((error) => {
      console.error("Unable to register service worker");
      console.error(error);
    });

  // navigator.serviceWorker.ready.then(console.log("Service Worker is running."));
  navigator.serviceWorker.ready.then();
}

const port = 3000;
function sendSubToBackEnd(pushSubscript) {
  //   return fetch("/api/save-endpoint/", {
  //   return fetch(`http://localhost:${port}/api/save-endpoint/`, {
  return fetch(`/api/save-endpoint/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(pushSubscript),
  })
    .then((res) => {
      if (!res.ok) {
        console.error(res);
        throw new Error(`HTTP error! Status: ${res.status}`);
      }

      console.log("res");
      console.log(res);
      return res;
    })
    .catch((error) => {
      console.error("error");
      console.error(error);
    });
}

/**
 * Conversion de la clef VAPID pour la subscription
 * @param base64String
 * @returns {Uint8Array}
 */
function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding)
    // .replace(/\-/g, "+")
    .replace(/-/g, "+")
    .replace(/_/g, "/");

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}
