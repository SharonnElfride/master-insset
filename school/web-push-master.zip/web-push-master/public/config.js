const __Application_server_key =
    "BGnEGYOre0OGfWPiE94qCd9yRUTw9UsDggPcBbc-VTq5dxCBWPPGhaDfiYq2ekWSM14TPctZAu6ZHVe9MqdBK_I";
