navigator.serviceWorker.register("service-worker.js", {scope: "./"}).then(r => {
    console.log(r)
});
navigator.serviceWorker.ready.then(res => {
    console.log("Service Worker is running.")
    console.log("res => " + res)
});
