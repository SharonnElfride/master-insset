// Import and initialize Express JS, setting it to use port **3000**.
const express = require("express");
const app = express();
const port = 3000;

const bodyParser = require("body-parser");
const webpush = require("web-push");
const vapidKeys = require("./NOTversionned/vapidKeys.js");

webpush.setVapidDetails(
  (subject = vapidKeys.subject),
  (publicKey = vapidKeys.publicKey),
  (privateKey = vapidKeys.privateKey)
);

// Set up variables for the images.
const CACHE_TIMEOUT = 10000;
const MAX_IMAGES = 10;
var imageNumber = 0;
var lastUpdate = 0;

// Serve the static files.
app.use(express.static("public"));
app.use(bodyParser.json());

// Serve an image which expires after `CACHE_TIMEOUT`.
app.get("/img", (req, res) => {
  serveImage(res, CACHE_TIMEOUT);
});

function serveImage(res, timeout) {
  var now = Date.now();

  if (now - lastUpdate > timeout) {
    imageNumber = (imageNumber + 1) % MAX_IMAGES;
    lastUpdate = Date.now();
  }

  var imageName = "cat-" + (imageNumber + 1) + ".jpg";
  res.sendFile(imageName, { root: "./imgs/" });
}

// Have Express JS begin listening for requests.
app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});

// Mine
const endPoints = [];

app.get("/favicon.ico", function (req, res) {
  res.sendFile(__dirname + "/favicon.ico");
});

app.post("/api/save-endpoint/", (req, res) => {
  // console.log("req");
  // console.log(req.body);

  endPoints.push(req.body);
  // console.log("endPoints");
  // console.log(endPoints);

  res.setHeader("Content-Type", "application/json");
  res.send(JSON.stringify({ success: true }));
});

app.get("/imgs/cat-2.jpg", function (req, res) {
  res.sendFile(__dirname + "/imgs/cat-2.jpg");
});

// require("web-push")
app.get("/send", (req, res) => {
  sendNotifisToEndpoints("Test", "It is working");

  res.setHeader("Content-Type", "application/json");
  res.send(JSON.stringify({ success: true }));
});

function sendNotifisToEndpoints(title, body) {
  let i = 0;
  endPoints.forEach((endPoint) => {
    i++;
    webpush
      .sendNotification(
        endPoint,
        JSON.stringify({ title: `${title}-${i}`, body: `${body}-${i}` })
      )
      .then((_) => {
        // .then((res) => {
        // console.log("res");
        // console.log(res);

        console.log("Notification is Sent !");
      })
      .catch((error) => {
        console.error("error");
        console.error(error);
      });
  });
}
