# Poppy
Poppy books

### Student: 
Ahouefa Sharonn ZOUNON

<small> CCM M2 2023/2024 </small>

Even if it's tiring, I'm falling in love with Android !!!

## Used APIs

- Anime/Manga/Character API: [Jikan API](https://docs.api.jikan.moe/)
- Picture API: [Nekos API](https://nekosapi.com/docs/)
    ![nekos api banner](app/src/main/res/drawable/nekosapi_repo_banner_light.jpeg)

Helpful resources

* See [https://johncodeos.com/how-to-parse-json-with-retrofit-converters-using-kotlin/](https://johncodeos.com/how-to-parse-json-with-retrofit-converters-using-kotlin/)
<!--     // Links -->
<!--     // https://developer.android.com/courses/pathways/android-basics-compose-unit-5-pathway-2#codelab-https://developer.android.com/codelabs/basic-android-kotlin-compose-add-repository -->
<!--     // https://m3.material.io/components/switch/overview -->
<!--     // gallery => https://developer.android.com/jetpack/compose/lists#lazy-staggered-grid -->

