package com.sharonn.poppy.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.sharonn.poppy.data.repository.MangaRepository
import com.sharonn.poppy.utils.REPO_ERROR_TAG
import com.sharonn.poppy.ui.model.MangaItemUI
import com.sharonn.poppy.ui.model.toUi
import com.sharonn.poppy.ui.model.toUiSingle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MangaViewModel : ViewModel() {
    private val mangaRepository: MangaRepository by lazy { MangaRepository() }

    private val auth = Firebase.auth
    private val userId = auth.currentUser?.uid ?: String()

    private val _mangas: Flow<List<MangaItemUI>>
        get() = mangaRepository.getAllMangas(userId = userId).map { list ->
            list.groupBy { character ->
                character.mangaType
            }.flatMap {
                buildList {
                    add(
                        MangaItemUI.CompleteManga(
                            header = MangaItemUI.Header(
                                mangaType = it.key
                            ),
                            items = it.value.toUi(),
                            footer = MangaItemUI.Footer(
                                addedTotal = it.value.size
                            )
                        )
                    )
                }
            }
        }

    val mangas = _mangas

    private val _favoriteMangas: Flow<List<MangaItemUI>>
        get() = mangaRepository.getFavoriteMangas(userId = userId).map { list ->
            list.groupBy { character ->
                character.mangaType
            }.flatMap {
                buildList {
                    add(
                        MangaItemUI.CompleteManga(
                            header = MangaItemUI.Header(
                                mangaType = it.key
                            ),
                            items = it.value.toUi(),
                            footer = MangaItemUI.Footer(
                                addedTotal = it.value.size
                            )
                        )
                    )
                }
            }
        }

    val favoriteMangas = _favoriteMangas

    private val _firstThreeMangas: Flow<List<MangaItemUI.Item>>
        get() = mangaRepository.getFirstThreeMangas(userId = userId).map { list ->
            list.toUi()
        }

    val firstThreeMangas = _firstThreeMangas

    fun addManga(
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                mangaRepository.addManga(userId = userId)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun getSingleManga(
        mangaId: Long,
        onError: () -> Unit
    ): MangaItemUI? {
        var manga: MangaItemUI? = null
        try {
            manga =
                mangaRepository.getSingleManga(mangaId = mangaId).toUiSingle()
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d(REPO_ERROR_TAG, e.message.toString())
            onError()
        }

        return manga
    }

    fun updateMangaIsFavorite(
        value: Boolean,
        mangaId: Long,
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                mangaRepository.updateMangaIsFavorite(
                    mangaId = mangaId,
                    value = value
                )
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun deleteSingleManga(
        mangaId: Long,
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                mangaRepository.deleteSingleManga(mangaId = mangaId)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun deleteAllMangas(
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                mangaRepository.deleteAllMangas(userId = userId)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }
}