package com.sharonn.poppy.ui.model

import androidx.compose.ui.graphics.vector.ImageVector
import com.sharonn.poppy.utils.EntityType

data class TabItem(
    val title: String,
    val entityType: EntityType,
    val unselectedIcon: ImageVector,
    val selectedIcon: ImageVector
)

