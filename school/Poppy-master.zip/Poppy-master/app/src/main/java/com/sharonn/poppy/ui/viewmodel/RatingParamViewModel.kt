package com.sharonn.poppy.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sharonn.poppy.data.model.ratingparam.RatingParam
import com.sharonn.poppy.data.repository.RatingParamRepository
import com.sharonn.poppy.utils.RatingParamType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class RatingParamViewModel(
    private var userId: String
) : ViewModel() {
    private val ratingParamRepository: RatingParamRepository by lazy { RatingParamRepository() }

    private val _userRatingParam: Flow<RatingParam>
        get() = ratingParamRepository.getUserRatingParam(userId = userId)

//    fun deleteAll() {
//        viewModelScope.launch(Dispatchers.IO) {
//            ratingParamRepository.deleteAll()
//        }
//    }

    fun deleteUserRatingParam(
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                ratingParamRepository.deleteUserRatingParam(
                    userId = userId
                )
            } catch (e: Exception) {
                e.printStackTrace()
                onError()
            }
        }
    }

    val userRatingParam = _userRatingParam

    fun updateUserRatingParam(value: Boolean, ratingParamType: RatingParamType) {
        viewModelScope.launch(Dispatchers.IO) {
            ratingParamRepository.updateUserRatingParam(
                userId = userId,
                value = value,
                ratingParamType = ratingParamType
            )
        }
    }
}
