package com.sharonn.poppy.data.model.jikanapi.character

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.sharonn.poppy.utils.DateFormat
import com.sharonn.poppy.utils.SharedFunctions.Companion.fromListToString
import com.sharonn.poppy.domain.FormatDateUseCase
import java.util.Date

data class CharacterDto(
    @Expose
    @SerializedName("data")
    val data: CharacterData,

    // All the list attributes will be converted to String using .joinToString & converted back to array using .split
)

data class CharacterData(
    @Expose
    @SerializedName("url")
    val characterUrl: String,

    @Expose
    @SerializedName("images")
    val characterImages: CharacterImages,

    @Expose
    @SerializedName("name")
    val characterName: String,

    @Expose
    @SerializedName("name_kanji")
    val characterKanjiName: String?,

    @Expose
    @SerializedName("nicknames")
    val characterNicknames: List<String>,

    @Expose
    @SerializedName("about")
    val characterAbout: String?,
)

data class CharacterImages(
    @Expose
    @SerializedName("webp")
    val webpImages: CharacterWebpImages,
)

data class CharacterWebpImages(
    @Expose
    @SerializedName("image_url")
    val imageUrl: String?,

    @Expose
    @SerializedName("small_image_url")
    val smallImageUrl: String?,
)

fun CharacterDto.toRoom(userId: String): CharacterEntity {
    val currentDateTime = Date()

    // Parsing JSON here !
    val characterUrl = data.characterUrl
    val imageUrl = data.characterImages.webpImages.imageUrl
    val smallImageUrl = data.characterImages.webpImages.smallImageUrl
    val characterName = data.characterName
    val characterKanjiName = data.characterKanjiName
    val characterNicknames = fromListToString(data.characterNicknames)
    val characterAbout = data.characterAbout
    val createdDate = FormatDateUseCase().invoke(currentDateTime, DateFormat.DATE)
    val createdTime = FormatDateUseCase().invoke(currentDateTime, DateFormat.TIME)

    return CharacterEntity(
        userId = userId,
        characterUrl = characterUrl,
        imageUrl = imageUrl,
        smallImageUrl = smallImageUrl,
        characterName = characterName,
        characterKanjiName = characterKanjiName,
        characterNicknames = characterNicknames,
        characterAbout = characterAbout,
        createdDate = createdDate,
        createdTime = createdTime
    )
}

