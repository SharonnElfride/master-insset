package com.sharonn.poppy.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sharonn.poppy.data.model.jikanapi.anime.AnimeEntity
import com.sharonn.poppy.utils.ANIME_TABLE_NAME
import kotlinx.coroutines.flow.Flow

@Dao
interface AnimeDao {
    @Query("SELECT * FROM $ANIME_TABLE_NAME WHERE userId = :userId ORDER BY type ASC")
    fun getAllAnimes(userId: String): Flow<List<AnimeEntity>>

    @Query("SELECT * FROM $ANIME_TABLE_NAME WHERE userId = :userId LIMIT 3")
    fun getFirstThreeAnimes(userId: String): Flow<List<AnimeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(anime: AnimeEntity)

    @Query("SELECT * FROM $ANIME_TABLE_NAME WHERE id = :animeId")
    fun getSingleAnime(animeId: Long): AnimeEntity

    @Query("UPDATE $ANIME_TABLE_NAME SET isFavorite = :isFavorite WHERE id = :animeId")
    fun updateAnimeIsFavorite(isFavorite: Boolean, animeId: Long): Int

    @Query("SELECT * FROM $ANIME_TABLE_NAME WHERE userId = :userId AND isFavorite = ${true} ORDER BY type ASC")
    fun getFavoriteAnimes(userId: String): Flow<List<AnimeEntity>>

    @Query("DELETE FROM $ANIME_TABLE_NAME WHERE id = :animeId")
    fun deleteSingleAnime(animeId: Long)

    @Query("DELETE FROM $ANIME_TABLE_NAME WHERE userId = :userId")
    fun deleteAll(userId: String)
}