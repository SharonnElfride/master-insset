package com.sharonn.poppy.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sharonn.poppy.data.model.ratingparam.RatingParamEntity
import com.sharonn.poppy.utils.RATING_PARAM_TABLE_NAME
import kotlinx.coroutines.flow.Flow

@Dao
interface RatingParamDao {
    @Query("SELECT * FROM $RATING_PARAM_TABLE_NAME WHERE userId = :userId")
    fun getUserRatingParam(userId: String): Flow<RatingParamEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(ratingParam: RatingParamEntity)

    @Query("SELECT EXISTS(SELECT * FROM $RATING_PARAM_TABLE_NAME WHERE userId = :userId)")
    fun isInitialized(userId: String): Boolean

    @Query("UPDATE $RATING_PARAM_TABLE_NAME SET safe = :safe WHERE userId = :userId")
    fun updateRatingSafe(safe: Boolean, userId: String): Int

    @Query("UPDATE $RATING_PARAM_TABLE_NAME SET borderline = :borderline WHERE userId = :userId")
    fun updateRatingBorderline(borderline: Boolean, userId: String): Int

    @Query("UPDATE $RATING_PARAM_TABLE_NAME SET suggestive = :suggestive WHERE userId = :userId")
    fun updateRatingSuggestive(suggestive: Boolean, userId: String): Int

    @Query("DELETE FROM $RATING_PARAM_TABLE_NAME")
    fun deleteAll()

    @Query("DELETE FROM $RATING_PARAM_TABLE_NAME WHERE userId = :userId")
    fun deleteUserRatingParam(userId: String)

    // @Update
    //void update(Order order);
    //
    //@Delete
    //void delete(Order order);
}

