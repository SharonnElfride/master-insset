package com.sharonn.poppy.utils

enum class EntityType {
    ANIME,
    MANGA,
    CHARACTER,
    NOTE,
    RATING_PARAM
}