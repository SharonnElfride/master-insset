package com.sharonn.poppy.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sharonn.poppy.R
import com.sharonn.poppy.ui.theme.dark_oncustom_color_2
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary

@Composable
fun EntityStringDataRow(
    dataTitle: String,
    data: String,
    modifier: Modifier = Modifier,
    canCopy: Boolean = false,
    context: Context? = null
) {
    Row(
        modifier = Modifier.padding(5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(
            text = dataTitle,
            textAlign = TextAlign.Center,
            style = TextStyle(
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Normal,
                color = dark_oncustom_color_2
            ),
        )

        if (data.isNotEmpty()) {
            Text(
                text = data,
                textAlign = TextAlign.Justify,
                style = TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontStyle = FontStyle.Normal,
                    color = md_theme_light_onPrimary
                ),
                modifier = modifier.weight(1f),
            )
        }

        if (canCopy) {
            val clipboardManager: androidx.compose.ui.platform.ClipboardManager = LocalClipboardManager.current
            val sourceNullMessage = stringResource(id = R.string.data_null_toast_message)

            IconButton(onClick = {
                if (data.isNotEmpty() && (data.lowercase() != "null")) {
                    clipboardManager.setText(AnnotatedString((data)))
                } else {
                    if (context != null) {
                        Toast.makeText(context, sourceNullMessage, Toast.LENGTH_SHORT)
                            .show()
                    }
                }
            }) {
                Icon(
                    modifier = Modifier.size(30.dp),
                    imageVector = Icons.Rounded.ContentCopy,
                    contentDescription = "Copy data icon",
                    tint = Color.White
                )
            }
        }
    }
}
