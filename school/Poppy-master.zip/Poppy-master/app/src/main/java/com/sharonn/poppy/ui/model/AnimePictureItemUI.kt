package com.sharonn.poppy.ui.model

import com.sharonn.poppy.data.model.nekoapi.AnimePictureObject

data class AnimePictureItemUI(
    val imageId: Long,
    val imageUrl: String,
    val imageSourceUrl: String? = null,
    val imageRating: String,
    val artistName: String,
    val createdDate: String,
    val createdTime: String
)

fun List<AnimePictureObject>.toUi(): List<AnimePictureItemUI> {
    return map { entity ->
        entity.toUiSingle()
    }
}

fun AnimePictureObject.toUiSingle(): AnimePictureItemUI {
    return AnimePictureItemUI(
        imageId = imageId,
        imageUrl = imageUrl,
        imageSourceUrl = imageSourceUrl,
        imageRating = imageRating,
        artistName = artistName,
        createdDate = createdDate,
        createdTime = createdTime
    )
}
