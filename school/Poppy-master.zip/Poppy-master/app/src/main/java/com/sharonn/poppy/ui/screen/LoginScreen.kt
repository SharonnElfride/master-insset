package com.sharonn.poppy.ui.screen

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Login
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.paint
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.LifecycleCoroutineScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sharonn.poppy.R
import com.sharonn.poppy.data.firebase.FirebaseAuthUiClient
import com.sharonn.poppy.utils.Validator
import com.sharonn.poppy.ui.components.AuthDivider
import com.sharonn.poppy.ui.components.AuthenticationButtonComponent
import com.sharonn.poppy.ui.components.EmailPasswdField
import com.sharonn.poppy.ui.components.GoogleAccessComponent
import com.sharonn.poppy.ui.components.ManageAuthScreenComponent
import com.sharonn.poppy.ui.state.SignInState
import com.sharonn.poppy.ui.viewmodel.SignInViewModel
import kotlinx.coroutines.launch


@Composable
fun LoginScreen(
    state: SignInState,
    onLetsGoButtonClick: () -> Unit,
    onSignUpButtonClick: () -> Unit,
    onLoginWithGoogleButtonClick: () -> Unit,
    firebaseAuthUiClient: FirebaseAuthUiClient,
    lifecycleScope: LifecycleCoroutineScope,
) {
    val context = LocalContext.current

    val viewModel = viewModel<SignInViewModel>()

    LaunchedEffect(key1 = state.accessAppError) {
        state.accessAppError?.let { error ->
            Toast.makeText(context, error, Toast.LENGTH_LONG).show()
        }
    }

    val successfulSignInText = stringResource(id = R.string.sign_in_caption) + " " + stringResource(
        id = R.string.successful_caption
    )

    val unsuccessfulSignInText =
        stringResource(id = R.string.sign_in_caption) + " " + stringResource(
            id = R.string.unsuccessful_caption
        )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .paint(
                painter = painterResource(id = R.drawable.login_background),
                contentScale = ContentScale.FillBounds
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val emailFieldValue = remember { mutableStateOf("") }
            val passwordFieldValue = remember { mutableStateOf("") }

            val emailError = remember { mutableStateOf(false) }
            val badPasswordError = remember { mutableStateOf(false) }

            EmailPasswdField(
                value = emailFieldValue.value,
                onValueChange = { email ->
                    emailFieldValue.value = email
                },
                label = stringResource(id = R.string.email_caption),
                placeholder = stringResource(id = R.string.email_caption),
                leadingIcon = Icons.Rounded.Email,
                isError = emailError.value,
                errorMessage = stringResource(id = R.string.email_error_message)
            )

            EmailPasswdField(
                value = passwordFieldValue.value,
                onValueChange = { passwd ->
                    passwordFieldValue.value = passwd
                },
                label = stringResource(id = R.string.password_caption),
                placeholder = stringResource(id = R.string.password_caption),
                leadingIcon = Icons.Rounded.VpnKey,
                isPassword = true,
                isError = badPasswordError.value,
                errorMessage = stringResource(id = R.string.password_error_message)
            )

            AuthenticationButtonComponent(
                imageVector = Icons.Rounded.Login,
                value = context.getString(R.string.access_app_button_text),
                onClickButton = {
                    emailError.value = !Validator.isValidEmail(emailFieldValue.value)
                    badPasswordError.value = !Validator.isValidPassword(passwordFieldValue.value)

                    if (!emailError.value && !badPasswordError.value) {
                        lifecycleScope.launch {
                            val signInResult = firebaseAuthUiClient.signInWithEmailAndPassword(
                                email = emailFieldValue.value,
                                password = passwordFieldValue.value
                            )

                            signInResult.data?.let {
                                onLetsGoButtonClick()

                                Toast.makeText(
                                    context,
                                    successfulSignInText,
                                    Toast.LENGTH_SHORT
                                ).show()

                                viewModel.resetState()
                            }

                            if (signInResult.data == null) {
                                Toast.makeText(
                                    context,
                                    unsuccessfulSignInText,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                }
            )

            ManageAuthScreenComponent(
                initialText = stringResource(id = R.string.dont_have_an_account_yet_caption),
                clickableText = stringResource(id = R.string.sign_up_caption),
                onTextClick = onSignUpButtonClick
            )

            AuthDivider()

            GoogleAccessComponent(
                context = context,
                onLoginWithGoogleButtonClick = onLoginWithGoogleButtonClick
            )
        }
    }
}
