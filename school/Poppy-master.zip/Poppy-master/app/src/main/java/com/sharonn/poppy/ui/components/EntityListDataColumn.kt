package com.sharonn.poppy.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sharonn.poppy.ui.theme.dark_oncustom_color_2
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_primary


@Composable
fun EntityListDataColumn(
    dataTitle: String,
    data: List<String>
) {
    Column(
        modifier = Modifier,
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(
            text = dataTitle,
            textAlign = TextAlign.Center,
            style = TextStyle(
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Normal,
                color = dark_oncustom_color_2
            ),
        )

        if (data.isEmpty()) {
            Spacer(modifier = Modifier.size(10.dp))
        } else {
            LazyRow(
                modifier = Modifier,
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                items(data) { item ->
                    AssistChip(
                        onClick = {},
                        label = {
                            Text(
                                text = item,
                                textAlign = TextAlign.Center,
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontStyle = FontStyle.Normal
                                ),
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Tag,
                                contentDescription = "Content description"
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            leadingIconContentColor = md_theme_light_onPrimary,
                            containerColor = md_theme_light_primary,
                            labelColor = md_theme_light_onPrimary
                        ),
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(IntrinsicSize.Min),
                        border = AssistChipDefaults.assistChipBorder(
                            borderColor = Color.White
                        )
                    )
                }
            }
        }
    }
}
