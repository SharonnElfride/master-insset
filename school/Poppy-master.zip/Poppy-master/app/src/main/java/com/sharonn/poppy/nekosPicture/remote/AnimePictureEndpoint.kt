package com.sharonn.poppy.nekosPicture.remote

import com.sharonn.poppy.data.model.nekoapi.AnimePictureDto
import retrofit2.http.GET
import retrofit2.http.Query


interface AnimePictureEndpoint {
    // Documentation: https://nekosapi.com/docs/
    // Returns an image where the age rating is in the specified list.
    // Possible values: safe, suggestive, borderline, explicit
    @GET("images/random")
    suspend fun generateRandomPicture(
        @Query("rating") categories: List<String>,
        @Query("limit") limit: Int = 1
    ): AnimePictureDto?
}
