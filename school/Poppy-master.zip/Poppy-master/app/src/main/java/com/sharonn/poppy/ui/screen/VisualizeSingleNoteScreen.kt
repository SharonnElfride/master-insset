package com.sharonn.poppy.ui.screen

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.ShortText
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sharonn.poppy.R
import com.sharonn.poppy.data.model.notes.Note
import com.sharonn.poppy.utils.DateFormat
import com.sharonn.poppy.utils.Validator
import com.sharonn.poppy.domain.FormatDateUseCase
import com.sharonn.poppy.ui.components.NoteAttributeField
import com.sharonn.poppy.ui.components.NoteEntityInformation
import com.sharonn.poppy.ui.components.cancellationToast
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.md_theme_dark_primaryContainer
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.viewmodel.NoteViewModel
import java.util.Date


@Composable
fun VisualizeSingleNoteScreen(
    context: Context,
    noteId: String? = null,
) {
    val noteViewModel: NoteViewModel = viewModel()

    val errorMessage = stringResource(id = R.string.error_retrieving_item) + " ID = $noteId"

    var note: Note? = Note()
    if (!noteId.isNullOrEmpty()) {
        noteViewModel.observeNote(
            noteId = noteId,
            onFailureAction = {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(
                        context,
                        errorMessage,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        )

        note = noteViewModel.getNote.value
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = md_theme_light_primary)
            .padding(top = 10.dp)
            .clip(shape = RoundedCornerShape(15.dp, 15.dp, 0.dp, 0.dp))
            .background(color = dark_custom_color_2)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (note != null) {
            var isEdit by remember { mutableStateOf(false) }

            val titleFieldValue = remember { mutableStateOf(note.title) }
            val contentFieldValue = remember { mutableStateOf(note.content) }

            val badTitleLengthError = remember { mutableStateOf(false) }
            val badContentLengthError = remember { mutableStateOf(false) }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 20.dp, horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                NoteAttributeField(
                    value = titleFieldValue.value,
                    onValueChange = { title ->
                        titleFieldValue.value = title
                    },
                    label = stringResource(id = R.string.title_caption),
                    placeholder = stringResource(id = R.string.title_caption),
                    leadingIcon = Icons.Rounded.Title,
                    isError = badTitleLengthError.value,
                    errorMessage = stringResource(id = R.string.note_title_error_message),
                    enabled = isEdit,
                )

                NoteEntityInformation(
                    entityId = note.entityId,
                    entityDenomination = note.entityDenomination,
                    entityType = note.entityType
                )

                NoteAttributeField(
                    value = contentFieldValue.value,
                    onValueChange = { content ->
                        contentFieldValue.value = content
                    },
                    label = stringResource(id = R.string.content_caption),
                    placeholder = stringResource(id = R.string.content_caption),
                    leadingIcon = Icons.Rounded.ShortText,
                    isError = badContentLengthError.value,
                    errorMessage = stringResource(id = R.string.note_content_error_message),
                    isContent = true,
                    enabled = isEdit,
                )

                val noChangesMade = stringResource(id = R.string.no_changes_made_error_message)
                val updateTakenIntoAccount = stringResource(id = R.string.update_taken_into_account)
                val effectiveUpdate = stringResource(id = R.string.effective_update)
                val defectiveUpdate = stringResource(id = R.string.unable_to_update_note)

                when {
                    isEdit -> {
                        Button(
                            modifier = Modifier,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = md_theme_light_primary,
                                contentColor = md_theme_light_onPrimary
                            ),
                            onClick = {
                                if (note.title.equals(
                                        titleFieldValue.value,
                                        true
                                    ) && note.content.equals(contentFieldValue.value, true)
                                ) {
                                    Toast.makeText(
                                        context,
                                        noChangesMade,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        updateTakenIntoAccount,
                                        Toast.LENGTH_SHORT
                                    ).show()

                                    badTitleLengthError.value =
                                        !Validator.isValidNoteTitle(titleFieldValue.value)
                                    badContentLengthError.value =
                                        !Validator.isValidNoteContent(contentFieldValue.value)

                                    if (!badTitleLengthError.value && !badContentLengthError.value) {
                                        val currentDateTime = Date()
                                        val currentFormattedDateTime =
                                            FormatDateUseCase().invoke(
                                                currentDateTime,
                                                DateFormat.ALL
                                            )

                                        updateNote(
                                            context = context,
                                            noteViewModel = noteViewModel,
                                            note = Note(
                                                id = note.id,
                                                userId = note.userId,
                                                title = titleFieldValue.value,
                                                content = contentFieldValue.value,
                                                entityId = note.entityId,
                                                entityDenomination = note.entityDenomination,
                                                entityType = note.entityType,
                                                imageUrl = note.imageUrl,
                                                createdOn = note.createdOn,
                                                lastUpdatedOn = currentFormattedDateTime
                                            ),
                                            effectiveUpdate = effectiveUpdate,
                                            defectiveUpdate = defectiveUpdate,
                                        )

                                        Toast.makeText(
                                            context,
                                            effectiveUpdate,
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }

                                isEdit = false
                            },
                            shape = RoundedCornerShape(25.dp)
                        ) {
                            Row(
                                modifier = Modifier.width(IntrinsicSize.Min),
                                horizontalArrangement = Arrangement.spacedBy(ButtonDefaults.IconSpacing),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Rounded.Save, contentDescription = "Content description")
                                Text(text = stringResource(id = R.string.save_button_text))
                            }
                        }
                    }

                    !isEdit -> {
                        Button(
                            modifier = Modifier,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = md_theme_light_primary,
                                contentColor = md_theme_light_onPrimary
                            ),
                            onClick = {
                                isEdit = true
                            },
                            shape = RoundedCornerShape(25.dp)
                        ) {
                            Row(
                                modifier = Modifier.width(IntrinsicSize.Min),
                                horizontalArrangement = Arrangement.spacedBy(ButtonDefaults.IconSpacing),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.EditNote,
                                    contentDescription = "Content description"
                                )
                                Text(text = stringResource(id = R.string.edit_button_text))
                            }
                        }
                    }
                }
            }
        } else {
            CircularProgressIndicator(
                progress = 0.5f,
                modifier = Modifier
                    .padding(20.dp)
                    .align(
                        Alignment.CenterHorizontally
                    ),
                color = md_theme_dark_primaryContainer
            )
        }
    }
}

fun updateNote(
    context: Context,
    noteViewModel: NoteViewModel,
    note: Note,
    effectiveUpdate: String,
    defectiveUpdate: String,
) {
    noteViewModel.updateNote(
        note = note,
        onSuccessAction = {
            Toast.makeText(
                context,
                effectiveUpdate,
                Toast.LENGTH_SHORT
            ).show()
        },
        onFailureAction = {
            Toast.makeText(
                context,
                defectiveUpdate,
                Toast.LENGTH_SHORT
            ).show()
        },
        onCanceledAction = {
            cancellationToast(
                context = context
            )
        },
    )
}
