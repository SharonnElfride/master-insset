package com.sharonn.poppy.ui.components

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sharonn.poppy.R
import com.sharonn.poppy.utils.EntityType
import com.sharonn.poppy.utils.SharedFunctions
import com.sharonn.poppy.ui.theme.md_theme_dark_primaryContainer
import com.sharonn.poppy.ui.viewmodel.AnimeViewModel
import com.sharonn.poppy.ui.viewmodel.CharacterViewModel
import com.sharonn.poppy.ui.viewmodel.MangaViewModel


@Composable
fun AddDeleteEntityComponent(
    entityType: EntityType,
    onError: () -> Unit
) {
    val animeViewModel: AnimeViewModel = viewModel()
    val mangaViewModel: MangaViewModel = viewModel()
    val characterViewModel: CharacterViewModel = viewModel()

    val context = LocalContext.current
    val openAlertDialog = remember { mutableStateOf(false) }
    val confirmationMessage = stringResource(id = R.string.confirmation_registered_caption)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        Button(
            onClick = {
                SharedFunctions.addEntity(
                    entityType = entityType,
                    animeViewModel = animeViewModel,
                    mangaViewModel = mangaViewModel,
                    characterViewModel = characterViewModel,
                    onError = onError
                )
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = md_theme_dark_primaryContainer,
                contentColor = Color.White
            )
        ) {
            Text(text = stringResource(id = R.string.tab_add_item))
        }

        when {
            openAlertDialog.value -> {
                AllItemsPermanentDeletionDialog(
                    onDismissRequest = { openAlertDialog.value = false },
                    onConfirmation = {
                        openAlertDialog.value = false

                        Toast.makeText(
                            context,
                            confirmationMessage,
                            Toast.LENGTH_SHORT
                        ).show()

                        SharedFunctions.deleteAllEntity(
                            entityType = entityType,
                            animeViewModel = animeViewModel,
                            mangaViewModel = mangaViewModel,
                            characterViewModel = characterViewModel,
                            onError = onError
                        )
                    }
                )
            }
        }

        Button(
            onClick = {
                openAlertDialog.value = true
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = md_theme_dark_primaryContainer,
                contentColor = Color.White
            )
        ) {
            Text(text = stringResource(id = R.string.tab_delete_all_items))
        }
    }

    Column {
        Divider(
            modifier = Modifier,
            thickness = 2.dp,
            color = md_theme_dark_primaryContainer
        )

        Spacer(modifier = Modifier.size(2.dp))

        Divider(
            modifier = Modifier,
            thickness = 2.dp,
            color = md_theme_dark_primaryContainer
        )
    }
}
