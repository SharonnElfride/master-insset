package com.sharonn.poppy.ui.screen

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.sharonn.poppy.R
import com.sharonn.poppy.data.model.notes.Note
import com.sharonn.poppy.utils.AvailableScreens
import com.sharonn.poppy.utils.VISUALIZE_NOTE
import com.sharonn.poppy.ui.components.AllItemsPermanentDeletionDialog
import com.sharonn.poppy.ui.components.cancellationToast
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.md_theme_dark_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_onSurfaceVariant
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.theme.md_theme_light_surfaceVariant
import com.sharonn.poppy.ui.viewmodel.NoteViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteScreen(
    context: Context,
    navController: NavController = rememberNavController(),
    noteIdsToDelete: MutableList<String>
) {
    val noteViewModel: NoteViewModel = viewModel()
    val notes: List<Note?> = noteViewModel.notes.collectAsState(emptyList()).value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = md_theme_light_primary)
            .padding(top = 10.dp)
            .clip(shape = RoundedCornerShape(15.dp, 15.dp, 0.dp, 0.dp))
            .background(color = dark_custom_color_2),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Start)
                .padding(top = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val noExistingNotes = stringResource(id = R.string.no_existing_notes_message)
            val allNotesDeletedSuccess = stringResource(id = R.string.all_notes_deletion_succeeded)
            val deletionFailed = stringResource(id = R.string.deletion_failed_message)
            val openAlertDialog = remember { mutableStateOf(false) }
            val confirmationMessage = stringResource(id = R.string.confirmation_registered_caption)

            when {
                openAlertDialog.value -> {
                    AllItemsPermanentDeletionDialog(
                        onDismissRequest = { openAlertDialog.value = false },
                        onConfirmation = {
                            openAlertDialog.value = false

                            Toast.makeText(
                                context,
                                confirmationMessage,
                                Toast.LENGTH_SHORT
                            ).show()

                            noteViewModel.deleteAllNotes(
                                onSuccessAction = {
                                    Handler(Looper.getMainLooper()).post {
                                        Toast.makeText(
                                            context,
                                            allNotesDeletedSuccess,
                                            Toast.LENGTH_SHORT
                                        ).show()

                                        noteViewModel.updateNotes(
                                            onSuccessAction = {},
                                            onFailureAction = {}
                                        )
                                    }
                                },
                                onFailureAction = {
                                    Handler(Looper.getMainLooper()).post {
                                        Toast.makeText(
                                            context,
                                            deletionFailed,
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                },
                                onCanceledAction = {
                                    Handler(Looper.getMainLooper()).post {
                                        cancellationToast(
                                            context = context
                                        )
                                    }
                                }
                            )
                        }
                    )
                }
            }

            Button(
                modifier = Modifier.padding(bottom = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = md_theme_light_primary,
                    contentColor = md_theme_light_onPrimary
                ),
                onClick = {
                    if (notes.isEmpty()) {
                        Handler(Looper.getMainLooper()).post {
                            Toast.makeText(
                                context,
                                noExistingNotes,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        openAlertDialog.value = true
                    }
                },
                shape = RoundedCornerShape(25.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.DeleteForever,
                    contentDescription = "Content description",
                    tint = md_theme_light_onPrimary
                )

                Spacer(Modifier.size(ButtonDefaults.IconSpacing))

                Text(
                    text = stringResource(id = R.string.delete_all_notes_button_text),
                    style = TextStyle(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontStyle = FontStyle.Normal,
                        color = md_theme_light_onPrimary
                    ),
                    textAlign = TextAlign.Center,
                )
            }

            Divider(
                modifier = Modifier.padding(top = 10.dp),
                thickness = 2.dp,
                color = md_theme_dark_onPrimary
            )
        }

        LazyColumn(
            modifier = Modifier
        ) {
            itemsIndexed(notes) { index, _ ->
                notes[index]?.let { note ->
                    Card(
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = md_theme_light_surfaceVariant,
                            contentColor = md_theme_light_onSurfaceVariant
                        ),
                        onClick = {
                            navController.navigate(
                                "${AvailableScreens.VISUALIZE_SINGLE_NOTE_SCREEN.getScreenIdentification()}/{$VISUALIZE_NOTE}".replace(
                                    "{$VISUALIZE_NOTE}",
                                    note.id
                                )
                            )
                        }
                    ) {
                        Row(
                            modifier = Modifier,
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            var checked by remember { mutableStateOf(false) }

                            Checkbox(
                                checked = checked,
                                onCheckedChange = {
                                    checked = !checked
                                    if (checked) {
                                        noteIdsToDelete.add(note.id)
                                    } else {
                                        noteIdsToDelete.remove(note.id)
                                    }
                                }
                            )

                            Column(
                                modifier = Modifier.padding(5.dp),
                                horizontalAlignment = Alignment.Start,
                                verticalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Text(
                                    text = note.title.uppercase(),
                                    modifier = Modifier.padding(4.dp),
                                    color = Color.Black,
                                    textAlign = TextAlign.Left,
                                    style = TextStyle(
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Cursive,
                                    ),
                                    maxLines = 1,
                                    softWrap = true,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Text(
                                    text = note.content,
                                    modifier = Modifier.padding(4.dp),
                                    color = Color.Black,
                                    textAlign = TextAlign.Left,
                                    style = TextStyle(
                                        fontSize = 16.sp
                                    ),
                                    maxLines = 3,
                                    softWrap = true,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
