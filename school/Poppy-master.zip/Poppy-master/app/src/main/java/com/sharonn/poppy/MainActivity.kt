package com.sharonn.poppy

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Window
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.LifecycleCoroutineScope
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.auth.api.identity.Identity
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.sharonn.poppy.data.firebase.FirebaseAuthUiClient
import com.sharonn.poppy.data.firebase.GoogleAuthUiClient
import com.sharonn.poppy.data.firebase.SharedAuthFunctions
import com.sharonn.poppy.utils.AvailableScreens
import com.sharonn.poppy.utils.EntityType
import com.sharonn.poppy.utils.VISUALIZE_ANIME
import com.sharonn.poppy.utils.VISUALIZE_CHARACTER
import com.sharonn.poppy.utils.VISUALIZE_MANGA
import com.sharonn.poppy.utils.VISUALIZE_SINGLE_SCREEN_PREFIX
import com.sharonn.poppy.ui.components.cancellationToast
import com.sharonn.poppy.ui.model.AnimeItemUI
import com.sharonn.poppy.ui.model.CharacterItemUI
import com.sharonn.poppy.ui.model.MangaItemUI
import com.sharonn.poppy.ui.navigation.AppNavHost
import com.sharonn.poppy.ui.sheet.NoteBottomSheet
import com.sharonn.poppy.ui.theme.PoppyTheme
import com.sharonn.poppy.ui.theme.md_theme_dark_onPrimaryContainer
import com.sharonn.poppy.ui.theme.md_theme_dark_primaryContainer
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.viewmodel.AnimeViewModel
import com.sharonn.poppy.ui.viewmodel.CharacterViewModel
import com.sharonn.poppy.ui.viewmodel.MangaViewModel
import com.sharonn.poppy.ui.viewmodel.NoteViewModel
import com.sharonn.poppy.ui.viewmodel.SignInViewModel
import kotlinx.coroutines.launch


class MainActivity : ComponentActivity() {
    private val googleAuthUiClient by lazy {
        GoogleAuthUiClient(
            context = applicationContext,
            oneTapClient = Identity.getSignInClient(applicationContext)
        )
    }

    private val firebaseAuthUiClient by lazy {
        FirebaseAuthUiClient()
    }

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

//        val windowInsetsController = ViewCompat.getWindowInsetsController(window.decorView)
//        // Hide the system bars .
//        windowInsetsController?.hide(WindowInsetsCompat.Type.systemBars())
//        // Show the system bars .
//        windowInsetsController?.show(WindowInsetsCompat.Type.systemBars())

        setContent {
            PoppyTheme {
                MainScreen(
                    googleAuthUiClient = googleAuthUiClient,
                    firebaseAuthUiClient = firebaseAuthUiClient,
                    lifecycleScope = lifecycleScope,
                    applicationContext = applicationContext,
                    window = window
                )
            }
        }
    }
}

@Composable
private fun MainScreen(
    googleAuthUiClient: GoogleAuthUiClient,
    firebaseAuthUiClient: FirebaseAuthUiClient,
    lifecycleScope: LifecycleCoroutineScope,
    applicationContext: Context,
    window: Window,
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination?.route ?: ""
    val canNavigateBack = AvailableScreens.canNav(currentDestination = currentDestination)
    val currentScreen = AvailableScreens.getScreen(currentDestination = currentDestination)

    val noteIdsToDelete = remember {
        mutableListOf<String>()
    }

    val contextForToast = LocalContext.current.applicationContext

    Scaffold(
        modifier = Modifier,
        topBar = {
            if (AvailableScreens.showTopAppBar(currentScreen = currentScreen)) {
                PoppyTopAppBar(
                    canNavigateBack = canNavigateBack,
                    navigate = {
                        navController.popBackStack()
                    },
                    contextForToast = contextForToast,
                    navBackStackEntry = navBackStackEntry,
                    window = window,
                    noteIdsToDelete = noteIdsToDelete,
                    currentScreen = currentScreen
                )
            }
        },
        bottomBar = {
            if (AvailableScreens.showBottomAppBar(currentScreen = currentScreen)) {
                PoppyBottomAppBar(
                    navController = navController,
                    currentScreen = currentScreen
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            val viewModel = viewModel<SignInViewModel>()
            val state by viewModel.state.collectAsState()

            LaunchedEffect(key1 = Unit) {
                val signedInUser = SharedAuthFunctions.getSignedInUser()
                if (signedInUser != null) {
                    navController.navigate(AvailableScreens.HOME_SCREEN.getScreenIdentification())
                }
            }

            val launcher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.StartIntentSenderForResult(),
                onResult = { result ->
                    if (result.resultCode == ComponentActivity.RESULT_OK) {
                        lifecycleScope.launch {
                            val signInResult = googleAuthUiClient.signInWithIntent(
                                intent = result.data ?: return@launch
                            )

                            viewModel.onSignInResult(signInResult)
                        }
                    }
                }
            )

            val noInfoText = stringResource(id = R.string.no_info_caption)
            val successfulSignInText =
                stringResource(id = R.string.sign_in_caption) + " " + stringResource(
                    id = R.string.successful_caption
                )

            LaunchedEffect(key1 = state.isSignInSuccessful) {
                if (state.isSignInSuccessful) {
                    Toast.makeText(
                        applicationContext,
                        successfulSignInText,
                        Toast.LENGTH_SHORT
                    ).show()

                    val signedInUser = SharedAuthFunctions.getSignedInUser()
                    signedInUser.let { userData ->
                        var userInfoToast = noInfoText

                        if (userData != null) {
                            userInfoToast = " ${userData.userId} - ${userData.username!!}"
                        }

                        Toast.makeText(
                            applicationContext,
                            userInfoToast,
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    navController.navigate(AvailableScreens.HOME_SCREEN.getScreenIdentification())
                    viewModel.resetState()
                }
            }

            AppNavHost(
                navController = navController,
                state = state,
                googleAuthUiClient = googleAuthUiClient,
                lifecycleScope = lifecycleScope,
                launcher = launcher,
                applicationContext = applicationContext,
                firebaseAuthUiClient = firebaseAuthUiClient,
                noteIdsToDelete = noteIdsToDelete
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PoppyTopAppBar(
    canNavigateBack: Boolean,
    navigate: () -> Unit,
    modifier: Modifier = Modifier,
    contextForToast: Context,
    navBackStackEntry: NavBackStackEntry? = null,
    window: Window,
    noteIdsToDelete: MutableList<String>,
    currentScreen: AvailableScreens
) {
    var screenTitle = stringResource(id = currentScreen.getScreenTitle())

    var anime: AnimeItemUI? = null
    var manga: MangaItemUI? = null
    var character: CharacterItemUI? = null

    if (
        currentScreen.getScreenIdentification().contains(VISUALIZE_SINGLE_SCREEN_PREFIX)
    ) {
        val animeViewModel: AnimeViewModel = viewModel()
        val mangaViewModel: MangaViewModel = viewModel()
        val characterViewModel: CharacterViewModel = viewModel()

        var entityId: Long
        val cannotRetrieveItemText = stringResource(id = R.string.cannot_retrieve_item_caption)

        if (currentScreen === AvailableScreens.VISUALIZE_SINGLE_ANIME_SCREEN) {
            val animeId = navBackStackEntry?.arguments?.getString(VISUALIZE_ANIME)
            animeId?.let {
                entityId = animeId.toLong()

                anime = animeViewModel.getSingleAnime(
                    animeId = entityId,
                    onError = {
                        Toast.makeText(
                            contextForToast,
                            "$cannotRetrieveItemText = $entityId",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )

                anime?.let {
                    when (it) {
                        is AnimeItemUI.Item -> {
                            screenTitle = it.animeTitle
                        }

                        else -> {}
                    }
                }
            }
        }

        if (currentScreen === AvailableScreens.VISUALIZE_SINGLE_MANGA_SCREEN) {
            val mangaId = navBackStackEntry?.arguments?.getString(VISUALIZE_MANGA)
            mangaId?.let {
                entityId = mangaId.toLong()

                manga = mangaViewModel.getSingleManga(
                    mangaId = entityId,
                    onError = {
                        Toast.makeText(
                            contextForToast,
                            "$cannotRetrieveItemText = $entityId",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )

                manga?.let {
                    when (it) {
                        is MangaItemUI.Item -> {
                            screenTitle = it.mangaTitle
                        }

                        else -> {}
                    }
                }
            }
        }

        if (currentScreen === AvailableScreens.VISUALIZE_SINGLE_CHARACTER_SCREEN) {
            val characterId = navBackStackEntry?.arguments?.getString(VISUALIZE_CHARACTER)
            characterId?.let {
                entityId = characterId.toLong()

                character = characterViewModel.getSingleCharacter(
                    characterId = entityId,
                    onError = {
                        Toast.makeText(
                            contextForToast,
                            "$cannotRetrieveItemText = $entityId",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )

                character?.let {
                    when (it) {
                        is CharacterItemUI.Item -> {
                            screenTitle = it.characterName
                        }

                        else -> {}
                    }
                }
            }
        }

        if (currentScreen === AvailableScreens.VISUALIZE_SINGLE_NOTE_SCREEN) {
            screenTitle = stringResource(id = R.string.single_note_title)
        }
    }

    val imageVector = currentScreen.getScreenIcon()

    CenterAlignedTopAppBar(
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = md_theme_light_primary,
            titleContentColor = md_theme_light_onPrimary,
        ),
        title = {
            Row(
                modifier = Modifier,
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (
                    !currentScreen.getScreenIdentification()
                        .contains(VISUALIZE_SINGLE_SCREEN_PREFIX)
                ) {
                    Icon(
                        imageVector = imageVector,
                        contentDescription = "${currentScreen.getScreenIdentification()} icon",
                        modifier = Modifier
                    )

                    Spacer(modifier = Modifier.size(ButtonDefaults.IconSpacing))
                }

                Text(
                    text = screenTitle,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        modifier = modifier,
        navigationIcon = {
            if (canNavigateBack) {
                IconButton(
                    onClick = navigate,
                    colors = IconButtonDefaults.iconButtonColors(
                        contentColor = md_theme_light_onPrimary
                    )
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ArrowBack,
                        contentDescription = "Arrow back icon"
                    )
                }
            }
        },
        actions = {
            if (
                currentScreen === AvailableScreens.VISUALIZE_SINGLE_ANIME_SCREEN ||
                currentScreen === AvailableScreens.VISUALIZE_SINGLE_MANGA_SCREEN ||
                currentScreen === AvailableScreens.VISUALIZE_SINGLE_CHARACTER_SCREEN
            ) {
                val notYetText = stringResource(id = R.string.not_yet_implemented_text)
                val userId = Firebase.auth.currentUser?.uid ?: String()
                val showBottomSheet = remember { mutableStateOf(false) }

                var entityId by remember { mutableLongStateOf(0) }
                var entityDenomination by remember { mutableStateOf("") }
                var entityType by remember { mutableStateOf(EntityType.ANIME) }

                when {
                    showBottomSheet.value -> {
                        NoteBottomSheet(
                            onBottomSheetDismissRequest = { showBottomSheet.value = false },
                            entityId = entityId,
                            entityType = entityType,
                            entityDenomination = entityDenomination,
                            userId = userId,
                            window = window
                        )
                    }
                }

                IconButton(onClick = {
                    when (currentScreen) {
                        AvailableScreens.VISUALIZE_SINGLE_ANIME_SCREEN -> {
                            anime?.let {
                                when (it) {
                                    is AnimeItemUI.Item -> {
                                        showBottomSheet.value = true
                                        entityId = it.animeId
                                        entityType = EntityType.ANIME
                                        entityDenomination = it.animeTitle
                                    }

                                    else -> {}
                                }
                            }
                        }

                        AvailableScreens.VISUALIZE_SINGLE_MANGA_SCREEN -> {
                            manga?.let {
                                when (it) {
                                    is MangaItemUI.Item -> {
                                        showBottomSheet.value = true
                                        entityId = it.mangaId
                                        entityType = EntityType.MANGA
                                        entityDenomination = it.mangaTitle
                                    }

                                    else -> {}
                                }
                            }
                        }

                        AvailableScreens.VISUALIZE_SINGLE_CHARACTER_SCREEN -> {
                            character?.let {
                                when (it) {
                                    is CharacterItemUI.Item -> {
                                        showBottomSheet.value = true
                                        entityId = it.characterId
                                        entityType = EntityType.CHARACTER
                                        entityDenomination = it.characterName
                                    }

                                    else -> {}
                                }
                            }
                        }

                        else -> {
                            Toast.makeText(
                                contextForToast,
                                notYetText,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }) {
                    Icon(
                        imageVector = Icons.Rounded.NoteAdd,
                        contentDescription = "Add/Ajouter note icon",
                        tint = Color.White
                    )
                }
            }

            if (currentScreen === AvailableScreens.NOTES_SCREEN) {
                val noteViewModel: NoteViewModel = viewModel()

                IconButton(onClick = {
                    if (noteIdsToDelete.isEmpty()) {
                        Handler(Looper.getMainLooper()).post {
                            Toast.makeText(
                                contextForToast,
                                contextForToast.getString(R.string.no_notes_selected),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        noteViewModel.deleteManyNotes(
                            noteIds = noteIdsToDelete,
                            onSuccessAction = {
                                Toast.makeText(
                                    contextForToast,
                                    contextForToast.getString(R.string.deletion_successful_message),
                                    Toast.LENGTH_SHORT
                                ).show()

                                noteViewModel.updateNotes(
                                    onSuccessAction = {},
                                    onFailureAction = {}
                                )
                            },
                            onFailureAction = {
                                Handler(Looper.getMainLooper()).post {
                                    Toast.makeText(
                                        contextForToast,
                                        contextForToast.getString(R.string.deletion_failed_message),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            onCanceledAction = {
                                Handler(Looper.getMainLooper()).post {
                                    cancellationToast(
                                        context = contextForToast
                                    )
                                }
                            },
                        )
                    }
                }) {
                    Icon(
                        imageVector = Icons.Rounded.Delete,
                        contentDescription = "Delete multiple notes icon",
                        tint = Color.White
                    )
                }
            }
        }
    )
}

@Composable
private fun PoppyBottomAppBar(
    navController: NavHostController,
    currentScreen: AvailableScreens
) {
    NavigationBar(
        modifier = Modifier.fillMaxWidth(),
        containerColor = md_theme_light_primary,
        contentColor = Color.White,
        tonalElevation = 5.dp
    ) {
        NavigationBarItem(
            selected = (currentScreen === AvailableScreens.HOME_SCREEN),
            onClick = {
                if (currentScreen !== AvailableScreens.HOME_SCREEN) {
                    navController.navigate(route = AvailableScreens.HOME_SCREEN.getScreenIdentification())
                }
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = md_theme_dark_primaryContainer,
                unselectedIconColor = md_theme_dark_onPrimaryContainer,
                unselectedTextColor = md_theme_dark_onPrimaryContainer
            ),
            icon = {
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Home,
                        contentDescription = "${stringResource(id = R.string.home_title)} icon"
                    )
                    Text(text = stringResource(id = R.string.home_title))
                }
            },
//            label = {
//                Text(text = stringResource(id = R.string.home_title))
//            }
        )

        NavigationBarItem(
            selected = (currentScreen === AvailableScreens.LIBRARY_SCREEN),
            onClick = {
                if (currentScreen !== AvailableScreens.LIBRARY_SCREEN) {
                    navController.navigate(route = AvailableScreens.LIBRARY_SCREEN.getScreenIdentification())
                }
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = md_theme_dark_primaryContainer,
                unselectedIconColor = md_theme_dark_onPrimaryContainer,
                unselectedTextColor = md_theme_dark_onPrimaryContainer
            ),
            icon = {
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.MenuBook,
                        contentDescription = "${stringResource(id = R.string.library_title)} icon"
                    )
                    Text(text = stringResource(id = R.string.library_title))
                }
            }
        )

        NavigationBarItem(
            selected = (currentScreen === AvailableScreens.SECRET_GALLERY_SCREEN),
            onClick = {
                if (currentScreen !== AvailableScreens.SECRET_GALLERY_SCREEN) {
                    navController.navigate(route = AvailableScreens.SECRET_GALLERY_SCREEN.getScreenIdentification())
                }
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = md_theme_dark_primaryContainer,
                unselectedIconColor = md_theme_dark_onPrimaryContainer,
                unselectedTextColor = md_theme_dark_onPrimaryContainer
            ),
            icon = {
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_poppy_logo),
                        contentDescription = "${stringResource(id = R.string.secret_gallery_title)} icon",
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                    )
                }
            }
        )

        NavigationBarItem(
            selected = (currentScreen === AvailableScreens.FAVORITE_SCREEN),
            onClick = {
                if (currentScreen !== AvailableScreens.FAVORITE_SCREEN) {
                    navController.navigate(route = AvailableScreens.FAVORITE_SCREEN.getScreenIdentification())
                }
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = md_theme_dark_primaryContainer,
                unselectedIconColor = md_theme_dark_onPrimaryContainer,
                unselectedTextColor = md_theme_dark_onPrimaryContainer
            ),
            icon = {
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Favorite,
                        contentDescription = "${stringResource(id = R.string.favorites_title)} icon"
                    )
                    Text(text = stringResource(id = R.string.favorites_title))
                }
            }
        )

        NavigationBarItem(
            selected = (currentScreen === AvailableScreens.PROFILE_SCREEN),
            onClick = {
                if (currentScreen !== AvailableScreens.PROFILE_SCREEN) {
                    navController.navigate(route = AvailableScreens.PROFILE_SCREEN.getScreenIdentification())
                }
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = md_theme_dark_primaryContainer,
                unselectedIconColor = md_theme_dark_onPrimaryContainer,
                unselectedTextColor = md_theme_dark_onPrimaryContainer
            ),
            icon = {
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AccountCircle,
                        contentDescription = "${stringResource(id = R.string.profile_title)} icon"
                    )
                    Text(text = stringResource(id = R.string.profile_title))
                }
            }
        )
    }
}
