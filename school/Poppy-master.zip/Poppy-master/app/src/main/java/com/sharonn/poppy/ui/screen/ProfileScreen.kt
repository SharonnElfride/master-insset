package com.sharonn.poppy.ui.screen

import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.rounded.PersonOff
import androidx.compose.material.icons.rounded.StickyNote2
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.toUpperCase
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.sharonn.poppy.R
import com.sharonn.poppy.data.model.UserData
import com.sharonn.poppy.ui.components.AccountDeletionComponent
import com.sharonn.poppy.ui.components.AuthenticationButtonComponent
import com.sharonn.poppy.ui.components.ProfileInformation
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.md_theme_dark_errorContainer
import com.sharonn.poppy.ui.theme.md_theme_dark_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_primary


@Composable
fun ProfileScreen(
    userData: UserData?,
    onSignOut: () -> Unit,
    onAccountDeletionRequest: () -> Unit,
    onNotesButtonClick: () -> Unit,
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = md_theme_light_primary)
            .padding(top = 10.dp)
            .clip(shape = RoundedCornerShape(15.dp, 15.dp, 0.dp, 0.dp))
            .background(color = dark_custom_color_2)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(
            modifier = Modifier,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier.padding(start = 10.dp, end = 10.dp, bottom = 10.dp, top = 5.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (userData?.profilePictureURI != null) {
                    AsyncImage(
                        model = userData.profilePictureURI,
                        contentDescription = stringResource(id = R.string.profile_picture),
                        modifier = Modifier
                            .size(150.dp)
                            .clip(
                                CircleShape
                            ),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Image(
                        painter = painterResource(id = R.drawable.round_image_not_supported_24),
                        contentDescription = stringResource(id = R.string.no_profile_picture),
                        modifier = Modifier
                            .size(150.dp)
                            .clip(
                                CircleShape
                            ),
                        contentScale = ContentScale.Crop
                    )
                }

                val username =
                    userData?.username ?: stringResource(id = R.string.username_error_text)
                var color = md_theme_light_onPrimary
                if (userData?.username == null) {
                    color = md_theme_dark_errorContainer
                }

                Text(
                    text = username.toUpperCase(Locale.current),
                    style = TextStyle(
                        fontSize = 25.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontStyle = FontStyle.Normal,
                        color = color
                    ),
                    textAlign = TextAlign.Center,
                )
            }

            ProfileInformation(
                infoTitle = stringResource(id = R.string.user_id_info_key),
                information = userData?.userId,
                noDataText = stringResource(id = R.string.userid_error_text)
            )

            ProfileInformation(
                infoTitle = stringResource(id = R.string.email_info_key),
                information = userData?.email,
                noDataText = stringResource(id = R.string.user_email_error_text)
            )
        }

        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Divider(
                modifier = Modifier.padding(top = 10.dp),
                thickness = 2.dp,
                color = md_theme_dark_onPrimary
            )

            TextButton(
                onClick = onNotesButtonClick,
                modifier = Modifier,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = Color.White,
                )
            ) {
                Icon(imageVector = Icons.Rounded.StickyNote2, contentDescription = "Content description")
                Text(
                    text = stringResource(id = R.string.notes_title),
                    textAlign = TextAlign.Left,
                    style = TextStyle(
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                    ),
                )
            }
        }

        Column(
            modifier = Modifier.padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Divider(thickness = 2.dp, color = md_theme_dark_onPrimary)

            Column(
                modifier = Modifier,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(id = R.string.access_app_notification_settings_text),
                    style = TextStyle(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontStyle = FontStyle.Normal,
                        color = md_theme_light_onPrimary
                    ),
                    textAlign = TextAlign.Center,
                )

                val imageVector = Icons.Filled.Settings
                AuthenticationButtonComponent(
                    imageVector = imageVector,
                    value = stringResource(id = R.string.access_app_notification_settings),
                    onClickButton = {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        with(intent) {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }

                        //for Android 5-7
                        intent.putExtra("app_package", context.packageName)
                        intent.putExtra("app_uid", context.applicationInfo.uid)

                        // for Android 8 and above
                        intent.putExtra("android.provider.extra.APP_PACKAGE", context.packageName)

                        context.startActivity(intent)
                    },
                )
            }

            Column(
                modifier = Modifier,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(id = R.string.account_managment_part),
                    style = TextStyle(
                        fontSize = 25.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontStyle = FontStyle.Normal,
                        color = md_theme_light_onPrimary
                    ),
                    textAlign = TextAlign.Center,
                )

                val notYetText = stringResource(id = R.string.not_yet_implemented_text)
                AuthenticationButtonComponent(
                    imageVector = Icons.Rounded.PersonOff,
                    value = stringResource(id = R.string.revoke_access_to_google_account_button_text),
                    onClickButton = {
                        Toast.makeText(
                            context,
                            notYetText,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )

                AuthenticationButtonComponent(
                    imageVector = Icons.Filled.Logout,
                    value = context.getString(R.string.sign_out),
                    onClickButton = onSignOut
                )

                AccountDeletionComponent(
                    onAccountDeletionRequest = onAccountDeletionRequest
                )
            }
        }
    }
}


/*
//        OutlinedButton(
//            onClick = {
////            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
////            with(intent) {
////                data = Uri.fromParts("package", context.packageName, null)
////                addCategory(CATEGORY_DEFAULT)
////                addFlags(FLAG_ACTIVITY_NEW_TASK)
////                addFlags(FLAG_ACTIVITY_NO_HISTORY)
////                addFlags(FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
////            }
////            context.startActivity(intent)
//
//            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
//            with(intent) {
//                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//            }
//
//            //for Android 5-7
//            intent.putExtra("app_package", context.packageName)
//            intent.putExtra("app_uid", context.applicationInfo.uid)
//
//            // for Android 8 and above
//            intent.putExtra("android.provider.extra.APP_PACKAGE", context.packageName)
//
//            context.startActivity(intent)
//        },
//            colors = ButtonDefaults.outlinedButtonColors(
//                contentColor = Color.White
//            )
//        ) {
//            Text(text = "Go to settings")
//        }
 */

