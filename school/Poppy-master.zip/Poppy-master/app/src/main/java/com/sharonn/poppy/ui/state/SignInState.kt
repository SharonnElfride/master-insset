package com.sharonn.poppy.ui.state

data class SignInState(
    val isSignInSuccessful: Boolean = false,
    val accessAppError: String? = null
)
