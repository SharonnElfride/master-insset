package com.sharonn.poppy.ui.model

import com.sharonn.poppy.data.model.jikanapi.anime.AnimeObject

/**
 * The anime items are grouped by the anime type.
 *
 * The possible values are: "TV", "OVA", "Movie", "Special", "ONA", "Music"
 */
sealed interface AnimeItemUI {
    data class Header(
        val animeType: String?
    ) : AnimeItemUI

    data class Item(
        val animeId: Long,
        val animeUrl: String,
        val imageUrl: String? = null,
        val smallImageUrl: String? = null,
        val approvedByMal: Boolean,
        val animeType: String? = null,
        val trailerUrl: String? = null,
        val animeTitle: String,
        val animeKanjiTitle: String? = null,
        val animeOtherTitles: String? = null,
        val animeSource: String? = null,
        val animeEpisodes: Int? = null,
        val animeStatus: String? = null,
        val animeAiringStatus: Boolean,
        val animeAiringPeriodFrom: String? = null,
        val animeAiringPeriodTo: String? = null,
        val animeDuration: String? = null,
        val animeRating: String? = null,
        val animeMalScore: Float? = null,
        val animeMalRank: Int? = null,
        val animeMalPopularity: Int? = null,
        val animeSynopsis: String? = null,
        val animeBackground: String? = null,
        val animeProducers: String? = null,
        val animeStudios: String? = null,
        val animeGenres: String? = null,
        val animeExplicitGenres: String? = null,
        val animeThemes: String? = null,
        val animeDemographics: String? = null,
        val createdDate: String,
        val createdTime: String,
        val isFavorite: Boolean = false
    ) : AnimeItemUI

    data class Footer(
        val addedTotal: Int
    ) : AnimeItemUI

    data class CompleteAnime(
        val header: Header,
        val items: List<Item>,
        val footer: Footer
    ) : AnimeItemUI
}

fun List<AnimeObject>.toUi(): List<AnimeItemUI.Item> {
    return map { entity -> entity.toUiSingle() }
}

fun AnimeObject.toUiSingle(): AnimeItemUI.Item {
    return AnimeItemUI.Item(
        animeId = animeId,
        animeUrl = animeUrl,
        imageUrl = imageUrl,
        animeType = animeType,
        smallImageUrl = smallImageUrl,
        approvedByMal = approvedByMal,
        trailerUrl = trailerUrl,
        animeTitle = animeTitle,
        animeKanjiTitle = animeKanjiTitle,
        animeOtherTitles = animeOtherTitles,
        animeSource = animeSource,
        animeEpisodes = animeEpisodes,
        animeStatus = animeStatus,
        animeAiringStatus = animeAiringStatus,
        animeAiringPeriodFrom = animeAiringPeriodFrom,
        animeAiringPeriodTo = animeAiringPeriodTo,
        animeDuration = animeDuration,
        animeRating = animeRating,
        animeMalScore = animeMalScore,
        animeMalRank = animeMalRank,
        animeMalPopularity = animeMalPopularity,
        animeSynopsis = animeSynopsis,
        animeBackground = animeBackground,
        animeProducers = animeProducers,
        animeStudios = animeStudios,
        animeGenres = animeGenres,
        animeExplicitGenres = animeExplicitGenres,
        animeThemes = animeThemes,
        animeDemographics = animeDemographics,
        createdDate = createdDate,
        createdTime = createdTime,
        isFavorite = isFavorite
    )
}




