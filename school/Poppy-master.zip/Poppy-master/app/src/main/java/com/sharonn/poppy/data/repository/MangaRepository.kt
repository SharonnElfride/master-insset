package com.sharonn.poppy.data.repository

import com.sharonn.poppy.architecture.CustomApplication
import com.sharonn.poppy.architecture.RetrofitBuilder
import com.sharonn.poppy.data.model.jikanapi.manga.MangaObject
import com.sharonn.poppy.data.model.jikanapi.manga.toDomain
import com.sharonn.poppy.data.model.jikanapi.manga.toDomainSingle
import com.sharonn.poppy.data.model.jikanapi.manga.toRoom
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MangaRepository {
    private val mangaDao = CustomApplication.instance.poppyDatabase.mangaDao()

    suspend fun addManga(userId: String) {
        val result = RetrofitBuilder.getAnimeMangaCharacter().generateRandomManga()
        mangaDao.insert(manga = result.toRoom(userId = userId))
    }

    fun getSingleManga(mangaId: Long): MangaObject {
        return mangaDao.getSingleManga(mangaId = mangaId).toDomainSingle()
    }

    fun updateMangaIsFavorite(mangaId: Long, value: Boolean) {
        mangaDao.updateMangaIsFavorite(
            isFavorite = value,
            mangaId = mangaId
        )
    }

    fun deleteSingleManga(mangaId: Long) {
        mangaDao.deleteSingleManga(mangaId = mangaId)
    }

    fun getAllMangas(userId: String): Flow<List<MangaObject>> {
        return mangaDao.getAllMangas(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun getFirstThreeMangas(userId: String): Flow<List<MangaObject>> {
        return mangaDao.getFirstThreeMangas(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun getFavoriteMangas(userId: String): Flow<List<MangaObject>> {
        return mangaDao.getFavoriteMangas(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun deleteAllMangas(userId: String) {
        mangaDao.deleteAll(userId = userId)
    }
}