package com.sharonn.poppy.ui.screen

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.capitalize
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.sharonn.poppy.R
import com.sharonn.poppy.ui.components.AuthenticationButtonComponent
import com.sharonn.poppy.ui.components.EntityStringDataColumn
import com.sharonn.poppy.ui.model.AnimePictureItemUI
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.dark_oncustom_color_2
import com.sharonn.poppy.ui.theme.md_theme_dark_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.viewmodel.AnimePictureViewModel
import com.sharonn.poppy.utils.SharedFunctions.Companion.pictureDefaultFilename
import com.sharonn.poppy.utils.downloader.AndroidDownloader


@Composable
fun VisualizeSingleImageScreen(
    context: Context,
    pictureId: Long? = null
) {
    val downloader = AndroidDownloader(context)

    val pictureViewModel: AnimePictureViewModel = viewModel()
    val errorMessage = stringResource(id = R.string.error_image_generation)
    val selectedPicture = stringResource(id = R.string.selected_image_text)
    val brokenPicture = stringResource(id = R.string.broken_image_text)

    var picture: AnimePictureItemUI? = null
    if (pictureId != null) {
        picture = pictureViewModel.getSinglePicture(
            pictureId = pictureId,
            onError = {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(
                        context,
                        errorMessage,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = md_theme_light_primary)
            .padding(top = 10.dp)
            .clip(shape = RoundedCornerShape(15.dp, 15.dp, 0.dp, 0.dp))
            .background(color = dark_custom_color_2)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            EntityStringDataColumn(
                dataTitle = "${stringResource(id = R.string.picture_rating)}:",
                data = "${picture?.imageRating?.capitalize(Locale.current)}"
            )

            EntityStringDataColumn(
                dataTitle = "${stringResource(id = R.string.picture_source)}:",
                data = "${picture?.imageSourceUrl}",
                canCopy = true,
                context = context
            )

            EntityStringDataColumn(
                dataTitle = "${stringResource(id = R.string.artist_attribute_caption)}:",
                data = "${picture?.artistName}"
            )

            val addedOnText = stringResource(id = R.string.added_on_text)

            val annotatedString = buildAnnotatedString {
                withStyle(
                    style = SpanStyle(color = dark_oncustom_color_2, fontSize = 15.sp)
                ) {
                    append("$addedOnText ")
                }
                withStyle(
                    style = SpanStyle(color = Color.White, fontSize = 15.sp)
                ) {
                    append("${picture?.createdDate} ${picture?.createdTime}")
                }
            }

            Spacer(modifier = Modifier.size(10.dp))

            Text(
                text = annotatedString,
                textAlign = TextAlign.Center,
                style = TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontStyle = FontStyle.Normal,
                ),
            )
        }

        Divider(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
            thickness = 2.dp,
            color = md_theme_dark_onPrimary
        )

        Card(
            modifier = Modifier.padding(10.dp)
        ) {
            if (picture != null) {
                AsyncImage(
                    model = picture.imageUrl,
                    contentScale = ContentScale.Crop,
                    contentDescription = selectedPicture,
                    error = painterResource(R.drawable.round_broken_image_white_24),
                    placeholder = painterResource(R.drawable.loading),
                )
            } else {
                Image(
                    imageVector = Icons.Rounded.BrokenImage,
                    contentDescription = brokenPicture,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Spacer(modifier = Modifier.size(10.dp))

        AuthenticationButtonComponent(
            imageVector = Icons.Rounded.FileDownload,
            iconSize = 20.dp,
            value = stringResource(id = R.string.download_picture_button_text),
            onClickButton = {
                if (picture != null) {
                    Toast.makeText(context, "Downloading...", Toast.LENGTH_SHORT).show()

                    downloader.downloadFile(
                        picture.imageUrl,
                        pictureDefaultFilename()
                    )
                }
            }
        )

        Spacer(modifier = Modifier.size(10.dp))
    }
}

