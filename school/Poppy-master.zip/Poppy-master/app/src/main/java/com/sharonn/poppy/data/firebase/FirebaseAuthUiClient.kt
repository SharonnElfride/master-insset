package com.sharonn.poppy.data.firebase

import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.sharonn.poppy.data.model.UserData
import kotlinx.coroutines.tasks.await
import java.util.concurrent.CancellationException

class FirebaseAuthUiClient {
    private val auth = Firebase.auth

    suspend fun signInWithEmailAndPassword(email: String, password: String): SignInResult {
        return try {
            val user = auth.signInWithEmailAndPassword(email, password).await().user

            SignInResult(
                data = user?.run {
                    UserData(
                        userId = user.uid,
                        username = user.displayName,
                        profilePictureURI = user.photoUrl?.toString(),
                        email = user.email
                    )
                },
                errorMessage = null
            )
        } catch (e: Exception) {
            e.printStackTrace()
            if (e is CancellationException) throw e

            SignInResult(
                data = null,
                errorMessage = e.message
            )

        }
    }

    suspend fun signUpWithEmailAndPassword(email: String, password: String): SignInResult {
        return try {
            val user = auth.createUserWithEmailAndPassword(email, password).await().user

            SignInResult(
                data = user?.run {
                    UserData(
                        userId = user.uid,
                        username = user.displayName,
                        profilePictureURI = user.photoUrl?.toString(),
                        email = user.email
                    )
                },
                errorMessage = null
            )
        } catch (e: Exception) {
            e.printStackTrace()
            if (e is CancellationException) throw e

            SignInResult(
                data = null,
                errorMessage = e.message
            )
        }
    }
}