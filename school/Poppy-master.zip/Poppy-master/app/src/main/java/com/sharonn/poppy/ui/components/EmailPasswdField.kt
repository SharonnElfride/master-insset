package com.sharonn.poppy.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.sharonn.poppy.R
import com.sharonn.poppy.ui.theme.md_theme_light_error
import com.sharonn.poppy.ui.theme.md_theme_light_onSurface
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.theme.md_theme_light_surface
import com.sharonn.poppy.ui.theme.md_theme_light_surfaceVariant

@Composable
fun EmailPasswdField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    leadingIcon: ImageVector,
    isError: Boolean = false,
    isPassword: Boolean = false,
    errorMessage: String
) {
    val revealPassword = remember { mutableStateOf(false) }
    val eyeIcon: ImageVector
    val description: String

    if (revealPassword.value) {
        eyeIcon = Icons.Rounded.VisibilityOff
        description = stringResource(id = R.string.hide_password_caption)
    } else {
        eyeIcon = Icons.Rounded.Visibility
        description = stringResource(id = R.string.show_password_caption)
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {
        TextField(
            value = value,
            onValueChange = onValueChange,
            label = {
                Text(text = label)
            },
            placeholder = {
                Text(text = placeholder)
            },
            leadingIcon = {
                Icon(imageVector = leadingIcon, contentDescription = "Content description")
            },
            trailingIcon = {
                if (isPassword) {
                    IconButton(
                        onClick = {
                            revealPassword.value = !revealPassword.value
                        },
                        modifier = Modifier,
                        content = {
                            Icon(
                                imageVector = eyeIcon,
                                contentDescription = description,
                            )
                        }
                    )
                }
            },
            visualTransformation = if (isPassword && !revealPassword.value) PasswordVisualTransformation() else VisualTransformation.None,
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
                focusedContainerColor = md_theme_light_surface,
                unfocusedContainerColor = md_theme_light_surface,
                disabledContainerColor = md_theme_light_surface,
                cursorColor = md_theme_light_primary,
                errorCursorColor = md_theme_light_error,
                selectionColors = TextSelectionColors(
                    handleColor = md_theme_light_primary,
                    backgroundColor = md_theme_light_surfaceVariant
                ),
                focusedIndicatorColor = md_theme_light_primary,
                unfocusedIndicatorColor = md_theme_light_onSurface,
                errorIndicatorColor = md_theme_light_error,
                focusedLeadingIconColor = md_theme_light_onSurface,
                unfocusedLeadingIconColor = md_theme_light_onSurface,
                errorLeadingIconColor = md_theme_light_error,
                focusedTrailingIconColor = md_theme_light_onSurface,
                unfocusedTrailingIconColor = md_theme_light_onSurface,
                errorTrailingIconColor = md_theme_light_onSurface,
                focusedLabelColor = md_theme_light_primary,
                unfocusedLabelColor = md_theme_light_onSurface,
                errorLabelColor = md_theme_light_error,
                focusedPlaceholderColor = md_theme_light_onSurface,
                unfocusedPlaceholderColor = md_theme_light_onSurface,
                disabledPlaceholderColor = md_theme_light_onSurface,
                errorSupportingTextColor = md_theme_light_error,
            ),
            supportingText = {
                if (isError) {
                    Text(text = errorMessage)
                }
            },
            isError = isError
        )
    }
}
