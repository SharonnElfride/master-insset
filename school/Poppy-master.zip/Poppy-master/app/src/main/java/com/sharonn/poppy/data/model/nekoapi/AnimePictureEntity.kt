package com.sharonn.poppy.data.model.nekoapi

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sharonn.poppy.utils.ANIME_PICTURE_TABLE_NAME


@Entity(tableName = ANIME_PICTURE_TABLE_NAME)
class AnimePictureEntity(
    @ColumnInfo(name = "userId")
    val userId: String,

    @ColumnInfo(name = "imageUrl")
    val imageUrl: String,

    @ColumnInfo(name = "imageSourceUrl")
    val imageSourceUrl: String? = null,

    @ColumnInfo(name = "imageRating")
    val imageRating: String,

    @ColumnInfo(name = "artistName")
    val artistName: String,

    @ColumnInfo(name = "createdDate")
    val createdDate: String,

    @ColumnInfo(name = "createdTime")
    val createdTime: String
) {
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0
}
