package com.sharonn.poppy.data.repository

import com.sharonn.poppy.architecture.CustomApplication
import com.sharonn.poppy.data.model.ratingparam.RatingParam
import com.sharonn.poppy.data.model.ratingparam.toDomain
import com.sharonn.poppy.data.model.ratingparam.toRoomObject
import com.sharonn.poppy.utils.RatingParamType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class RatingParamRepository {
    private val ratingParamDao = CustomApplication.instance.poppyDatabase.ratingParamDao()

    fun getUserRatingParam(userId: String): Flow<RatingParam> {
        if (!ratingParamDao.isInitialized(userId)) {
            initializeUserRatingParam(
                ratingParam = RatingParam(
                    userId = userId
                )
            )
        }

        return ratingParamDao.getUserRatingParam(userId = userId).map {
            it.toDomain()
        }
    }

    fun deleteAll() {
        ratingParamDao.deleteAll()
    }

    fun deleteUserRatingParam(
        userId: String,
    ) {
        ratingParamDao.deleteUserRatingParam(
            userId = userId
        )
    }

    private fun initializeUserRatingParam(ratingParam: RatingParam) {
        ratingParamDao.insert(ratingParam.toRoomObject())
    }

    fun updateUserRatingParam(userId: String, value: Boolean, ratingParamType: RatingParamType) {
        when (ratingParamType) {
            RatingParamType.SAFE -> ratingParamDao.updateRatingSafe(
                safe = value,
                userId = userId
            )

            RatingParamType.BORDERLINE -> ratingParamDao.updateRatingBorderline(
                borderline = value,
                userId = userId
            )

            RatingParamType.SUGGESTIVE -> ratingParamDao.updateRatingSuggestive(
                suggestive = value,
                userId = userId
            )
        }
    }
}
