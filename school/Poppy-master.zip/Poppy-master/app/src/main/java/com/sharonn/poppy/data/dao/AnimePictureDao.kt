package com.sharonn.poppy.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sharonn.poppy.data.model.nekoapi.AnimePictureEntity
import com.sharonn.poppy.utils.ANIME_PICTURE_TABLE_NAME
import kotlinx.coroutines.flow.Flow


@Dao
interface AnimePictureDao {
    @Query("SELECT * FROM $ANIME_PICTURE_TABLE_NAME WHERE userId = :userId ORDER BY createdDate AND createdTime ASC")
    fun getAllPictures(userId: String): Flow<List<AnimePictureEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(animePicture: AnimePictureEntity)

    @Query("SELECT * FROM $ANIME_PICTURE_TABLE_NAME WHERE id = :pictureId")
    fun getSinglePicture(pictureId: Long): AnimePictureEntity

    @Query("DELETE FROM $ANIME_PICTURE_TABLE_NAME WHERE id = :pictureId")
    fun deleteSinglePicture(pictureId: Long)

    @Query("DELETE FROM $ANIME_PICTURE_TABLE_NAME WHERE userId = :userId")
    fun deleteAll(userId: String)
}
