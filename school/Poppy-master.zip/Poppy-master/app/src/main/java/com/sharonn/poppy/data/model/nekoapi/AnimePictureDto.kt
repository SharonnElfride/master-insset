package com.sharonn.poppy.data.model.nekoapi

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.sharonn.poppy.utils.DateFormat
import com.sharonn.poppy.domain.FormatDateUseCase
import java.util.Date

data class AnimePictureDto(
    @Expose
    @SerializedName("items")
    val items: List<Item>,

//    @Expose
//    @SerializedName("source")
//    val imageSourceUrl: String?,
//
//    @Expose
//    @SerializedName("rating")
//    val imageRating: String,
//
//    @Expose
//    @SerializedName("artist")
//    var artist: Artist?
)

data class Item(
    @Expose
    @SerializedName("image_url")
    val imageUrl: String,

    @Expose
    @SerializedName("source")
    val imageSourceUrl: String?,

    @Expose
    @SerializedName("rating")
    val imageRating: String,

    @Expose
    @SerializedName("artist")
    var artist: Artist?
)

data class Artist(
    @Expose
    @SerializedName("name")
    val artistName: String?
)

fun AnimePictureDto.toRoom(userId: String): AnimePictureEntity {
    val currentDateTime = Date()

    // Parse json here !
    val imageUrl = items[0].imageUrl
    val imageSourceUrl = items[0].imageSourceUrl
    val imageRating = items[0].imageRating
    val artistName = items[0].artist?.artistName ?: ""

    return AnimePictureEntity(
        userId = userId,
        imageUrl = imageUrl,
        imageSourceUrl = imageSourceUrl,
        imageRating = imageRating,
        artistName = artistName,
        createdDate = FormatDateUseCase().invoke(currentDateTime, DateFormat.DATE),
        createdTime = FormatDateUseCase().invoke(currentDateTime, DateFormat.TIME)
    )
}
