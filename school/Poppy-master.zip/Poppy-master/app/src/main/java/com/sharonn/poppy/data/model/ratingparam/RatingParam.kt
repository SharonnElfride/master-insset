package com.sharonn.poppy.data.model.ratingparam

data class RatingParam(
    val userId: String,
    val safe: Boolean = true,
    val borderline: Boolean = false,
    val suggestive: Boolean = false,
    // val explicit: Boolean = false
)

