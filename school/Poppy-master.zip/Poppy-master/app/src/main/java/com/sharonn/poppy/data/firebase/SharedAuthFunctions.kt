package com.sharonn.poppy.data.firebase

import com.google.android.gms.auth.api.identity.SignInClient
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.sharonn.poppy.data.model.UserData
import com.sharonn.poppy.ui.viewmodel.AnimePictureViewModel
import com.sharonn.poppy.ui.viewmodel.AnimeViewModel
import com.sharonn.poppy.ui.viewmodel.CharacterViewModel
import com.sharonn.poppy.ui.viewmodel.MangaViewModel
import com.sharonn.poppy.ui.viewmodel.NoteViewModel
import com.sharonn.poppy.ui.viewmodel.RatingParamViewModel
import kotlinx.coroutines.tasks.await
import java.util.concurrent.CancellationException

class SharedAuthFunctions {
    companion object {
        private val auth = Firebase.auth
        private val userId = auth.currentUser?.uid ?: String()

        private val animeViewModel: AnimeViewModel = AnimeViewModel()
        private val mangaViewModel: MangaViewModel = MangaViewModel()
        private val characterViewModel: CharacterViewModel = CharacterViewModel()
        private val ratingParamViewModel = RatingParamViewModel(userId = userId)
        private val pictureViewModel: AnimePictureViewModel = AnimePictureViewModel()
        private val noteViewModel: NoteViewModel = NoteViewModel()

        suspend fun signOutUser(
            oneTapClient: SignInClient,
        ) {
            try {
                oneTapClient.signOut().await()
                auth.signOut()
            } catch (e: Exception) {
                e.printStackTrace()
                if (e is CancellationException) throw e
            }
        }

        fun getSignedInUser(
        ): UserData? = auth.currentUser?.run {
            UserData(
                userId = uid,
                username = displayName,
                profilePictureURI = photoUrl?.toString(),
                email = email
            )
        }

        suspend fun revokeUserAccess(
            oneTapClient: SignInClient,
            auth: FirebaseAuth
        ) {
            try {
                oneTapClient.signOut().await()
                auth.signOut()
                // Google access revoke ?
            } catch (e: Exception) {
                e.printStackTrace()
                if (e is CancellationException) throw e
            }
        }

        suspend fun deleteUserAccount(
            oneTapClient: SignInClient,
            onError: () -> Unit
        ) {
            try {
                oneTapClient.signOut().await()
                auth.currentUser?.delete()?.await()

                // Delete all animes, mangas, characters, pictures, ratingParams & notes
                animeViewModel.deleteAllAnimes(onError = onError)
                mangaViewModel.deleteAllMangas(onError = onError)
                characterViewModel.deleteAllCharacters(onError = onError)
                ratingParamViewModel.deleteUserRatingParam(onError = onError)
                pictureViewModel.deleteAllPictures(onError = onError)
                noteViewModel.deleteAllNotes(
                    onSuccessAction = {},
                    onFailureAction = onError,
                    onCanceledAction = {}
                )
            } catch (e: Exception) {
                e.printStackTrace()
                if (e is CancellationException) throw e
            }
        }
    }
}