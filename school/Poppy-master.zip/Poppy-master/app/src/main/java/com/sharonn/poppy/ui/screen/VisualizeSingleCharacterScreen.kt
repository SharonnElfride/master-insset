package com.sharonn.poppy.ui.screen

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.sharonn.poppy.R
import com.sharonn.poppy.utils.SharedFunctions
import com.sharonn.poppy.ui.components.EntityStringDataColumn
import com.sharonn.poppy.ui.components.EntityStringDataRow
import com.sharonn.poppy.ui.components.NoDataComponent
import com.sharonn.poppy.ui.model.CharacterItemUI
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.dark_oncustom_color_2
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.viewmodel.CharacterViewModel
import com.sharonn.poppy.ui.viewmodel.NoteViewModel


@Composable
fun VisualizeSingleCharacterScreen(
    context: Context,
    characterId: Long? = null
) {
    val characterViewModel: CharacterViewModel = viewModel()
    val errorMessage = stringResource(id = R.string.error_retrieving_item)
    val selectedImage = stringResource(id = R.string.selected_image_text)
    val brokenImage = stringResource(id = R.string.broken_image_text)

    val noteViewModel: NoteViewModel = viewModel()

    var character: CharacterItemUI.Item? = null
    if (characterId != null) {
        character = characterViewModel.getSingleCharacter(
            characterId = characterId,
            onError = {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(
                        context,
                        errorMessage,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        ) as CharacterItemUI.Item
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = md_theme_light_primary)
            .padding(top = 10.dp)
            .clip(shape = RoundedCornerShape(15.dp, 15.dp, 0.dp, 0.dp))
            .background(color = dark_custom_color_2)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (character != null) {
            val imageUrl = character.imageUrl
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (imageUrl != null) {
                    AsyncImage(
                        model = imageUrl,
                        contentScale = ContentScale.Crop,
                        contentDescription = selectedImage,
                        error = painterResource(R.drawable.round_broken_image_white_24),
                        placeholder = painterResource(R.drawable.loading),
                        modifier = Modifier
                            .size(width = 150.dp, height = 200.dp)
                            .clip(RoundedCornerShape(8.dp)),
                    )
                } else {
                    Image(
                        imageVector = Icons.Rounded.BrokenImage,
                        contentDescription = brokenImage,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(width = 150.dp, height = 200.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.SpaceEvenly,
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = character.characterName,
                        textAlign = TextAlign.Start,
                        style = TextStyle(
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold,
                            fontStyle = FontStyle.Normal,
                            color = dark_oncustom_color_2
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    EntityStringDataRow(
                        dataTitle = "${stringResource(id = R.string.kanji_name_attribute)}:",
                        data = character.characterKanjiName ?: ""
                    )

                    val names = SharedFunctions.fromStringToList(character.characterNicknames)
                    val nicknames = SharedFunctions.fromListToString(names, " / ")

                    EntityStringDataColumn(
                        dataTitle = stringResource(id = R.string.nicknames_attribute),
                        data = nicknames
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.about_attribute),
                    data = character.characterAbout ?: ""
                )

                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.mal_link_attribute),
                    data = character.characterUrl,
                    canCopy = true,
                    context = context
                ) // can be copied

                val existingNotes =
                    noteViewModel.countNotes(linkedEntityId = character.characterId.toString())
                        .collectAsState(0).value ?: 0
                val existingNotesCount = pluralStringResource(
                    id = R.plurals.number_of_existing_notes,
                    count = existingNotes,
                    existingNotes,
                )

                EntityStringDataRow(
                    dataTitle = "${stringResource(id = R.string.notes_title)}:",
                    data = stringResource(
                        id = R.string.existing_notes_character,
                        existingNotesCount
                    )
                )

                if (character.imageUrl != null) {
                    AsyncImage(
                        model = character.imageUrl,
                        contentScale = ContentScale.Crop,
                        contentDescription = selectedImage,
                        error = painterResource(R.drawable.round_broken_image_white_24),
                        placeholder = painterResource(R.drawable.loading),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .align(Alignment.CenterHorizontally),
                    )
                }

                Text(
                    text = "CharacterId = $characterId",
                    textAlign = TextAlign.Center,
                    style = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Normal,
                        color = md_theme_light_onPrimary
                    ),
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(10.dp)
                )
            }
        } else {
            NoDataComponent()
        }
    }
}
