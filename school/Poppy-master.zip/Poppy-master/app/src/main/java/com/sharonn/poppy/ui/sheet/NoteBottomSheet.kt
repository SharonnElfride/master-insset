package com.sharonn.poppy.ui.sheet

import android.graphics.Rect
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.ShortText
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sharonn.poppy.R
import com.sharonn.poppy.utils.DateFormat
import com.sharonn.poppy.utils.EntityType
import com.sharonn.poppy.utils.Validator
import com.sharonn.poppy.domain.FormatDateUseCase
import com.sharonn.poppy.ui.components.NoteAttributeField
import com.sharonn.poppy.ui.components.NoteEntityInformation
import com.sharonn.poppy.ui.components.cancellationToast
import com.sharonn.poppy.ui.theme.md_theme_dark_primaryContainer
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_onSurface
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.theme.md_theme_light_surfaceVariant
import com.sharonn.poppy.ui.viewmodel.NoteViewModel
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteBottomSheet(
    onBottomSheetDismissRequest: () -> Unit,
    entityId: Long,
    entityDenomination: String,
    entityType: EntityType,
    userId: String,
    window: Window,
) {
    val noteViewModel: NoteViewModel = viewModel()

    val sheetState = rememberModalBottomSheetState()

    val context = LocalContext.current

    val rectangle = Rect()
    window.decorView.getWindowVisibleDisplayFrame(rectangle)
    val contentHeight = window.findViewById<View>(Window.ID_ANDROID_CONTENT)?.height
    val contentBottom = window.findViewById<View>(Window.ID_ANDROID_CONTENT)?.bottom

    var systemNavigationBarHeight by remember { mutableIntStateOf(0) }

    if (contentBottom != null && contentHeight != null) {
        systemNavigationBarHeight = (contentBottom - contentHeight).div(2)
    }

    ModalBottomSheet(
        onDismissRequest = {
            onBottomSheetDismissRequest()
        },
        sheetState = sheetState,
        containerColor = md_theme_light_surfaceVariant,
        contentColor = md_theme_light_onSurface,
        windowInsets = WindowInsets(bottom = systemNavigationBarHeight.dp),
        dragHandle = {
            Row(
                modifier = Modifier.padding(top = 10.dp, bottom = 20.dp)
            ) {
                Spacer(
                    modifier = Modifier
                        .width(50.dp)
                        .height(5.dp)
                        .background(
                            color = md_theme_dark_primaryContainer,
                            shape = RoundedCornerShape(size = 10.dp)
                        )
                )
            }
        }
    ) {
        Column(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {

            val titleFieldValue = remember { mutableStateOf("") }
            val contentFieldValue = remember { mutableStateOf("") }

            val badTitleLengthError = remember { mutableStateOf(false) }
            val badContentLengthError = remember { mutableStateOf(false) }

            NoteAttributeField(
                value = titleFieldValue.value,
                onValueChange = { title ->
                    titleFieldValue.value = title
                },
                label = stringResource(id = R.string.title_caption),
                placeholder = stringResource(id = R.string.title_caption),
                leadingIcon = Icons.Rounded.Title,
                isError = badTitleLengthError.value,
                errorMessage = stringResource(id = R.string.note_title_error_message),
            )

            NoteEntityInformation(
                entityId = entityId.toString(),
                entityDenomination = entityDenomination,
                entityType = entityType.name
            )

            NoteAttributeField(
                value = contentFieldValue.value,
                onValueChange = { content ->
                    contentFieldValue.value = content
                },
                label = stringResource(id = R.string.content_caption),
                placeholder = stringResource(id = R.string.content_caption),
                leadingIcon = Icons.Rounded.ShortText,
                isError = badContentLengthError.value,
                errorMessage = stringResource(id = R.string.note_content_error_message),
                isContent = true,
            )

            val errorMessage = stringResource(id = R.string.an_error_occurred_caption)
            val insertionTakenIntoAccount =
                stringResource(id = R.string.insertion_taken_into_account)

            Button(
                modifier = Modifier,
                colors = ButtonDefaults.buttonColors(
                    containerColor = md_theme_light_primary,
                    contentColor = md_theme_light_onPrimary
                ),
                content = {
                    Row(
                        modifier = Modifier.width(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(ButtonDefaults.IconSpacing),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Rounded.Save, contentDescription = "Content description")
                        Text(text = stringResource(id = R.string.save_button_text))
                    }
                },
                onClick = {
                    Toast.makeText(
                        context,
                        insertionTakenIntoAccount,
                        Toast.LENGTH_SHORT
                    ).show()

                    badTitleLengthError.value =
                        !Validator.isValidNoteTitle(titleFieldValue.value)
                    badContentLengthError.value =
                        !Validator.isValidNoteContent(contentFieldValue.value)

                    if (!badTitleLengthError.value && !badContentLengthError.value) {
                        val currentDateTime = Date()
                        val currentFormattedDateTime =
                            FormatDateUseCase().invoke(currentDateTime, DateFormat.ALL)

                        noteViewModel.insertNote(
                            entity = hashMapOf(
                                "userId" to userId,
                                "title" to titleFieldValue.value,
                                "content" to contentFieldValue.value,
                                "entityId" to entityId.toString(),
                                "entityDenomination" to entityDenomination,
                                "entityType" to entityType.toString(),
                                "imageUrl" to "",
                                "createdOn" to currentFormattedDateTime,
                                "lastUpdatedOn" to currentFormattedDateTime,
                            ),
                            onSuccessAction = { result ->
                                Toast.makeText(
                                    context,
                                    "Doc id = ${result.id}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            onCanceledAction = {
                                cancellationToast(
                                    context = context
                                )
                            },
                            onFailureAction = {
                                Toast.makeText(
                                    context,
                                    errorMessage,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )

                        titleFieldValue.value = ""
                        contentFieldValue.value = ""
                        onBottomSheetDismissRequest()
                    }
                },
                shape = RoundedCornerShape(25.dp)
            )
        }
    }
}
