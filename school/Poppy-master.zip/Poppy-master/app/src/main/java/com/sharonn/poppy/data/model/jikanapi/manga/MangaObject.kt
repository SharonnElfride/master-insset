package com.sharonn.poppy.data.model.jikanapi.manga

data class MangaObject(
    val mangaId: Long,
    val userId: String,
    val mangaUrl: String,
    val imageUrl: String? = null,
    val smallImageUrl: String? = null,
    val approvedByMal: Boolean,
    val mangaTitle: String,
    val mangaKanjiTitle: String? = null,
    val mangaOtherTitles: String? = null,
    val mangaType: String? = null,
    val mangaChapters: Int? = null,
    val mangaVolumes: Int? = null,
    val mangaStatus: String? = null,
    val mangaPublishingStatus: Boolean,
    val mangaPublishingPeriodFrom: String? = null,
    val mangaPublishingPeriodTo: String? = null,
    val mangaMalScore: Float? = null,
    val mangaMalRank: Int? = null,
    val mangaMalPopularity: Int? = null,
    val mangaSynopsis: String? = null,
    val mangaBackground: String? = null,
    val mangaAuthors: String? = null,
    val mangaSerializations: String? = null,
    val mangaGenres: String? = null,
    val mangaExplicitGenres: String? = null,
    val mangaThemes: String? = null,
    val mangaDemographics: String? = null,
    val createdDate: String,
    val createdTime: String,
    val isFavorite: Boolean = false
)


fun List<MangaEntity>.toDomain(): List<MangaObject> {
    return map { entity ->
        entity.toDomainSingle()
    }
}

fun MangaEntity.toDomainSingle(): MangaObject {
    return MangaObject(
        mangaId = id,
        userId = userId,
        mangaUrl = mangaUrl,
        imageUrl = imageUrl,
        smallImageUrl = smallImageUrl,
        approvedByMal = approvedByMal,
        mangaTitle = mangaTitle,
        mangaKanjiTitle = mangaKanjiTitle,
        mangaOtherTitles = mangaOtherTitles,
        mangaType = mangaType,
        mangaChapters = mangaChapters,
        mangaVolumes = mangaVolumes,
        mangaStatus = mangaStatus,
        mangaPublishingStatus = mangaPublishingStatus,
        mangaPublishingPeriodFrom = mangaPublishingPeriodFrom,
        mangaPublishingPeriodTo = mangaPublishingPeriodTo,
        mangaMalScore = mangaMalScore,
        mangaMalRank = mangaMalRank,
        mangaMalPopularity = mangaMalPopularity,
        mangaSynopsis = mangaSynopsis,
        mangaBackground = mangaBackground,
        mangaAuthors = mangaAuthors,
        mangaSerializations = mangaSerializations,
        mangaGenres = mangaGenres,
        mangaExplicitGenres = mangaExplicitGenres,
        mangaThemes = mangaThemes,
        mangaDemographics = mangaDemographics,
        createdDate = createdDate,
        createdTime = createdTime,
        isFavorite = isFavorite
    )
}

