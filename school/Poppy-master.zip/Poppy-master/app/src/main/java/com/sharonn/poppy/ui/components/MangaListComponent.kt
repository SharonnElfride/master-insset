package com.sharonn.poppy.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.sharonn.poppy.R
import com.sharonn.poppy.utils.AvailableScreens
import com.sharonn.poppy.utils.EntityType
import com.sharonn.poppy.utils.ListType
import com.sharonn.poppy.utils.SharedFunctions
import com.sharonn.poppy.utils.VISUALIZE_MANGA
import com.sharonn.poppy.ui.model.MangaItemUI
import com.sharonn.poppy.ui.viewmodel.AnimeViewModel
import com.sharonn.poppy.ui.viewmodel.CharacterViewModel
import com.sharonn.poppy.ui.viewmodel.MangaViewModel


@Composable
fun MangaListComponent(
    type: ListType? = null,
    animeViewModel: AnimeViewModel,
    characterViewModel: CharacterViewModel,
    navController: NavController = rememberNavController()
) {
    val context = LocalContext.current
    val openAlertDialog = remember { mutableStateOf(false) }
    val currentMangaId = remember { mutableLongStateOf(0) }

    val errorMessage = stringResource(id = R.string.an_error_occurred_caption)
    val confirmationMessage = stringResource(id = R.string.confirmation_registered_caption)
    val mangaViewModel: MangaViewModel = viewModel()
    val list = mangaViewModel.mangas.collectAsState(emptyList()).value
    val favList = mangaViewModel.favoriteMangas.collectAsState(emptyList()).value

    val mangaList: List<MangaItemUI> = if (type != null && type == ListType.FAVORITE) favList else list

    when {
        openAlertDialog.value -> {
            DeletionDialog(
                onDismissRequest = { openAlertDialog.value = false },
                onConfirmation = {
                    openAlertDialog.value = false

                    Toast.makeText(
                        context,
                        confirmationMessage,
                        Toast.LENGTH_SHORT
                    ).show()

                    mangaViewModel.deleteSingleManga(
                        mangaId = currentMangaId.longValue,
                        onError = {
                            Toast.makeText(
                                context,
                                errorMessage,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    )
                }
            )
        }
    }

    if (mangaList.isEmpty()) {
        NoDataComponent()
    } else {
        LazyColumn(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            items(count = mangaList.size) { number ->
                when (val currentItem = mangaList[number]) {
                    is MangaItemUI.CompleteManga -> {
                        Column(
                            verticalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Book,
                                    contentDescription = "Book icon",
                                    modifier = Modifier.padding(start = 10.dp),
                                    tint = Color.Black
                                )

                                Text(
                                    modifier = Modifier.padding(10.dp),
                                    text = "${currentItem.header.mangaType}",
                                    style = TextStyle(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                    ),
                                    textAlign = TextAlign.Center,
                                    color = Color.Black
                                )
                            }

                            Divider(
                                color = Color.Black,
                                thickness = 1.dp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }

                        LazyRow(
                            modifier = Modifier.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            items(currentItem.items) { manga ->
                                val toastText = "MangaId = ${manga.mangaId}"
                                val imageUrl = manga.imageUrl
                                val title = manga.mangaTitle
                                val body = manga.mangaSynopsis
                                val footer = "${manga.createdDate} ${manga.createdTime}"
                                val isFavorite = manga.isFavorite

                                EntityCard(
                                    context = LocalContext.current,
                                    toastText = toastText,
                                    imageUrl = imageUrl,
                                    title = title,
                                    body = body,
                                    footer = footer,
                                    entityIsFavorite = isFavorite,
                                    onEyeIconClick = {
                                        navController.navigate(
                                            "${AvailableScreens.VISUALIZE_SINGLE_MANGA_SCREEN.getScreenIdentification()}/{$VISUALIZE_MANGA}".replace(
                                                "{$VISUALIZE_MANGA}",
                                                "${manga.mangaId}"
                                            )
                                        )
                                    },
                                    onFavoriteIconClick = {
                                        SharedFunctions.updateEntityIsFavorite(
                                            animeViewModel = animeViewModel,
                                            mangaViewModel = mangaViewModel,
                                            characterViewModel = characterViewModel,
                                            entityType = EntityType.MANGA,
                                            entityId = manga.mangaId,
                                            isFavorite = !isFavorite,
                                            onError = {
                                                Toast.makeText(
                                                    context,
                                                    errorMessage,
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                        )
                                    },
                                    onDeleteIconClick = {
                                        openAlertDialog.value = true
                                        currentMangaId.longValue = manga.mangaId
                                    }
                                )
                            }
                        }

                        Column(
                            modifier = Modifier
                                .padding(5.dp)
                                .background(color = Color.White, shape = CircleShape)
                                .padding(10.dp),
                        ) {
                            val existingVersions = pluralStringResource(
                                id = R.plurals.number_of_added_items,
                                count = currentItem.footer.addedTotal,
                                currentItem.footer.addedTotal
                            )

                            val footerText = stringResource(
                                id = R.string.footer_text_for_anime_and_manga,
                                existingVersions,
                                currentItem.header.mangaType ?: "NONE"
                            )

                            Text(
                                text = footerText,
                                style = TextStyle(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp,
                                    fontStyle = FontStyle.Italic
                                ),
                                color = Color.Black
                            )
                        }
                    }

                    else -> {}
                }
            }
        }
    }
}
