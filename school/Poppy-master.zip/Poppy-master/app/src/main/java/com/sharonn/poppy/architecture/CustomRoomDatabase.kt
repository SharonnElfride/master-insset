package com.sharonn.poppy.architecture

import androidx.room.Database
import androidx.room.RoomDatabase
import com.sharonn.poppy.data.dao.AnimeDao
import com.sharonn.poppy.data.dao.AnimePictureDao
import com.sharonn.poppy.data.dao.CharacterDao
import com.sharonn.poppy.data.dao.MangaDao
import com.sharonn.poppy.data.dao.RatingParamDao
import com.sharonn.poppy.data.model.jikanapi.anime.AnimeEntity
import com.sharonn.poppy.data.model.jikanapi.character.CharacterEntity
import com.sharonn.poppy.data.model.jikanapi.manga.MangaEntity
import com.sharonn.poppy.data.model.nekoapi.AnimePictureEntity
import com.sharonn.poppy.data.model.ratingparam.RatingParamEntity

@Database(
    entities = [
        AnimePictureEntity::class,
        RatingParamEntity::class,
        AnimeEntity::class,
        MangaEntity::class,
        CharacterEntity::class
    ],
    version = 4,
    exportSchema = false
)

// Dao => Data Access Object
abstract class CustomRoomDatabase : RoomDatabase() {
    abstract fun animePictureDao(): AnimePictureDao

    abstract fun ratingParamDao(): RatingParamDao

    abstract fun animeDao(): AnimeDao

    abstract fun mangaDao(): MangaDao

    abstract fun characterDao(): CharacterDao
}