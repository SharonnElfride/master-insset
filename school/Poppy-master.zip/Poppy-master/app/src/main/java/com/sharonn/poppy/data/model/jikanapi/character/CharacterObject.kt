package com.sharonn.poppy.data.model.jikanapi.character

data class CharacterObject(
    val characterId: Long,
    val userId: String,
    val characterUrl: String,
    val imageUrl: String? = null,
    val smallImageUrl: String? = null,
    val characterName: String,
    val characterKanjiName: String? = null,
    val characterNicknames: String? = null,
    val characterAbout: String? = null,
    val createdDate: String,
    val createdTime: String,
    val isFavorite: Boolean = false
)

fun List<CharacterEntity>.toDomain(): List<CharacterObject> {
    return map { entity ->
        entity.toDomainSingle()
    }
}

fun CharacterEntity.toDomainSingle(): CharacterObject {
    return CharacterObject(
        characterId = id,
        userId = userId,
        characterUrl = characterUrl,
        imageUrl = imageUrl,
        smallImageUrl = smallImageUrl,
        characterName = characterName,
        characterKanjiName = characterKanjiName,
        characterNicknames = characterNicknames,
        characterAbout = characterAbout,
        createdDate = createdDate,
        createdTime = createdTime,
        isFavorite = isFavorite
    )
}


