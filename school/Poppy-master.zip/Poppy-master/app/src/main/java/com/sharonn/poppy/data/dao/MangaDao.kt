package com.sharonn.poppy.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sharonn.poppy.data.model.jikanapi.manga.MangaEntity
import com.sharonn.poppy.utils.MANGA_TABLE_NAME
import kotlinx.coroutines.flow.Flow

@Dao
interface MangaDao {
    @Query("SELECT * FROM $MANGA_TABLE_NAME WHERE userId = :userId ORDER BY type ASC")
    fun getAllMangas(userId: String): Flow<List<MangaEntity>>

    @Query("SELECT * FROM $MANGA_TABLE_NAME WHERE userId = :userId LIMIT 3")
    fun getFirstThreeMangas(userId: String): Flow<List<MangaEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(manga: MangaEntity)

    @Query("SELECT * FROM $MANGA_TABLE_NAME WHERE id = :mangaId")
    fun getSingleManga(mangaId: Long): MangaEntity

    @Query("UPDATE $MANGA_TABLE_NAME SET isFavorite = :isFavorite WHERE id = :mangaId")
    fun updateMangaIsFavorite(isFavorite: Boolean, mangaId: Long): Int

    @Query("SELECT * FROM $MANGA_TABLE_NAME WHERE userId = :userId AND isFavorite = ${true} ORDER BY type ASC")
    fun getFavoriteMangas(userId: String): Flow<List<MangaEntity>>

    @Query("DELETE FROM $MANGA_TABLE_NAME WHERE id = :mangaId")
    fun deleteSingleManga(mangaId: Long)

    @Query("DELETE FROM $MANGA_TABLE_NAME WHERE userId = :userId")
    fun deleteAll(userId: String)
}