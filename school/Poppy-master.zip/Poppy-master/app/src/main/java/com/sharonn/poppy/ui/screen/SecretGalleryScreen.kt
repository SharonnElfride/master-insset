package com.sharonn.poppy.ui.screen

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.sharonn.poppy.R
import com.sharonn.poppy.data.model.ratingparam.RatingParam
import com.sharonn.poppy.utils.ANIME_PICTURE_BORDERLINE_KEY
import com.sharonn.poppy.utils.ANIME_PICTURE_SAFE_KEY
import com.sharonn.poppy.utils.ANIME_PICTURE_SUGGESTIVE_KEY
import com.sharonn.poppy.utils.RatingParamType
import com.sharonn.poppy.ui.components.AuthenticationButtonComponent
import com.sharonn.poppy.ui.components.PictureGridItemUI
import com.sharonn.poppy.ui.components.RatingParamSwitch
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.viewmodel.AnimePictureViewModel
import com.sharonn.poppy.ui.viewmodel.RatingParamViewModel

@Composable
fun SecretGalleryScreen(
    context: Context,
    navController: NavController = rememberNavController()
) {
    val auth = Firebase.auth
    val userId = auth.currentUser?.uid ?: String()
    val pictureViewModel: AnimePictureViewModel = viewModel()
    val list = pictureViewModel.pictures.collectAsState(emptyList()).value
    val ratingParamViewModel = RatingParamViewModel(userId = userId)
    val ratingParam =
        ratingParamViewModel.userRatingParam.collectAsState(initial = RatingParam(userId = userId)).value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = md_theme_light_primary)
            .padding(top = 10.dp)
            .clip(shape = RoundedCornerShape(15.dp, 15.dp, 0.dp, 0.dp))
            .background(color = dark_custom_color_2),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row {
            Text(
                text = stringResource(id = R.string.secret_gallery_congrats_message),
                style = TextStyle(
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontStyle = FontStyle.Normal,
                    color = md_theme_light_onPrimary
                ),
                textAlign = TextAlign.Center,
            )
        }

        Row {
            Text(
                text = stringResource(id = R.string.long_press_to_delete_picture),
                style = TextStyle(
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontStyle = FontStyle.Normal,
                    color = md_theme_light_onPrimary
                ),
                textAlign = TextAlign.Center,
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RatingParamSwitch(
                paramName = stringResource(id = R.string.safe_rating_param),
                checked = true,
                enabled = false
            )

            RatingParamSwitch(
                paramName = stringResource(id = R.string.borderline_rating_param),
                checked = ratingParam.borderline,
                onSwitch = {
                    ratingParamViewModel.updateUserRatingParam(
                        value = it,
                        ratingParamType = RatingParamType.BORDERLINE
                    )
                }
            )

            RatingParamSwitch(
                paramName = stringResource(id = R.string.suggestive_rating_param),
                checked = ratingParam.suggestive,
                onSwitch = {
                    ratingParamViewModel.updateUserRatingParam(
                        value = it,
                        ratingParamType = RatingParamType.SUGGESTIVE
                    )
                }
            )
        }

        val selectedCategories = ArrayList<String>()
        selectedCategories.add(ANIME_PICTURE_SAFE_KEY)

        if (ratingParam.borderline) {
            selectedCategories.add(ANIME_PICTURE_BORDERLINE_KEY)
        } else {
            selectedCategories.remove(ANIME_PICTURE_BORDERLINE_KEY)
        }

        if (ratingParam.suggestive) {
            selectedCategories.add(ANIME_PICTURE_SUGGESTIVE_KEY)
        } else {
            selectedCategories.remove(ANIME_PICTURE_SUGGESTIVE_KEY)
        }

        val imageVector = Icons.Rounded.Refresh
        val errorMessage = stringResource(id = R.string.error_image_generation)
        AuthenticationButtonComponent(
            imageVector = imageVector,
            value = stringResource(id = R.string.generate_pictures_button_text),
            onClickButton = {
                pictureViewModel.generateRandomPicture(
                    categories = selectedCategories,
                    onError = {
                        Handler(Looper.getMainLooper()).post {
                            Toast.makeText(
                                context,
                                errorMessage,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )
            }
        )

        PictureGridItemUI(pictures = list, navController = navController)
    }
}
