package com.sharonn.poppy.ui.components

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sharonn.poppy.ui.theme.dark_oncustom_color_2
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary


@Composable
fun EntityStringDataColumn(
    dataTitle: String,
    data: String,
    modifier: Modifier = Modifier,
    textAlign: TextAlign = TextAlign.Center,
    textColor: Color = md_theme_light_onPrimary,
    canCopy: Boolean = false,
    context: Context? = null
) {
    Column(
        modifier = Modifier.padding(5.dp),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(
            text = dataTitle,
            textAlign = textAlign,
            style = TextStyle(
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Normal,
                color = dark_oncustom_color_2
            ),
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (data.isNotEmpty()) {
                Text(
                    text = data,
                    textAlign = TextAlign.Justify,
                    style = TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontStyle = FontStyle.Normal,
                        color = textColor
                    ),
                    modifier = modifier.weight(1f),
                    overflow = TextOverflow.Ellipsis,
                    maxLines = if (canCopy) 1 else Int.MAX_VALUE
                )
            }

            if (canCopy && data.isNotEmpty() && data.lowercase() != "null") {
                val clipboardManager: ClipboardManager = LocalClipboardManager.current

                IconButton(onClick = {
                    clipboardManager.setText(AnnotatedString((data)))
                }) {
                    Icon(
                        modifier = Modifier.size(30.dp),
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = "Copy data icon",
                        tint = Color.White
                    )
                }
            }
        }
    }
}
