package com.sharonn.poppy.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.Face2
import androidx.compose.material.icons.rounded.LocalFlorist
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.sharonn.poppy.R
import com.sharonn.poppy.utils.AvailableScreens
import com.sharonn.poppy.utils.EntityType
import com.sharonn.poppy.ui.model.AnimeItemUI
import com.sharonn.poppy.ui.model.CharacterItemUI
import com.sharonn.poppy.ui.model.MangaItemUI
import com.sharonn.poppy.ui.theme.md_theme_dark_onSecondary
import com.sharonn.poppy.ui.theme.md_theme_dark_primaryContainer
import com.sharonn.poppy.ui.theme.md_theme_dark_secondary


@Composable
fun HomeListComponent(
    listTitle: String,
    entityType: EntityType,
    animes: List<AnimeItemUI.Item>? = null,
    mangas: List<MangaItemUI.Item>? = null,
    characters: List<CharacterItemUI.Item>? = null,
    context: Context,
    navController: NavController = rememberNavController()
) {
    var imageVector = Icons.Rounded.LocalFlorist
    var seeAllRoute: String

    when (entityType) {
        EntityType.ANIME -> {
            imageVector = Icons.Rounded.VideoLibrary
            seeAllRoute = ""
        }

        EntityType.MANGA -> {
            imageVector = Icons.Rounded.Book
            seeAllRoute = ""
        }

        EntityType.CHARACTER -> {
            imageVector = Icons.Rounded.Face2
            seeAllRoute = ""
        }

        else -> {}
    }

    seeAllRoute = AvailableScreens.LIBRARY_SCREEN.getScreenIdentification()

    Column(
        modifier = Modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(md_theme_dark_secondary)
                .topBorder(3.dp, md_theme_dark_onSecondary)
                .bottomBorder(3.dp, md_theme_dark_onSecondary),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .background(color = Color.Transparent)
                    .padding(start = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = imageVector,
                    contentDescription = "",
                    tint = md_theme_dark_primaryContainer
                )

                Spacer(modifier = Modifier.size(ButtonDefaults.IconSpacing))

                Text(
                    text = listTitle,
                    modifier = Modifier,
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 35.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            TextButton(onClick = {
                navController.navigate(seeAllRoute)
            }) {
                Text(
                    text = stringResource(id = R.string.see_all_text),
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        if (entityType == EntityType.ANIME) {
            if (animes.isNullOrEmpty()) {
                NoDataComponent()
            } else {
                EntityHorizontalList(
                    animes = animes,
                    context = context
                )
            }
        } else if (entityType == EntityType.MANGA) {
            if (mangas.isNullOrEmpty()) {
                NoDataComponent()
            } else {
                EntityHorizontalList(
                    mangas = mangas,
                    context = context
                )
            }
        } else if (entityType == EntityType.CHARACTER) {
            if (characters.isNullOrEmpty()) {
                NoDataComponent()
            } else {
                EntityHorizontalList(
                    characters = characters,
                    context = context
                )
            }
        } else {
            NoDataComponent()
        }
    }
}
