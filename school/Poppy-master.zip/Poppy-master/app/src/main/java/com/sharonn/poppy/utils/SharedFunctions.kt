package com.sharonn.poppy.utils

import com.sharonn.poppy.ui.viewmodel.AnimeViewModel
import com.sharonn.poppy.ui.viewmodel.CharacterViewModel
import com.sharonn.poppy.ui.viewmodel.MangaViewModel
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class SharedFunctions {
    companion object {
        fun fromListToString(list: List<String?>, separator: String = ","): String {
            if (list.isEmpty()) {
                return ""
            }

            return list.joinToString(separator = separator)
        }

        fun fromStringToList(value: String?, delimiter: String = ","): List<String> {
            if (value.isNullOrEmpty()) {
                return emptyList()
            }

            return value.split(delimiter, ignoreCase = true)
        }

        fun formatFromToPeriod(value: String?, delimiter: Char = 'T'): String? {
            return value?.replace(Regex("$delimiter(.)*"), "")
        }

        fun addEntity(
            entityType: EntityType,
            animeViewModel: AnimeViewModel,
            mangaViewModel: MangaViewModel,
            characterViewModel: CharacterViewModel,
            onError: () -> Unit
        ) {
            when (entityType) {
                EntityType.ANIME -> {
                    animeViewModel.addAnime(onError = onError)
                }

                EntityType.MANGA -> {
                    mangaViewModel.addManga(onError = onError)
                }

                EntityType.CHARACTER -> {
                    characterViewModel.addCharacter(onError = onError)
                }

                else -> {}
            }
        }

        fun updateEntityIsFavorite(
            animeViewModel: AnimeViewModel,
            mangaViewModel: MangaViewModel,
            characterViewModel: CharacterViewModel,
            entityType: EntityType,
            entityId: Long,
            isFavorite: Boolean,
            onError: () -> Unit
        ) {
            when (entityType) {
                EntityType.ANIME -> {
                    animeViewModel.updateAnimeIsFavorite(
                        value = isFavorite,
                        animeId = entityId,
                        onError = onError
                    )
                }

                EntityType.MANGA -> {
                    mangaViewModel.updateMangaIsFavorite(
                        value = isFavorite,
                        mangaId = entityId,
                        onError = onError
                    )
                }

                EntityType.CHARACTER -> {
                    characterViewModel.updateCharacterIsFavorite(
                        value = isFavorite,
                        characterId = entityId,
                        onError = onError
                    )
                }

                else -> {}
            }
        }

        fun deleteAllEntity(
            entityType: EntityType,
            animeViewModel: AnimeViewModel,
            mangaViewModel: MangaViewModel,
            characterViewModel: CharacterViewModel,
            onError: () -> Unit
        ) {
            when (entityType) {
                EntityType.ANIME -> {
                    animeViewModel.deleteAllAnimes(onError = onError)
                }

                EntityType.MANGA -> {
                    mangaViewModel.deleteAllMangas(onError = onError)
                }

                EntityType.CHARACTER -> {
                    characterViewModel.deleteAllCharacters(onError = onError)
                }

                else -> {}
            }
        }

        fun pictureDefaultFilename(): String {
            return "poppy_image_${
                DateTimeFormatter.ofPattern(
                    "dd-MM-yyyy_HH-mm-ss",
                    java.util.Locale.getDefault()
                ).format(LocalDateTime.now())
            }.jpeg"
        }
    }
}