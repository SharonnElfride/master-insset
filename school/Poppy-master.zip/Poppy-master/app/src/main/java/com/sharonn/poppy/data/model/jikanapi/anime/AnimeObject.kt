package com.sharonn.poppy.data.model.jikanapi.anime

data class AnimeObject(
    val animeId: Long,
    val userId: String,
    val animeUrl: String,
    val imageUrl: String? = null,
    val smallImageUrl: String? = null,
    val approvedByMal: Boolean,
    val trailerUrl: String? = null,
    val animeTitle: String,
    val animeKanjiTitle: String? = null,
    val animeOtherTitles: String? = null,
    val animeType: String? = null,
    val animeSource: String? = null,
    val animeEpisodes: Int? = null,
    val animeStatus: String? = null,
    val animeAiringStatus: Boolean,
    val animeAiringPeriodFrom: String? = null,
    val animeAiringPeriodTo: String? = null,
    val animeDuration: String? = null,
    val animeRating: String? = null,
    val animeMalScore: Float? = null,
    val animeMalRank: Int? = null,
    val animeMalPopularity: Int? = null,
    val animeSynopsis: String? = null,
    val animeBackground: String? = null,
    val animeProducers: String? = null,
    val animeStudios: String? = null,
    val animeGenres: String? = null,
    val animeExplicitGenres: String? = null,
    val animeThemes: String? = null,
    val animeDemographics: String? = null,
    val createdDate: String,
    val createdTime: String,
    val isFavorite: Boolean = false
)

fun List<AnimeEntity>.toDomain(): List<AnimeObject> {
    return map { entity ->
        entity.toDomainSingle()
    }
}

fun AnimeEntity.toDomainSingle(): AnimeObject {
    return AnimeObject(
        animeId = id,
        userId = userId,
        animeUrl = animeUrl,
        imageUrl = imageUrl,
        smallImageUrl = smallImageUrl,
        approvedByMal = approvedByMal,
        trailerUrl = trailerUrl,
        animeTitle = animeTitle,
        animeKanjiTitle = animeKanjiTitle,
        animeOtherTitles = animeOtherTitles,
        animeType = animeType,
        animeSource = animeSource,
        animeEpisodes = animeEpisodes,
        animeStatus = animeStatus,
        animeAiringStatus = animeAiringStatus,
        animeAiringPeriodFrom = animeAiringPeriodFrom,
        animeAiringPeriodTo = animeAiringPeriodTo,
        animeDuration = animeDuration,
        animeRating = animeRating,
        animeMalScore = animeMalScore,
        animeMalRank = animeMalRank,
        animeMalPopularity = animeMalPopularity,
        animeSynopsis = animeSynopsis,
        animeBackground = animeBackground,
        animeProducers = animeProducers,
        animeStudios = animeStudios,
        animeGenres = animeGenres,
        animeExplicitGenres = animeExplicitGenres,
        animeThemes = animeThemes,
        animeDemographics = animeDemographics,
        createdDate = createdDate,
        createdTime = createdTime,
        isFavorite = isFavorite
    )
}

