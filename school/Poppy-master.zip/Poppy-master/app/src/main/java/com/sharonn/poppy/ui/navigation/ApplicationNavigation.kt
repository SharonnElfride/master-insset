package com.sharonn.poppy.ui.navigation

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.result.ActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.paint
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.LifecycleCoroutineScope
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth
import com.sharonn.poppy.R
import com.sharonn.poppy.data.firebase.FirebaseAuthUiClient
import com.sharonn.poppy.data.firebase.GoogleAuthUiClient
import com.sharonn.poppy.data.firebase.SharedAuthFunctions
import com.sharonn.poppy.utils.AvailableScreens
import com.sharonn.poppy.utils.VISUALIZE_ANIME
import com.sharonn.poppy.utils.VISUALIZE_CHARACTER
import com.sharonn.poppy.utils.VISUALIZE_IMAGE
import com.sharonn.poppy.utils.VISUALIZE_MANGA
import com.sharonn.poppy.utils.VISUALIZE_NOTE
import com.sharonn.poppy.ui.screen.ErrorScreen
import com.sharonn.poppy.ui.screen.FavoriteScreen
import com.sharonn.poppy.ui.screen.GetStartedScreen
import com.sharonn.poppy.ui.screen.HomeScreen
import com.sharonn.poppy.ui.screen.LibraryScreen
import com.sharonn.poppy.ui.screen.LoginScreen
import com.sharonn.poppy.ui.screen.NoteScreen
import com.sharonn.poppy.ui.screen.ProfileScreen
import com.sharonn.poppy.ui.screen.SecretGalleryScreen
import com.sharonn.poppy.ui.screen.SignUpScreen
import com.sharonn.poppy.ui.screen.VisualizeSingleAnimeScreen
import com.sharonn.poppy.ui.screen.VisualizeSingleCharacterScreen
import com.sharonn.poppy.ui.screen.VisualizeSingleImageScreen
import com.sharonn.poppy.ui.screen.VisualizeSingleMangaScreen
import com.sharonn.poppy.ui.screen.VisualizeSingleNoteScreen
import com.sharonn.poppy.ui.state.SignInState
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import kotlinx.coroutines.launch


fun NavGraphBuilder.addGetStartedScreenNavigation(
    onGetStartedButtonClick: () -> Unit,
) {
    composable(
        route = AvailableScreens.GET_STARTED_SCREEN.getScreenIdentification()
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
        ) {
            GetStartedScreen(
                onGetStartedButtonClick = { onGetStartedButtonClick() }
            )
        }
    }
}

fun NavGraphBuilder.addLoginScreenNavigation(
    state: SignInState,
    onLoginWithGoogleButtonClick: () -> Unit,
    onSignUpButtonClick: () -> Unit,
    onLetsGoButtonClick: () -> Unit,
    firebaseAuthUiClient: FirebaseAuthUiClient,
    lifecycleScope: LifecycleCoroutineScope,
) {
    composable(
        route = AvailableScreens.LOG_IN_SCREEN.getScreenIdentification()
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .paint(
                    painter = painterResource(id = R.drawable.get_started_background),
                    contentScale = ContentScale.FillBounds
                )
        ) {
            LoginScreen(
                state = state,
                onLoginWithGoogleButtonClick = onLoginWithGoogleButtonClick,
                onSignUpButtonClick = onSignUpButtonClick,
                onLetsGoButtonClick = onLetsGoButtonClick,
                firebaseAuthUiClient = firebaseAuthUiClient,
                lifecycleScope = lifecycleScope,
            )
        }
    }
}

fun NavGraphBuilder.addSignUpScreenNavigation(
    state: SignInState,
    onLetsGoButtonClick: () -> Unit,
    onLoginWithGoogleButtonClick: () -> Unit,
    onSignInButtonClick: () -> Unit,
    firebaseAuthUiClient: FirebaseAuthUiClient,
    lifecycleScope: LifecycleCoroutineScope,
) {
    composable(
        route = AvailableScreens.SIGN_UP_SCREEN.getScreenIdentification()
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .paint(
                    painter = painterResource(id = R.drawable.get_started_background),
                    contentScale = ContentScale.FillBounds
                )
        ) {
            SignUpScreen(
                state = state,
                onLetsGoButtonClick = onLetsGoButtonClick,
                onLoginWithGoogleButtonClick = onLoginWithGoogleButtonClick,
                onSignInButtonClick = onSignInButtonClick,
                firebaseAuthUiClient = firebaseAuthUiClient,
                lifecycleScope = lifecycleScope,
            )
        }
    }
}

fun NavGraphBuilder.addHomeScreenNavigation(
    context: Context,
    navController: NavController
) {
    composable(
        route = AvailableScreens.HOME_SCREEN.getScreenIdentification()
    ) {
        Surface(
            modifier = Modifier
                .background(dark_custom_color_2)
                .fillMaxSize()
        ) {
            HomeScreen(
                context = context,
                navController = navController
            )
        }
    }
}

fun NavGraphBuilder.addProfileScreenNavigation(
    context: Context,
    googleAuthUiClient: GoogleAuthUiClient,
    lifecycleScope: LifecycleCoroutineScope,
    navController: NavController,
) {
    composable(
        route = AvailableScreens.PROFILE_SCREEN.getScreenIdentification()
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(dark_custom_color_2)
        ) {
            val successSignOut = stringResource(id = R.string.signed_out_successful)
            val successAccountDeletion =
                "${stringResource(id = R.string.account_deletion_caption)} ${
                    stringResource(
                        id = R.string.successful_caption
                    )
                }"

            val errorMessage = stringResource(id = R.string.an_error_occurred_caption)

            ProfileScreen(
                userData = SharedAuthFunctions.getSignedInUser(),
                onSignOut = {
                    lifecycleScope.launch {
                        SharedAuthFunctions.signOutUser(
                            oneTapClient = googleAuthUiClient.publicOneTapClient,
                        )

                        Toast.makeText(
                            context,
                            successSignOut,
                            Toast.LENGTH_SHORT
                        ).show()

                        navController.popBackStack(
                            route = AvailableScreens.GET_STARTED_SCREEN.getScreenIdentification(),
                            inclusive = false
                        )
                    }
                },
                onAccountDeletionRequest = {
                    lifecycleScope.launch {
                        SharedAuthFunctions.deleteUserAccount(
                            oneTapClient = googleAuthUiClient.publicOneTapClient,
                            onError = {
                                Toast.makeText(
                                    context,
                                    errorMessage,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )

                        Toast.makeText(
                            context,
                            successAccountDeletion,
                            Toast.LENGTH_SHORT
                        ).show()

                        navController.popBackStack(
                            route = AvailableScreens.GET_STARTED_SCREEN.getScreenIdentification(),
                            inclusive = false
                        )
                    }
                },
                onNotesButtonClick = {
                    navController.navigate(AvailableScreens.NOTES_SCREEN.getScreenIdentification())
                }
            )
        }
    }
}

fun NavGraphBuilder.addLibraryScreenNavigation(
    context: Context,
    navController: NavController
) {
    composable(
        route = AvailableScreens.LIBRARY_SCREEN.getScreenIdentification()
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            LibraryScreen(
                context = context,
                navController = navController
            )
        }
    }
}

fun NavGraphBuilder.addSecretGalleryScreenNavigation(
    context: Context,
    navController: NavController
) {
    composable(
        route = AvailableScreens.SECRET_GALLERY_SCREEN.getScreenIdentification()
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            SecretGalleryScreen(
                context = context,
                navController = navController
            )
        }
    }
}

fun NavGraphBuilder.addFavoriteScreenNavigation(
    context: Context,
    navController: NavController
) {
    composable(
        route = AvailableScreens.FAVORITE_SCREEN.getScreenIdentification()
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            FavoriteScreen(
                context = context,
                navController = navController
            )
        }
    }
}

fun NavGraphBuilder.addNoteScreenNavigation(
    context: Context,
    navController: NavController,
    noteIdsToDelete: MutableList<String>
) {
    composable(
        route = AvailableScreens.NOTES_SCREEN.getScreenIdentification()
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            NoteScreen(
                context = context,
                navController = navController,
                noteIdsToDelete = noteIdsToDelete
            )
        }
    }
}

fun NavGraphBuilder.addVisualizeSingleImageScreenNavigation(
    context: Context,
) {
    composable(
        route = "${AvailableScreens.VISUALIZE_SINGLE_IMAGE_SCREEN.getScreenIdentification()}/{$VISUALIZE_IMAGE}",
    ) { navBackStackEntry ->
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            /* Extracting the id from the route */
            val imageId = navBackStackEntry.arguments?.getString(VISUALIZE_IMAGE)
            imageId?.let {
                VisualizeSingleImageScreen(
                    context = context,
                    pictureId = imageId.toLong()
                )
            }
        }
    }
}

fun NavGraphBuilder.addVisualizeSingleAnimeScreenNavigation(
    context: Context,
) {
    composable(
        route = "${AvailableScreens.VISUALIZE_SINGLE_ANIME_SCREEN.getScreenIdentification()}/{$VISUALIZE_ANIME}",
    ) { navBackStackEntry ->
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            val animeId = navBackStackEntry.arguments?.getString(VISUALIZE_ANIME)
            animeId?.let {
                VisualizeSingleAnimeScreen(
                    context = context,
                    animeId = animeId.toLong()
                )
            }
        }
    }
}

fun NavGraphBuilder.addVisualizeSingleMangaScreenNavigation(
    context: Context,
) {
    composable(
        route = "${AvailableScreens.VISUALIZE_SINGLE_MANGA_SCREEN.getScreenIdentification()}/{$VISUALIZE_MANGA}",
    ) { navBackStackEntry ->
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            val mangaId = navBackStackEntry.arguments?.getString(VISUALIZE_MANGA)
            mangaId?.let {
                VisualizeSingleMangaScreen(
                    context = context,
                    mangaId = mangaId.toLong()
                )
            }
        }
    }
}

fun NavGraphBuilder.addVisualizeSingleCharacterScreenNavigation(
    context: Context,
) {
    composable(
        route = "${AvailableScreens.VISUALIZE_SINGLE_CHARACTER_SCREEN.getScreenIdentification()}/{$VISUALIZE_CHARACTER}",
    ) { navBackStackEntry ->
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            val characterId = navBackStackEntry.arguments?.getString(VISUALIZE_CHARACTER)
            characterId?.let {
                VisualizeSingleCharacterScreen(
                    context = context,
                    characterId = it.toLong()
                )
            }
        }
    }
}

fun NavGraphBuilder.addVisualizeSingleNoteScreenNavigation(
    context: Context,
) {
    composable(
        route = "${AvailableScreens.VISUALIZE_SINGLE_NOTE_SCREEN.getScreenIdentification()}/{$VISUALIZE_NOTE}",
    ) { navBackStackEntry ->
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            val noteId = navBackStackEntry.arguments?.getString(VISUALIZE_NOTE)
            noteId?.let {
                VisualizeSingleNoteScreen(
                    context = context,
                    noteId = it
                )
            }
        }
    }
}

fun NavGraphBuilder.addErrorScreenNavigation(
    context: Context,
    onActionButtonClick: () -> Unit
) {
    composable(
        route = AvailableScreens.ERROR_SCREEN.getScreenIdentification(),
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            ErrorScreen(
                context = context,
                onActionButtonClick = onActionButtonClick
            )
        }
    }
}

@Composable
fun AppNavHost(
    state: SignInState,
    navController: NavHostController = rememberNavController(),
    googleAuthUiClient: GoogleAuthUiClient,
    firebaseAuthUiClient: FirebaseAuthUiClient,
    lifecycleScope: LifecycleCoroutineScope,
    launcher: ManagedActivityResultLauncher<IntentSenderRequest, ActivityResult>,
    applicationContext: Context,
    noteIdsToDelete: MutableList<String>
) {
    val currentUser = FirebaseAuth.getInstance().currentUser

    NavHost(
        navController = navController,
        startDestination = AvailableScreens.GET_STARTED_SCREEN.getScreenIdentification(),
    ) {
        // Routes definition
        addGetStartedScreenNavigation(
            onGetStartedButtonClick = {
                navController.navigate(AvailableScreens.LOG_IN_SCREEN.getScreenIdentification())
            }
        )

        addLoginScreenNavigation(
            state = state,
            onLoginWithGoogleButtonClick = {
                lifecycleScope.launch {
                    val signInIntentSender = googleAuthUiClient.signIn()
                    launcher.launch(
                        IntentSenderRequest.Builder(
                            signInIntentSender ?: return@launch
                        ).build()
                    )
                }
            },
            onSignUpButtonClick = {
                navController.navigate(AvailableScreens.SIGN_UP_SCREEN.getScreenIdentification())
            },
            onLetsGoButtonClick = {
                navController.navigate(AvailableScreens.HOME_SCREEN.getScreenIdentification())
            },
            firebaseAuthUiClient = firebaseAuthUiClient,
            lifecycleScope = lifecycleScope,
        )

        addSignUpScreenNavigation(
            state = state,
            onLoginWithGoogleButtonClick = {
                lifecycleScope.launch {
                    val signInIntentSender = googleAuthUiClient.signIn()
                    launcher.launch(
                        IntentSenderRequest.Builder(
                            signInIntentSender ?: return@launch
                        ).build()
                    )
                }
            },
            onLetsGoButtonClick = {
                navController.navigate(AvailableScreens.HOME_SCREEN.getScreenIdentification())
            },
            onSignInButtonClick = {
                navController.popBackStack(
                    route = AvailableScreens.LOG_IN_SCREEN.getScreenIdentification(),
                    inclusive = false
                )
            },
            firebaseAuthUiClient = firebaseAuthUiClient,
            lifecycleScope = lifecycleScope,
        )

        addHomeScreenNavigation(
            context = applicationContext,
            navController = navController
        )

        addProfileScreenNavigation(
            context = applicationContext,
            googleAuthUiClient = googleAuthUiClient,
            lifecycleScope = lifecycleScope,
            navController = navController,
        )

        addLibraryScreenNavigation(
            context = applicationContext,
            navController = navController
        )

        addSecretGalleryScreenNavigation(
            context = applicationContext,
            navController = navController
        )

        addFavoriteScreenNavigation(
            context = applicationContext,
            navController = navController
        )

        addNoteScreenNavigation(
            context = applicationContext,
            navController = navController,
            noteIdsToDelete = noteIdsToDelete
        )

        addVisualizeSingleImageScreenNavigation(
            context = applicationContext,
        )

        addVisualizeSingleAnimeScreenNavigation(
            context = applicationContext
        )

        addVisualizeSingleMangaScreenNavigation(
            context = applicationContext
        )

        addVisualizeSingleCharacterScreenNavigation(
            context = applicationContext
        )

        addVisualizeSingleNoteScreenNavigation(
            context = applicationContext
        )

        addErrorScreenNavigation(
            context = applicationContext,
            onActionButtonClick = {
                if (currentUser != null) {
                    val canPopBack = navController.popBackStack(
                        route = AvailableScreens.HOME_SCREEN.getScreenIdentification(),
                        inclusive = false
                    )

                    if (!canPopBack) {
                        navController.navigate(
                            route = AvailableScreens.HOME_SCREEN.getScreenIdentification(),
                        )
                    }
                } else {
                    val canPopBack = navController.popBackStack(
                        route = AvailableScreens.GET_STARTED_SCREEN.getScreenIdentification(),
                        inclusive = false
                    )

                    if (!canPopBack) {
                        navController.navigate(
                            route = AvailableScreens.GET_STARTED_SCREEN.getScreenIdentification(),
                        )
                    }
                }
            }
        )
    }
}
