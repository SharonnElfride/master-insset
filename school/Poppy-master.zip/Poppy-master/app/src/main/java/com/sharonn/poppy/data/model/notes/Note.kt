package com.sharonn.poppy.data.model.notes

data class Note(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val content: String = "",
    val entityId: String = "0",
    val entityDenomination: String = "",
    val entityType: String = "",
    val imageUrl: String = "",
    val createdOn: String = "",
    val lastUpdatedOn: String = ""
)
