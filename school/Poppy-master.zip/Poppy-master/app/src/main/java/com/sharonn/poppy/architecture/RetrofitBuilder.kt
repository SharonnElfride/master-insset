package com.sharonn.poppy.architecture

import com.google.gson.GsonBuilder
import com.sharonn.poppy.utils.JIKAN_API_BASE_URL
import com.sharonn.poppy.utils.NEKOS_API_BASE_URL
import com.sharonn.poppy.jikanAnimeManga.remote.AnimeMangaCharactersEndpoint
import com.sharonn.poppy.nekosPicture.remote.AnimePictureEndpoint
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitBuilder {
    // Anime/Manga/Character API
    private val jikanRetrofit: Retrofit = Retrofit.Builder()
        .baseUrl(JIKAN_API_BASE_URL)
        .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
        .build()

    fun getAnimeMangaCharacter(): AnimeMangaCharactersEndpoint =
        jikanRetrofit.create(AnimeMangaCharactersEndpoint::class.java)


    // Nekos pics API
    private val nekosRetrofit: Retrofit = Retrofit.Builder()
        .baseUrl(NEKOS_API_BASE_URL)
        .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
        .build()

    fun getAnimePictures(): AnimePictureEndpoint =
        nekosRetrofit.create(AnimePictureEndpoint::class.java)
}