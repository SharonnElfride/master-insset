package com.sharonn.poppy.ui.components

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sharonn.poppy.R
import com.sharonn.poppy.ui.theme.dark_oncustom_color_2
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.theme.md_theme_light_surface


@Composable
fun GoogleAccessComponent(
    context: Context,
    onLoginWithGoogleButtonClick: () -> Unit
) {
    Column(
        modifier = Modifier,
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val imageVector = ImageVector.vectorResource(id = R.drawable.icon_google_material_filled_48)
        AuthenticationButtonComponent(
            imageVector = imageVector,
            value = context.getString(R.string.google_log_in_button_text),
            onClickButton = onLoginWithGoogleButtonClick
        )

        Text(
            text = context.getString(R.string.login_more_auth_methods_comming),
            style = TextStyle(
                fontSize = 15.sp,
                fontWeight = FontWeight.Light,
                fontStyle = FontStyle.Normal,
                color = Color.DarkGray
            ),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .background(color = md_theme_light_surface, shape = RoundedCornerShape(6.dp))
                .padding(8.dp)
        )
    }
}

@Composable
fun ManageAuthScreenComponent(
    initialText: String,
    clickableText: String,
    onTextClick: () -> Unit
) {
    val annotatedString = buildAnnotatedString {
        withStyle(
            style = SpanStyle(color = Color.White, fontSize = 15.sp)
        ) {
            append("$initialText ")
        }
        withStyle(
            style = SpanStyle(color = dark_oncustom_color_2, fontSize = 15.sp)
        ) {
            pushStringAnnotation(
                tag = clickableText,
                annotation = clickableText
            )
            append(clickableText)
        }
    }

    ClickableText(text = annotatedString, onClick = { offset ->
        annotatedString.getStringAnnotations(offset, offset)
            .firstOrNull()?.also { onTextClick() }
    })
}

@Composable
fun AuthenticationButtonComponent(
    imageVector: ImageVector? = null,
    iconSize: Dp = 25.dp,
    value: String,
    onClickButton: () -> Unit
) {
    Button(
        modifier = Modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = md_theme_light_primary,
            contentColor = md_theme_light_onPrimary
        ),
        content = {
            if (imageVector != null) {
                Image(
                    imageVector = imageVector,
                    modifier = Modifier
                        .size(iconSize),
                    contentDescription = "$value button icon",
                    colorFilter = ColorFilter.tint(md_theme_light_onPrimary)
                )

                Spacer(Modifier.size(ButtonDefaults.IconSpacing))
            }

            Text(
                text = value,
                style = TextStyle(
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontStyle = FontStyle.Normal,
                    color = md_theme_light_onPrimary
                ),
                textAlign = TextAlign.Center,
            )
        },
        onClick = onClickButton,
        shape = RoundedCornerShape(25.dp)
    )
}
