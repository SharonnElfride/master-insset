package com.sharonn.poppy.ui.screen

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.sharonn.poppy.R
import com.sharonn.poppy.utils.SharedFunctions
import com.sharonn.poppy.ui.components.EntityDataCheckbox
import com.sharonn.poppy.ui.components.EntityListDataColumn
import com.sharonn.poppy.ui.components.EntityStringDataColumn
import com.sharonn.poppy.ui.components.EntityStringDataRow
import com.sharonn.poppy.ui.components.NoDataComponent
import com.sharonn.poppy.ui.components.StarRatingBar
import com.sharonn.poppy.ui.model.MangaItemUI
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.dark_oncustom_color_2
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.viewmodel.MangaViewModel
import com.sharonn.poppy.ui.viewmodel.NoteViewModel


@Composable
fun VisualizeSingleMangaScreen(
    context: Context,
    mangaId: Long? = null
) {
    val mangaViewModel: MangaViewModel = viewModel()
    val errorMessage = stringResource(id = R.string.error_retrieving_item)
    val selectedImage = stringResource(id = R.string.selected_image_text)
    val brokenImage = stringResource(id = R.string.broken_image_text)

    val noteViewModel: NoteViewModel = viewModel()

    var manga: MangaItemUI.Item? = null
    if (mangaId != null) {
        manga = mangaViewModel.getSingleManga(
            mangaId = mangaId,
            onError = {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(
                        context,
                        errorMessage,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        ) as MangaItemUI.Item
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = md_theme_light_primary)
            .padding(top = 10.dp)
            .clip(shape = RoundedCornerShape(15.dp, 15.dp, 0.dp, 0.dp))
            .background(color = dark_custom_color_2)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (manga != null) {
            val imageUrl = manga.imageUrl
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (imageUrl != null) {
                    AsyncImage(
                        model = imageUrl,
                        contentScale = ContentScale.Crop,
                        contentDescription = selectedImage,
                        error = painterResource(R.drawable.round_broken_image_white_24),
                        placeholder = painterResource(R.drawable.loading),
                        modifier = Modifier
                            .size(width = 150.dp, height = 200.dp)
                            .clip(RoundedCornerShape(8.dp)),
                    )
                } else {
                    Image(
                        imageVector = Icons.Rounded.BrokenImage,
                        contentDescription = brokenImage,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(width = 150.dp, height = 200.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.SpaceEvenly,
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = manga.mangaTitle,
                        textAlign = TextAlign.Start,
                        style = TextStyle(
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold,
                            fontStyle = FontStyle.Normal,
                            color = dark_oncustom_color_2
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    EntityStringDataRow(
                        dataTitle = "${stringResource(id = R.string.kanji_title_attribute)}:",
                        data = manga.mangaKanjiTitle ?: ""
                    )

                    val titles = SharedFunctions.fromStringToList(manga.mangaOtherTitles)
                    val otherTitles = SharedFunctions.fromListToString(titles, " / ")

                    EntityStringDataColumn(
                        dataTitle = stringResource(id = R.string.other_titles_attribute),
                        data = otherTitles
                    )

                    EntityStringDataRow(
                        dataTitle = "${stringResource(id = R.string.type_attribute)}:",
                        data = manga.mangaType ?: ""
                    )
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                val score = manga.mangaMalScore ?: 0f
                StarRatingBar(rating = score, spaceBetween = 3.dp)

                val addedOnText = stringResource(id = R.string.added_on_text)
                Text(
                    text = "$addedOnText ${manga.createdDate} ${manga.createdTime}",
                    textAlign = TextAlign.Center,
                    style = TextStyle(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Normal,
                        color = md_theme_light_onPrimary
                    ),
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.synopsis_attribute),
                    data = manga.mangaSynopsis ?: ""
                )
                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.background_attribute),
                    data = manga.mangaBackground ?: ""
                )

                EntityDataCheckbox(
                    checkValue = manga.approvedByMal,
                    checkTitle = stringResource(id = R.string.approved_by_mal_attribute)
                )

                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.mal_link_attribute),
                    data = manga.mangaUrl,
                    canCopy = true,
                    context = context
                ) // can be copied

                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.status_attribute),
                    data = manga.mangaStatus ?: ""
                )

                EntityDataCheckbox(
                    checkValue = manga.mangaPublishingStatus,
                    checkTitle = stringResource(id = R.string.publishing_status_attribute)
                )

                val from = manga.mangaPublishingPeriodFrom ?: ""
                val to = manga.mangaPublishingPeriodTo ?: ""

                val fromTo: String = if (from.isEmpty()) {
                    stringResource(id = R.string.not_specified_text)
                } else {
                    "${stringResource(id = R.string.period_from)} $from ${stringResource(id = R.string.period_to)} $to"
                }

                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.publishing_period_attribute),
                    data = fromTo
                )

                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.chapters_attribute),
                    data = manga.mangaChapters?.toString() ?: ""
                )

                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.volumes_attribute),
                    data = manga.mangaVolumes?.toString() ?: ""
                )

                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.mal_rank_attribute),
                    data = "N° ${manga.mangaMalRank ?: ""}"
                )

                EntityStringDataColumn(
                    dataTitle = stringResource(id = R.string.mal_popularity_attribute),
                    data = "N° ${manga.mangaMalPopularity ?: ""}"
                )

                EntityListDataColumn(
                    dataTitle = stringResource(id = R.string.authors_attribute),
                    data = manga.mangaAuthors
                )

                val serializations =
                    SharedFunctions.fromStringToList(value = manga.mangaSerializations)
                EntityListDataColumn(
                    dataTitle = stringResource(id = R.string.serializations_attribute),
                    data = serializations
                )

                val genres = SharedFunctions.fromStringToList(value = manga.mangaGenres)
                EntityListDataColumn(
                    dataTitle = stringResource(id = R.string.genres_attribute),
                    data = genres
                )

                val explicitGenres =
                    SharedFunctions.fromStringToList(value = manga.mangaExplicitGenres)
                EntityListDataColumn(
                    dataTitle = stringResource(id = R.string.explicit_genres_attribute),
                    data = explicitGenres
                )

                val themes = SharedFunctions.fromStringToList(value = manga.mangaThemes)
                EntityListDataColumn(
                    dataTitle = stringResource(id = R.string.themes_attribute),
                    data = themes
                )

                val demographics = SharedFunctions.fromStringToList(value = manga.mangaDemographics)
                EntityListDataColumn(
                    dataTitle = stringResource(id = R.string.demographics_attribute),
                    data = demographics
                )

                val existingNotes =
                    noteViewModel.countNotes(linkedEntityId = manga.mangaId.toString())
                        .collectAsState(0).value ?: 0
                val existingNotesCount = pluralStringResource(
                    id = R.plurals.number_of_existing_notes,
                    count = existingNotes,
                    existingNotes,
                )

                EntityStringDataRow(
                    dataTitle = "${stringResource(id = R.string.notes_title)}:",
                    data = stringResource(
                        id = R.string.existing_notes_manga,
                        existingNotesCount
                    )
                )

                if (manga.imageUrl != null) {
                    AsyncImage(
                        model = manga.imageUrl,
                        contentScale = ContentScale.Crop,
                        contentDescription = selectedImage,
                        error = painterResource(R.drawable.round_broken_image_white_24),
                        placeholder = painterResource(R.drawable.loading),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .align(Alignment.CenterHorizontally),
                    )
                }

                Text(
                    text = "MangaId = $mangaId",
                    textAlign = TextAlign.Center,
                    style = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Normal,
                        color = md_theme_light_onPrimary
                    ),
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(10.dp)
                )
            }
        } else {
            NoDataComponent()
        }
    }
}
