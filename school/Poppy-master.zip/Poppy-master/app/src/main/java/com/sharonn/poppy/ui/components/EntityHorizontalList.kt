package com.sharonn.poppy.ui.components

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import com.sharonn.poppy.ui.model.AnimeItemUI
import com.sharonn.poppy.ui.model.CharacterItemUI
import com.sharonn.poppy.ui.model.MangaItemUI


@Composable
fun EntityHorizontalList(
    context: Context,
    animes: List<AnimeItemUI.Item>? = null,
    mangas: List<MangaItemUI.Item>? = null,
    characters: List<CharacterItemUI.Item>? = null
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(8.dp)
    ) {
        if (animes != null) {
            items(animes) { anime ->
                val toastText = "AnimeId = ${anime.animeId}"
                val imageUrl = anime.imageUrl
                val title = anime.animeTitle
                val body = anime.animeSynopsis
                val footer = "${anime.createdDate} ${anime.createdTime}"
                val isFavorite = anime.isFavorite

                EntityCard(
                    toastText = toastText,
                    imageUrl = imageUrl,
                    title = title,
                    body = body,
                    footer = footer,
                    entityIsFavorite = isFavorite,
                    context = context
                )
            }
        }
        if (mangas != null) {
            items(mangas) { manga ->
                val toastText = "MangaId = ${manga.mangaId}"
                val imageUrl = manga.imageUrl
                val title = manga.mangaTitle
                val body = manga.mangaSynopsis
                val footer = "${manga.createdDate} ${manga.createdTime}"
                val isFavorite = manga.isFavorite

                EntityCard(
                    toastText = toastText,
                    imageUrl = imageUrl,
                    title = title,
                    body = body,
                    footer = footer,
                    entityIsFavorite = isFavorite,
                    context = context,
                )
            }
        }
        if (characters != null) {
            items(characters) { character ->
                val toastText = "CharacterId = ${character.characterId}"
                val imageUrl = character.imageUrl
                val title = character.characterName
                val body = character.characterAbout
                val footer = "${character.createdDate} ${character.createdTime}"
                val isFavorite = character.isFavorite

                EntityCard(
                    toastText = toastText,
                    imageUrl = imageUrl,
                    title = title,
                    body = body,
                    footer = footer,
                    entityIsFavorite = isFavorite,
                    context = context,
                )
            }
        }
    }
}
