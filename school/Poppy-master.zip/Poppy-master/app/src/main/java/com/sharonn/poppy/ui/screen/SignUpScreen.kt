package com.sharonn.poppy.ui.screen

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Login
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.paint
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.LifecycleCoroutineScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sharonn.poppy.R
import com.sharonn.poppy.data.firebase.FirebaseAuthUiClient
import com.sharonn.poppy.utils.Validator
import com.sharonn.poppy.ui.components.AuthDivider
import com.sharonn.poppy.ui.components.AuthenticationButtonComponent
import com.sharonn.poppy.ui.components.EmailPasswdField
import com.sharonn.poppy.ui.components.GoogleAccessComponent
import com.sharonn.poppy.ui.components.ManageAuthScreenComponent
import com.sharonn.poppy.ui.state.SignInState
import com.sharonn.poppy.ui.viewmodel.SignInViewModel
import kotlinx.coroutines.launch


@Composable
fun SignUpScreen(
    state: SignInState,
    onLetsGoButtonClick: () -> Unit,
    onLoginWithGoogleButtonClick: () -> Unit,
    onSignInButtonClick: () -> Unit,
    firebaseAuthUiClient: FirebaseAuthUiClient,
    lifecycleScope: LifecycleCoroutineScope,
) {
    val context = LocalContext.current
    val viewModel = viewModel<SignInViewModel>()

    LaunchedEffect(key1 = state.accessAppError) {
        state.accessAppError?.let { error ->
            Toast.makeText(context, error, Toast.LENGTH_LONG).show()
        }
    }

    val successfulSignUpText = stringResource(id = R.string.sign_up_caption) + " " + stringResource(
        id = R.string.successful_caption
    )

    val unsuccessfulSignUpText =
        stringResource(id = R.string.sign_up_caption) + " " + stringResource(
            id = R.string.unsuccessful_caption
        )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .paint(
                painter = painterResource(id = R.drawable.login_background),
                contentScale = ContentScale.FillBounds
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(15.dp)
        ) {
            Text(
                text = stringResource(id = R.string.sign_up_caption),
                textAlign = TextAlign.Start,
                style = TextStyle(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontStyle = FontStyle.Normal,
                    color = Color.White
                ),
            )

            val emailFieldValue = remember { mutableStateOf("") }
            val passwordFieldValue = remember { mutableStateOf("") }
            val confirmPasswordFieldValue = remember { mutableStateOf("") }

            val emailError = remember { mutableStateOf(false) }
            val badPasswordError = remember { mutableStateOf(false) }
            val notSamePasswordError = remember { mutableStateOf(false) }

            EmailPasswdField(
                value = emailFieldValue.value,
                onValueChange = { email ->
                    emailFieldValue.value = email
                },
                label = stringResource(id = R.string.email_caption),
                placeholder = stringResource(id = R.string.email_caption),
                leadingIcon = Icons.Rounded.Email,
                isError = emailError.value,
                errorMessage = stringResource(id = R.string.email_error_message)
            )

            EmailPasswdField(
                value = passwordFieldValue.value,
                onValueChange = { passwd ->
                    passwordFieldValue.value = passwd
                },
                label = stringResource(id = R.string.password_caption),
                placeholder = stringResource(id = R.string.password_caption),
                leadingIcon = Icons.Rounded.VpnKey,
                isPassword = true,
                isError = badPasswordError.value,
                errorMessage = stringResource(id = R.string.password_error_message)
            )

            EmailPasswdField(
                value = confirmPasswordFieldValue.value,
                onValueChange = { passwd ->
                    confirmPasswordFieldValue.value = passwd
                },
                label = stringResource(id = R.string.confirm_password_caption),
                placeholder = stringResource(id = R.string.confirm_password_caption),
                leadingIcon = Icons.Rounded.VpnKey,
                isPassword = true,
                isError = notSamePasswordError.value,
                errorMessage = stringResource(id = R.string.passwords_do_not_correspond),
            )

            AuthenticationButtonComponent(
                imageVector = Icons.Rounded.Login,
                value = context.getString(R.string.access_app_button_text),
                onClickButton = {
                    emailError.value = !Validator.isValidEmail(emailFieldValue.value)
                    badPasswordError.value = !Validator.isValidPassword(passwordFieldValue.value)
                    notSamePasswordError.value =
                        passwordFieldValue.value != confirmPasswordFieldValue.value

                    if (!emailError.value && !badPasswordError.value && !notSamePasswordError.value) {
                        lifecycleScope.launch {
                            val signUpResult = firebaseAuthUiClient.signUpWithEmailAndPassword(
                                email = emailFieldValue.value,
                                password = passwordFieldValue.value
                            )

                            signUpResult.data?.let {
                                onLetsGoButtonClick()

                                Toast.makeText(
                                    context,
                                    successfulSignUpText,
                                    Toast.LENGTH_SHORT
                                ).show()

                                viewModel.resetState()
                            }

                            if (signUpResult.data == null) {
                                Toast.makeText(
                                    context,
                                    unsuccessfulSignUpText,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                }
            )

            ManageAuthScreenComponent(
                initialText = stringResource(id = R.string.already_have_an_account_caption),
                clickableText = stringResource(id = R.string.sign_in_caption),
                onTextClick = onSignInButtonClick
            )

            AuthDivider()

            GoogleAccessComponent(
                context = context,
                onLoginWithGoogleButtonClick = onLoginWithGoogleButtonClick
            )
        }
    }
}

