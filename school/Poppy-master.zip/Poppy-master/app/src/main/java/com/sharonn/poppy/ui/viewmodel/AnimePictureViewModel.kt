package com.sharonn.poppy.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.sharonn.poppy.data.repository.AnimePictureRepository
import com.sharonn.poppy.utils.REPO_ERROR_TAG
import com.sharonn.poppy.ui.model.AnimePictureItemUI
import com.sharonn.poppy.ui.model.toUi
import com.sharonn.poppy.ui.model.toUiSingle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class AnimePictureViewModel : ViewModel() {
    private val animePictureRepository: AnimePictureRepository by lazy { AnimePictureRepository() }

    private val auth = Firebase.auth
    private val userId = auth.currentUser?.uid ?: String()

    private val _pictures: Flow<List<AnimePictureItemUI>>
        get() = animePictureRepository.getAllPictures(userId = userId).map { list ->
            list.toUi()
        }

    val pictures = _pictures

    fun generateRandomPicture(
        categories: List<String>,
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                animePictureRepository.generateRandomPicture(
                    categories = categories,
                    userId = userId
                )
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun getSinglePicture(
        pictureId: Long,
        onError: () -> Unit
    ): AnimePictureItemUI? {
        var picture: AnimePictureItemUI? = null
        try {
            picture = animePictureRepository.getSinglePicture(pictureId = pictureId).toUiSingle()
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d(REPO_ERROR_TAG, e.message.toString())
            onError()
        }

        return picture
    }

    fun deleteAllPictures(
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                animePictureRepository.deleteAll(
                    userId = userId
                )
            } catch (e: Exception) {
                e.printStackTrace()
                onError()
            }
        }
    }

    fun deleteSinglePicture(
        pictureId: Long,
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                animePictureRepository.deleteSinglePicture(
                    pictureId = pictureId
                )
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }
}
