package com.sharonn.poppy.ui.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.DocumentReference
import com.sharonn.poppy.data.model.notes.Note
import com.sharonn.poppy.data.repository.NoteRepository
import com.sharonn.poppy.utils.REPO_ERROR_TAG
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Suppress("UNUSED_EXPRESSION")
class NoteViewModel : ViewModel() {
    private val noteRepository: NoteRepository by lazy { NoteRepository() }

    private val _notes: Flow<List<Note?>>
        get() = noteRepository.getAllNotes()

    val notes = _notes

    fun insertNote(
        entity: Map<String, String?>,
        onSuccessAction: (DocumentReference) -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: (() -> Unit)? = null,
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                noteRepository.insertNote(
                    entity = entity,
                    onSuccessAction = onSuccessAction,
                    onFailureAction = onFailureAction,
                    onCanceledAction = onCanceledAction
                )
            } catch (exception: Exception) {
                exception.printStackTrace()
                Log.d(REPO_ERROR_TAG, exception.message.toString())

                if (exception is CancellationException) throw exception
                null
            }
        }
    }

    private val _note = MutableLiveData<Note>()
    val getNote: LiveData<Note>
        get() = _note

    fun observeNote(
        noteId: String,
        onFailureAction: () -> Unit
    ) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                noteRepository.getNote(
                    noteId = noteId,
                    onFailureAction = onFailureAction
                ).collect {
                    _note.postValue(it)
                }
            }
        }
    }

    fun updateNote(
        note: Note,
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: () -> Unit,
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                noteRepository.updateNote(
                    note,
                    onSuccessAction = onSuccessAction,
                    onFailureAction = onFailureAction,
                    onCanceledAction = onCanceledAction
                )

                observeNote(
                    noteId = note.id,
                    onFailureAction = onFailureAction
                )
            } catch (exception: Exception) {
                exception.printStackTrace()
                Log.d(REPO_ERROR_TAG, exception.message.toString())

                onFailureAction()

                if (exception is CancellationException) throw exception
                null
            }
        }
    }

    fun deleteManyNotes(
        noteIds: List<String>,
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: () -> Unit,
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                noteRepository.deleteManyNotes(
                    entityIds = noteIds,
                    onSuccessAction = onSuccessAction,
                    onFailureAction = onFailureAction,
                    onCanceledAction = onCanceledAction
                )
            } catch (exception: Exception) {
                exception.printStackTrace()
                Log.d(REPO_ERROR_TAG, exception.message.toString())

                onFailureAction()

                if (exception is CancellationException) throw exception
                null
            }
        }
    }

    fun deleteAllNotes(
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: () -> Unit,
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                noteRepository.deleteAllNotesByUserId(
                    onSuccessAction = onSuccessAction,
                    onFailureAction = onFailureAction,
                    onCanceledAction = onCanceledAction
                )
            } catch (exception: Exception) {
                exception.printStackTrace()
                Log.d(REPO_ERROR_TAG, exception.message.toString())

                onFailureAction()

                if (exception is CancellationException) throw exception
                null
            }
        }
    }

    fun updateNotes(
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                noteRepository.getAllNotes().collect().let {
                    onSuccessAction()
                }
            } catch (exception: Exception) {
                exception.printStackTrace()
                Log.d(REPO_ERROR_TAG, exception.message.toString())

                onFailureAction()

                if (exception is CancellationException) throw exception
                null
            }
        }
    }

    fun countNotes(
        linkedEntityId: String
    ): Flow<Int?> {
        return noteRepository.countNotes(
            linkedEntityId = linkedEntityId
        )
    }
}