package com.sharonn.poppy.ui.components

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.Face2
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.Face2
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.sharonn.poppy.R
import com.sharonn.poppy.utils.EntityType
import com.sharonn.poppy.utils.ListType
import com.sharonn.poppy.ui.model.TabItem
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.viewmodel.AnimeViewModel
import com.sharonn.poppy.ui.viewmodel.CharacterViewModel
import com.sharonn.poppy.ui.viewmodel.MangaViewModel
import kotlinx.coroutines.launch


@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryTabComponent(
    context: Context,
    type: ListType? = null,
    navController: NavController = rememberNavController()
) {
    val animeViewModel: AnimeViewModel = viewModel()
    val mangaViewModel: MangaViewModel = viewModel()
    val characterViewModel: CharacterViewModel = viewModel()
    val errorMessage = stringResource(id = R.string.an_error_occurred_caption)

    val tabItems = listOf(
        TabItem(
            title = stringResource(id = R.string.anime_section_title),
            unselectedIcon = Icons.Outlined.VideoLibrary,
            selectedIcon = Icons.Rounded.VideoLibrary,
            entityType = EntityType.ANIME
        ),
        TabItem(
            title = stringResource(id = R.string.manga_section_title),
            unselectedIcon = Icons.Outlined.Book,
            selectedIcon = Icons.Rounded.Book,
            entityType = EntityType.MANGA
        ),
        TabItem(
            title = stringResource(id = R.string.character_section_title),
            unselectedIcon = Icons.Outlined.Face2,
            selectedIcon = Icons.Rounded.Face2,
            entityType = EntityType.CHARACTER
        ),
    )

    var selectedTabIndex by remember {
        mutableIntStateOf(0)
    }

    // remember the pager state
    val pagerState = rememberPagerState {
        tabItems.size
    }

    // coroutine scope
    val coroutineScope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = Color.White,
            contentColor = md_theme_light_primary,
            divider = {
                Divider(
                    modifier = Modifier,
                    thickness = 2.dp,
                    color = Color.Transparent
                )
            },
            indicator = { tabPositions ->
                Box(
                    modifier = Modifier
                        .tabIndicatorOffset(tabPositions[selectedTabIndex])
                        .height(3.dp)
                        .padding(horizontal = 20.dp)
                        .background(
                            color = md_theme_light_primary,
                            shape = RoundedCornerShape(10.dp)
                        )
                )
            },
        ) {
            tabItems.forEachIndexed { index, item ->
                Tab(
                    selected = (index == selectedTabIndex),
                    onClick = {
                        selectedTabIndex = index

                        // change the page when the tab is changed
                        coroutineScope.launch {
                            pagerState.animateScrollToPage(selectedTabIndex)
                        }
                    },
                    text = {
                        Text(text = item.title)
                    },
                    icon = {
                        Icon(
                            imageVector = if (index == selectedTabIndex) item.selectedIcon else item.unselectedIcon,
                            contentDescription = "Content description"
                        )
                    }
                )
            }
        }

        when (tabItems[selectedTabIndex].entityType) {
            EntityType.ANIME -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    if (type != ListType.FAVORITE) {
                        AddDeleteEntityComponent(
                            entityType = EntityType.ANIME,
                            onError = {
                                Handler(Looper.getMainLooper()).post {
                                    Toast.makeText(
                                        context,
                                        errorMessage,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        )
                    }

                    AnimeListComponent(
                        type = type,
                        mangaViewModel = mangaViewModel,
                        characterViewModel = characterViewModel,
                        navController = navController
                    )
                }
            }

            EntityType.MANGA -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    if (type != ListType.FAVORITE) {
                        AddDeleteEntityComponent(
                            entityType = EntityType.MANGA,
                            onError = {
                                Handler(Looper.getMainLooper()).post {
                                    Toast.makeText(
                                        context,
                                        errorMessage,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        )
                    }

                    MangaListComponent(
                        type = type,
                        animeViewModel = animeViewModel,
                        characterViewModel = characterViewModel,
                        navController = navController
                    )
                }

            }

            EntityType.CHARACTER -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    if (type != ListType.FAVORITE) {
                        AddDeleteEntityComponent(
                            entityType = EntityType.CHARACTER,
                            onError = {
                                Handler(Looper.getMainLooper()).post {
                                    Toast.makeText(
                                        context,
                                        errorMessage,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        )
                    }

                    CharacterListComponent(
                        type = type,
                        animeViewModel = animeViewModel,
                        mangaViewModel = mangaViewModel,
                        navController = navController
                    )
                }
            }

            else -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tabItems[selectedTabIndex].title,
                        fontSize = 18.sp
                    )
                }
            }
        }

        /*
        // pager
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxWidth()
        ) { index ->
            // app content
            // Have the list

            val errorMessage = stringResource(id = R.string.an_error_occurred_caption)

            when (tabItems[index].entityType) {
                EntityType.ANIME -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceEvenly
                    ) {
                        if (type != ListType.FAVORITE) {
                            AddDeleteEntityComponent(
                                entityType = EntityType.ANIME,
                                onError = {
                                    Handler(Looper.getMainLooper()).post {
                                        Toast.makeText(
                                            context,
                                            errorMessage,
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                        }

//                        AnimeListComponent(
                        AnimeExperimentalListComponent(
                            type = type,
                            mangaViewModel = mangaViewModel,
                            characterViewModel = characterViewModel
                        )
                    }
                }

                EntityType.MANGA -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceEvenly
                    ) {
                        if (type != ListType.FAVORITE) {
                            AddDeleteEntityComponent(
                                entityType = EntityType.MANGA,
                                onError = {
                                    Handler(Looper.getMainLooper()).post {
                                        Toast.makeText(
                                            context,
                                            errorMessage,
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                        }

                        MangaListComponent(
                            type = type,
                            animeViewModel = animeViewModel,
                            characterViewModel = characterViewModel
                        )
                    }

                }

                EntityType.CHARACTER -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceEvenly
                    ) {
                        if (type != ListType.FAVORITE) {
                            AddDeleteEntityComponent(
                                entityType = EntityType.CHARACTER,
                                onError = {
                                    Handler(Looper.getMainLooper()).post {
                                        Toast.makeText(
                                            context,
                                            errorMessage,
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                        }

                        CharacterListComponent(
                            type = type,
                            animeViewModel = animeViewModel,
                            mangaViewModel = mangaViewModel
                        )
                    }
                }

                else -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tabItems[index].title,
                            fontSize = 18.sp
                        )
                    }
                }
            }
        }
        */

        // change the tab item when current page is changed
        LaunchedEffect(pagerState.currentPage, pagerState.isScrollInProgress) {
            if (!pagerState.isScrollInProgress) {
                selectedTabIndex = pagerState.currentPage
            }
        }
    }
}
