package com.sharonn.poppy.data.firebase

import com.sharonn.poppy.data.model.UserData

data class SignInResult(
    val data: UserData?,
    val errorMessage: String?
)
