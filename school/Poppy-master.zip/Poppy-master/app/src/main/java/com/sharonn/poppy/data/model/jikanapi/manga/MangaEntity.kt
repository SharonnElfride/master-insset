package com.sharonn.poppy.data.model.jikanapi.manga

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sharonn.poppy.utils.MANGA_TABLE_NAME

@Entity(tableName = MANGA_TABLE_NAME)
class MangaEntity(
    @ColumnInfo(name = "userId")
    val userId: String,

    @ColumnInfo(name = "url")
    val mangaUrl: String,

    @ColumnInfo(name = "imageUrl")
    val imageUrl: String? = null,

    @ColumnInfo(name = "smallImageUrl")
    val smallImageUrl: String? = null,

    @ColumnInfo(name = "approved")
    val approvedByMal: Boolean,

    @ColumnInfo(name = "title")
    val mangaTitle: String,

    @ColumnInfo(name = "kanjiTitle")
    val mangaKanjiTitle: String? = null,

    @ColumnInfo(name = "otherTitles")
    val mangaOtherTitles: String? = null,

    @ColumnInfo(name = "type")
    val mangaType: String? = null,

    @ColumnInfo(name = "chapters")
    val mangaChapters: Int? = null,

    @ColumnInfo(name = "volumes")
    val mangaVolumes: Int? = null,

    @ColumnInfo(name = "status")
    val mangaStatus: String? = null,

    @ColumnInfo(name = "publishing")
    val mangaPublishingStatus: Boolean,

    @ColumnInfo(name = "publishedFrom")
    val mangaPublishingPeriodFrom: String? = null,

    @ColumnInfo(name = "publishedTo")
    val mangaPublishingPeriodTo: String? = null,

    @ColumnInfo(name = "score")
    val mangaMalScore: Float? = null,

    @ColumnInfo(name = "rank")
    val mangaMalRank: Int? = null,

    @ColumnInfo(name = "popularity")
    val mangaMalPopularity: Int? = null,

    @ColumnInfo(name = "synopsis")
    val mangaSynopsis: String? = null,

    @ColumnInfo(name = "background")
    val mangaBackground: String? = null,

    @ColumnInfo(name = "authors")
    val mangaAuthors: String? = null,

    @ColumnInfo(name = "serializations")
    val mangaSerializations: String? = null,

    @ColumnInfo(name = "genres")
    val mangaGenres: String? = null,

    @ColumnInfo(name = "explicit_genres")
    val mangaExplicitGenres: String? = null,

    @ColumnInfo(name = "themes")
    val mangaThemes: String? = null,

    @ColumnInfo(name = "demographics")
    val mangaDemographics: String? = null,

    @ColumnInfo(name = "createdDate")
    val createdDate: String,

    @ColumnInfo(name = "createdTime")
    val createdTime: String,

    @ColumnInfo(name = "isFavorite")
    val isFavorite: Boolean = false
) {
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0
}