package com.sharonn.poppy.data.model.nekoapi

data class AnimePictureObject(
    val imageId: Long,
    val userId: String,
    val imageUrl: String,
    val imageSourceUrl: String? = null,
    val imageRating: String,
    val artistName: String,
    val createdDate: String,
    val createdTime: String
)

fun List<AnimePictureEntity>.toDomain(): List<AnimePictureObject> {
    return map { entity ->
        entity.toDomainSingle()
    }
}

fun AnimePictureEntity.toDomainSingle(): AnimePictureObject {
    return AnimePictureObject(
        imageId = id,
        userId = userId,
        imageUrl = imageUrl,
        imageSourceUrl = imageSourceUrl,
        imageRating = imageRating,
        artistName = artistName,
        createdDate = createdDate,
        createdTime = createdTime
    )
}
