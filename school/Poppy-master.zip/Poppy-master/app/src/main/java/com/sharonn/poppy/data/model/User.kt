package com.sharonn.poppy.data.model

data class UserData(
    var userId: String,
    val username: String?,
    val email: String?,
    val profilePictureURI: String?
)

data class Account(
    var userId: String,
    val username: String?,
    val email: String?,
    val profilePictureURI: String?
)
