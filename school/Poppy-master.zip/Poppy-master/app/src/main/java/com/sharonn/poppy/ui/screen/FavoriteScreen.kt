package com.sharonn.poppy.ui.screen

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.sharonn.poppy.utils.ListType
import com.sharonn.poppy.ui.components.LibraryTabComponent
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.md_theme_light_primary

@Composable
fun FavoriteScreen(
    context: Context,
    navController: NavController = rememberNavController()
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = md_theme_light_primary)
            .padding(top = 10.dp)
            .clip(shape = RoundedCornerShape(15.dp, 15.dp, 0.dp, 0.dp))
            .background(color = dark_custom_color_2),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LibraryTabComponent(
            context = context,
            type = ListType.FAVORITE,
            navController = navController
        )
    }
}
