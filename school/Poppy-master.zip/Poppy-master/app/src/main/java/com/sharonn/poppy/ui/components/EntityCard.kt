package com.sharonn.poppy.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.sharonn.poppy.R
import com.sharonn.poppy.ui.theme.md_theme_dark_onSurfaceVariant
import com.sharonn.poppy.ui.theme.md_theme_dark_surfaceVariant
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntityCard(
    context: Context,
    toastText: String,
    imageUrl: String? = null,
    title: String,
    body: String? = null,
    footer: String,
    entityIsFavorite: Boolean,
    onEyeIconClick: (() -> Unit)? = null,
    onFavoriteIconClick: (() -> Unit)? = null,
    onDeleteIconClick: (() -> Unit)? = null,
) {
    Card(
        onClick = {
            Toast.makeText(
                context,
                toastText,
                Toast.LENGTH_SHORT
            ).show()
        },
        modifier = Modifier
            .size(width = 400.dp, height = 200.dp),
        colors = CardDefaults.cardColors(
            containerColor = md_theme_dark_surfaceVariant,
            contentColor = md_theme_dark_onSurfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (imageUrl != null) {
                AsyncImage(
                    model = imageUrl,
                    contentScale = ContentScale.Crop,
                    contentDescription = "Content description",
                    error = painterResource(R.drawable.round_broken_image_white_24),
                    placeholder = painterResource(R.drawable.loading),
                    modifier = Modifier.size(width = 150.dp, height = 200.dp)
                )
            } else {
                Image(
                    imageVector = Icons.Rounded.BrokenImage,
                    contentDescription = stringResource(id = R.string.broken_image_text),
                    modifier = Modifier.fillMaxSize()
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(color = Color.White, shape = CircleShape)
                        .padding(5.dp),
                    style = TextStyle(
                        fontSize = 25.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontStyle = FontStyle.Normal,
                        color = Color.Black
                    ),
                    textAlign = TextAlign.Center,
                    overflow = TextOverflow.Ellipsis,
                    softWrap = true,
                    maxLines = 1
                )

                Column {
                    if (body != null) {
                        Text(
                            text = body,
                            style = TextStyle(
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontStyle = FontStyle.Normal,
                                color = md_theme_light_onPrimary
                            ),
                            textAlign = TextAlign.Center,
                            overflow = TextOverflow.Ellipsis,
                            softWrap = true,
                            maxLines = 4
                        )
                    }

                    if (onEyeIconClick != null || onFavoriteIconClick != null || onDeleteIconClick != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (onEyeIconClick != null) {
                                IconButton(onClick = onEyeIconClick) {
                                    Icon(
                                        imageVector = Icons.Rounded.Visibility,
                                        contentDescription = "Content description"
                                    )
                                }
                            }

                            if (onFavoriteIconClick != null) {
                                var favoriteImageVector = Icons.Rounded.FavoriteBorder
                                if (entityIsFavorite) {
                                    favoriteImageVector = Icons.Rounded.Favorite
                                }

                                IconButton(onClick = onFavoriteIconClick) {
                                    Icon(
                                        imageVector = favoriteImageVector,
                                        contentDescription = "Content description",
                                    )
                                }
                            }

                            if (onDeleteIconClick != null) {
                                IconButton(onClick = onDeleteIconClick) {
                                    Icon(
                                        imageVector = Icons.Rounded.Delete,
                                        contentDescription = "Content description",
                                    )
                                }
                            }
                        }
                    }
                }

                Text(
                    text = footer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(color = Color.White, shape = CircleShape)
                        .padding(5.dp),
                    style = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Italic,
                        color = Color(0xAA000000),
                    ),
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}
