package com.sharonn.poppy.utils

// Retrofit
const val JIKAN_API_V4_BASE_URL = "https://api.jikan.moe/v4/"

const val NEKOS_API_V3_BASE_URL = "https://api.nekosapi.com/v3/"  // Stable
// const val NEKOS_API_V2_BASE_URL = "https://api.nekosapi.com/v2/"  // Discontinued on November 2nd of 2023
// const val NEKOS_API_V1_BASE_URL = "https://api.nekosapi.com/v1/"  // Deprecated

const val JIKAN_API_BASE_URL = JIKAN_API_V4_BASE_URL
const val NEKOS_API_BASE_URL = NEKOS_API_V3_BASE_URL

// Room
const val POPPY_DATABASE_NAME = "poppyDatabase"
const val ANIME_TABLE_NAME = "animes"
const val MANGA_TABLE_NAME = "mangas"
const val CHARACTER_TABLE_NAME = "characters"
const val ANIME_PICTURE_TABLE_NAME = "anime_pictures"
const val RATING_PARAM_TABLE_NAME = "rating_params"

// JSON parsing
const val DEFAULT_TITLE_IDENTIFIER = "Default"
const val JAPANESE_TITLE_IDENTIFIER = "Japanese"

// Errors tags
const val REPO_ERROR_TAG = "POPPY REPO ERROR"

// Visualizer screens navigation
const val VISUALIZE_SINGLE_SCREEN_PREFIX = "visualize_single"
const val VISUALIZE_IMAGE = "imageId"
const val VISUALIZE_ANIME = "animeId"
const val VISUALIZE_MANGA = "mangaId"
const val VISUALIZE_CHARACTER = "characterId"
const val VISUALIZE_NOTE = "noteId"

const val STAR_RATING_TOTAL_COUNT = 10

const val ANIME_PICTURE_SAFE_KEY = "safe"
const val ANIME_PICTURE_BORDERLINE_KEY = "borderline"
const val ANIME_PICTURE_SUGGESTIVE_KEY = "suggestive"

// Firebase
const val NOTES_COLLECTION = "notes"
const val ANIME_PICTURE_RATING_COLLECTION = "anime_picture_rating"
