package com.sharonn.poppy.ui.model

import com.sharonn.poppy.data.model.jikanapi.character.CharacterObject

/**
 * The character items are grouped by creation date
 */
sealed interface CharacterItemUI {
    data class Header(
        val createdDate: String
    ) : CharacterItemUI

    data class Item(
        val characterId: Long,
        val characterUrl: String,
        val imageUrl: String? = null,
        val smallImageUrl: String? = null,
        val characterName: String,
        val characterKanjiName: String? = null,
        val characterNicknames: String? = null,
        val characterAbout: String? = null,
        val createdDate: String,
        val createdTime: String,
        val isFavorite: Boolean = false
    ) : CharacterItemUI

    data class Footer(
        val addedTotal: Int
    ) : CharacterItemUI

    data class CompleteCharacter(
        val header: Header,
        val items: List<Item>,
        val footer: Footer
    ) : CharacterItemUI
}

fun List<CharacterObject>.toUi(): List<CharacterItemUI.Item> {
    return map { entity -> entity.toUiSingle() }
}

fun CharacterObject.toUiSingle(): CharacterItemUI.Item {
    return CharacterItemUI.Item(
        characterId = characterId,
        characterUrl = characterUrl,
        imageUrl = imageUrl,
        smallImageUrl = smallImageUrl,
        characterName = characterName,
        characterKanjiName = characterKanjiName,
        characterNicknames = characterNicknames,
        characterAbout = characterAbout,
        createdDate = createdDate,
        createdTime = createdTime,
        isFavorite = isFavorite
    )
}

