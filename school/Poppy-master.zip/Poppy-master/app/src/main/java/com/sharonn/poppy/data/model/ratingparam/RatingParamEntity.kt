package com.sharonn.poppy.data.model.ratingparam

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.sharonn.poppy.utils.RATING_PARAM_TABLE_NAME

@Entity(
    tableName = RATING_PARAM_TABLE_NAME,
    indices = [Index(value = ["userId"], unique = true)]
)
class RatingParamEntity(
    @ColumnInfo(name = "userId")
    val userId: String,

    @ColumnInfo(name = "safe")
    val safe: Boolean = true,

    @ColumnInfo(name = "borderline")
    val borderline: Boolean = false,

    @ColumnInfo(name = "suggestive")
    val suggestive: Boolean = false,

//    @ColumnInfo(name = "explicit")
//    val explicit: Boolean = false
) {
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0
}

fun RatingParam.toRoomObject(): RatingParamEntity {
    return RatingParamEntity(
        userId = userId,
        safe = safe,
        borderline = borderline,
        suggestive = suggestive
    )
}

fun RatingParamEntity.toDomain(): RatingParam {
    return RatingParam(
        userId = userId,
        safe = safe,
        borderline = borderline,
        suggestive = suggestive
    )
}

