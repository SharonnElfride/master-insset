package com.sharonn.poppy.architecture

import android.app.Application
import androidx.room.Room
import com.sharonn.poppy.utils.POPPY_DATABASE_NAME

class CustomApplication : Application() {
    companion object {
        lateinit var instance: CustomApplication
    }

    val poppyDatabase: CustomRoomDatabase by lazy {
        Room.databaseBuilder(
            applicationContext,
            CustomRoomDatabase::class.java,
            POPPY_DATABASE_NAME
        ).allowMainThreadQueries().fallbackToDestructiveMigration().build()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}