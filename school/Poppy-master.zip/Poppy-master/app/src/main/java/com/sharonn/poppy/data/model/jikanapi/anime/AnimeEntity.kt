package com.sharonn.poppy.data.model.jikanapi.anime

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sharonn.poppy.utils.ANIME_TABLE_NAME

@Entity(tableName = ANIME_TABLE_NAME)
class AnimeEntity(
    @ColumnInfo(name = "userId")
    val userId: String,

    @ColumnInfo(name = "url")
    val animeUrl: String,

    @ColumnInfo(name = "imageUrl")
    val imageUrl: String? = null,

    @ColumnInfo(name = "smallImageUrl")
    val smallImageUrl: String? = null,

    @ColumnInfo(name = "approved")
    val approvedByMal: Boolean,

    @ColumnInfo(name = "trailerUrl")
    val trailerUrl: String? = null,

    @ColumnInfo(name = "title")
    val animeTitle: String,

    @ColumnInfo(name = "kanjiTitle")
    val animeKanjiTitle: String? = null,

    @ColumnInfo(name = "otherTitles")
    val animeOtherTitles: String? = null,

    @ColumnInfo(name = "type")
    val animeType: String? = null,

    @ColumnInfo(name = "source")
    val animeSource: String? = null,

    @ColumnInfo(name = "episodes")
    val animeEpisodes: Int? = null,

    @ColumnInfo(name = "status")
    val animeStatus: String? = null,

    @ColumnInfo(name = "airing")
    val animeAiringStatus: Boolean,

    @ColumnInfo(name = "airedFrom")
    val animeAiringPeriodFrom: String? = null,

    @ColumnInfo(name = "airedTo")
    val animeAiringPeriodTo: String? = null,

    @ColumnInfo(name = "duration")
    val animeDuration: String? = null,

    @ColumnInfo(name = "rating")
    val animeRating: String? = null,

    @ColumnInfo(name = "score")
    val animeMalScore: Float? = null,

    @ColumnInfo(name = "rank")
    val animeMalRank: Int? = null,

    @ColumnInfo(name = "popularity")
    val animeMalPopularity: Int? = null,

    @ColumnInfo(name = "synopsis")
    val animeSynopsis: String? = null,

    @ColumnInfo(name = "background")
    val animeBackground: String? = null,

    @ColumnInfo(name = "producers")
    val animeProducers: String? = null,

    @ColumnInfo(name = "studios")
    val animeStudios: String? = null,

    @ColumnInfo(name = "genres")
    val animeGenres: String? = null,

    @ColumnInfo(name = "explicit_genres")
    val animeExplicitGenres: String? = null,

    @ColumnInfo(name = "themes")
    val animeThemes: String? = null,

    @ColumnInfo(name = "demographics")
    val animeDemographics: String? = null,

    @ColumnInfo(name = "createdDate")
    val createdDate: String,

    @ColumnInfo(name = "createdTime")
    val createdTime: String,

    @ColumnInfo(name = "isFavorite")
    val isFavorite: Boolean = false
) {
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0
}
