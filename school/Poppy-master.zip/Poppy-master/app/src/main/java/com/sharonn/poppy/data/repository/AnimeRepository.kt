package com.sharonn.poppy.data.repository

import com.sharonn.poppy.architecture.CustomApplication
import com.sharonn.poppy.architecture.RetrofitBuilder
import com.sharonn.poppy.data.model.jikanapi.anime.AnimeObject
import com.sharonn.poppy.data.model.jikanapi.anime.toDomain
import com.sharonn.poppy.data.model.jikanapi.anime.toDomainSingle
import com.sharonn.poppy.data.model.jikanapi.anime.toRoom
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class AnimeRepository {
    private val animeDao = CustomApplication.instance.poppyDatabase.animeDao()

    suspend fun addAnime(userId: String) {
        val result = RetrofitBuilder.getAnimeMangaCharacter().generateRandomAnime()
        animeDao.insert(anime = result.toRoom(userId = userId))
    }

    fun getSingleAnime(animeId: Long): AnimeObject {
        return animeDao.getSingleAnime(animeId = animeId).toDomainSingle()
    }

    fun updateAnimeIsFavorite(animeId: Long, value: Boolean) {
        animeDao.updateAnimeIsFavorite(
            isFavorite = value,
            animeId = animeId
        )
    }

    fun deleteSingleAnime(animeId: Long) {
        animeDao.deleteSingleAnime(animeId = animeId)
    }

    fun getAllAnimes(userId: String): Flow<List<AnimeObject>> {
        return animeDao.getAllAnimes(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun getFirstThreeAnimes(userId: String): Flow<List<AnimeObject>> {
        return animeDao.getFirstThreeAnimes(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun getFavoriteAnimes(userId: String): Flow<List<AnimeObject>> {
        return animeDao.getFavoriteAnimes(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun deleteAllAnimes(userId: String) {
        animeDao.deleteAll(userId = userId)
    }
}