package com.sharonn.poppy.data.repository

import com.sharonn.poppy.architecture.CustomApplication
import com.sharonn.poppy.architecture.RetrofitBuilder
import com.sharonn.poppy.data.model.jikanapi.character.CharacterObject
import com.sharonn.poppy.data.model.jikanapi.character.toDomain
import com.sharonn.poppy.data.model.jikanapi.character.toDomainSingle
import com.sharonn.poppy.data.model.jikanapi.character.toRoom
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CharacterRepository {
    private val characterDao = CustomApplication.instance.poppyDatabase.characterDao()

    suspend fun addCharacter(userId: String) {
        val result = RetrofitBuilder.getAnimeMangaCharacter().generateRandomCharacter()
        characterDao.insert(character = result.toRoom(userId = userId))
    }

    fun getSingleCharacter(characterId: Long): CharacterObject {
        return characterDao.getSingleCharacter(characterId = characterId).toDomainSingle()
    }

    fun updateCharacterIsFavorite(characterId: Long, value: Boolean) {
        characterDao.updateCharacterIsFavorite(
            isFavorite = value,
            characterId = characterId
        )
    }

    fun deleteSingleCharacter(characterId: Long) {
        characterDao.deleteSingleCharacter(characterId = characterId)
    }

    fun getAllCharacters(userId: String): Flow<List<CharacterObject>> {
        return characterDao.getAllCharacters(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun getFirstThreeCharacters(userId: String): Flow<List<CharacterObject>> {
        return characterDao.getFirstThreeCharacters(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun getFavoriteCharacters(userId: String): Flow<List<CharacterObject>> {
        return characterDao.getFavoriteCharacters(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun deleteAllCharacters(userId: String) {
        characterDao.deleteAll(userId = userId)
    }
}