package com.sharonn.poppy.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.sharonn.poppy.data.repository.AnimeRepository
import com.sharonn.poppy.utils.REPO_ERROR_TAG
import com.sharonn.poppy.ui.model.AnimeItemUI
import com.sharonn.poppy.ui.model.toUi
import com.sharonn.poppy.ui.model.toUiSingle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class AnimeViewModel : ViewModel() {
    private val animeRepository: AnimeRepository by lazy { AnimeRepository() }

    private val auth = Firebase.auth
    private val userId = auth.currentUser?.uid ?: String()

    private val _animes: Flow<List<AnimeItemUI>>
        get() = animeRepository.getAllAnimes(userId = userId).map { list ->
            list.groupBy { character ->
                character.animeType
            }.flatMap {
                buildList {
                    add(
                        AnimeItemUI.CompleteAnime(
                            header = AnimeItemUI.Header(
                                animeType = it.key
                            ),
                            items = it.value.toUi(),
                            footer = AnimeItemUI.Footer(
                                addedTotal = it.value.size
                            )
                        )
                    )
                }
            }
        }

    val animes = _animes

    private val _favoriteAnimes: Flow<List<AnimeItemUI>>
        get() = animeRepository.getFavoriteAnimes(userId = userId).map { list ->
            list.groupBy { character ->
                character.animeType
            }.flatMap {
                buildList {
                    add(
                        AnimeItemUI.CompleteAnime(
                            header = AnimeItemUI.Header(
                                animeType = it.key
                            ),
                            items = it.value.toUi(),
                            footer = AnimeItemUI.Footer(
                                addedTotal = it.value.size
                            )
                        )
                    )
                }
            }
        }

    val favoriteAnimes = _favoriteAnimes

    private val _firstThreeAnimes: Flow<List<AnimeItemUI.Item>>
        get() = animeRepository.getFirstThreeAnimes(userId = userId).map { list ->
            list.toUi()
        }

    val firstThreeAnimes = _firstThreeAnimes

    fun addAnime(
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                animeRepository.addAnime(userId = userId)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun getSingleAnime(
        animeId: Long,
        onError: () -> Unit
    ): AnimeItemUI? {
        var anime: AnimeItemUI? = null
        try {
            anime =
                animeRepository.getSingleAnime(animeId = animeId).toUiSingle()
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d(REPO_ERROR_TAG, e.message.toString())
            onError()
        }

        return anime
    }

    fun updateAnimeIsFavorite(
        value: Boolean,
        animeId: Long,
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                animeRepository.updateAnimeIsFavorite(
                    animeId = animeId,
                    value = value
                )
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun deleteSingleAnime(
        animeId: Long,
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                animeRepository.deleteSingleAnime(animeId = animeId)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun deleteAllAnimes(
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                animeRepository.deleteAllAnimes(userId = userId)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }
}