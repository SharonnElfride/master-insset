package com.sharonn.poppy.data.model.jikanapi.manga

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.sharonn.poppy.utils.DEFAULT_TITLE_IDENTIFIER
import com.sharonn.poppy.utils.DateFormat
import com.sharonn.poppy.utils.JAPANESE_TITLE_IDENTIFIER
import com.sharonn.poppy.utils.SharedFunctions.Companion.formatFromToPeriod
import com.sharonn.poppy.utils.SharedFunctions.Companion.fromListToString
import com.sharonn.poppy.domain.FormatDateUseCase
import java.util.Date

data class MangaDto(
    @Expose
    @SerializedName("data")
    val data: MangaData,

    // All the list attributes will be converted to String using .joinToString & converted back to array using .split
)

data class MangaData(
    @Expose
    @SerializedName("url")
    val mangaUrl: String,

    @Expose
    @SerializedName("images")
    val mangaImages: MangaImages,

    @Expose
    @SerializedName("approved")
    val approvedByMal: Boolean,

    @Expose
    @SerializedName("titles")
    val mangaTitles: List<MangaTitle>,

    @Expose
    @SerializedName("type")
    val mangaType: String?,

    @Expose
    @SerializedName("chapters")
    val mangaChapters: Int?,

    @Expose
    @SerializedName("volumes")
    val mangaVolumes: Int?,

    @Expose
    @SerializedName("status")
    val mangaStatus: String?,

    @Expose
    @SerializedName("publishing")
    val mangaPublishingStatus: Boolean,

    @Expose
    @SerializedName("published")
    val mangaPublishingPeriod: MangaPublishingPeriod,

    @Expose
    @SerializedName("score")
    val mangaMalScore: Float?,

    @Expose
    @SerializedName("rank")
    val mangaMalRank: Int?,

    @Expose
    @SerializedName("popularity")
    val mangaMalPopularity: Int?,

    @Expose
    @SerializedName("synopsis")
    val mangaSynopsis: String?,

    @Expose
    @SerializedName("background")
    val mangaBackground: String?,

    @Expose
    @SerializedName("authors")
    val mangaAuthors: List<MangaAuthorSerialization>,

    @Expose
    @SerializedName("serializations")
    val mangaSerializations: List<MangaAuthorSerialization>,

    @Expose
    @SerializedName("genres")
    val mangaGenres: List<MangaGenreTheme>,

    @Expose
    @SerializedName("explicit_genres")
    val mangaExplicitGenres: List<MangaGenreTheme>,

    @Expose
    @SerializedName("themes")
    val mangaThemes: List<MangaGenreTheme>,

    @Expose
    @SerializedName("demographics")
    val mangaDemographics: List<MangaDemographic>,
)

data class MangaImages(
    @Expose
    @SerializedName("webp")
    val webpImages: MangaWebpImages,
)

data class MangaWebpImages(
    @Expose
    @SerializedName("image_url")
    val imageUrl: String?,

    @Expose
    @SerializedName("small_image_url")
    val smallImageUrl: String?,
)

data class MangaTitle(
    @Expose
    @SerializedName("type")
    val titleType: String,

    @Expose
    @SerializedName("title")
    val title: String,
)

data class MangaPublishingPeriod(
    @Expose
    @SerializedName("from")
    val from: String?,

    @Expose
    @SerializedName("to")
    val to: String?,
)

data class MangaAuthorSerialization(
    @Expose
    @SerializedName("name")
    val name: String?,
)

data class MangaGenreTheme(
    @Expose
    @SerializedName("name")
    val name: String?,
)

data class MangaDemographic(
    @Expose
    @SerializedName("name")
    val name: String?,
)

fun MangaDto.toRoom(userId: String): MangaEntity {
    val currentDateTime = Date()

    // Parsing json here !
    val mangaUrl = data.mangaUrl
    val imageUrl = data.mangaImages.webpImages.imageUrl
    val smallImageUrl = data.mangaImages.webpImages.smallImageUrl
    val approvedByMal = data.approvedByMal

    val mangaTitle = data.mangaTitles.find { title ->
        title.titleType.equals(DEFAULT_TITLE_IDENTIFIER, ignoreCase = true)
    }?.title ?: ""

    val mangaKanjiTitle = data.mangaTitles.find { title ->
        title.titleType.equals(JAPANESE_TITLE_IDENTIFIER, ignoreCase = true)
    }?.title ?: ""

    val otherTitles = data.mangaTitles.filter { title ->
        !title.titleType.equals(DEFAULT_TITLE_IDENTIFIER, ignoreCase = true) &&
                !title.titleType.equals(JAPANESE_TITLE_IDENTIFIER, ignoreCase = true)
    }.map { title -> title.title }

    val mangaOtherTitles = fromListToString(otherTitles)

    val mangaType = data.mangaType
    val mangaChapters = data.mangaChapters
    val mangaVolumes = data.mangaVolumes
    val mangaStatus = data.mangaStatus
    val mangaPublishingStatus = data.mangaPublishingStatus

    val mangaPublishingPeriodFrom = formatFromToPeriod(data.mangaPublishingPeriod.from)
    val mangaPublishingPeriodTo = formatFromToPeriod(data.mangaPublishingPeriod.to)

    val mangaMalScore = data.mangaMalScore
    val mangaMalRank = data.mangaMalRank
    val mangaMalPopularity = data.mangaMalPopularity
    val mangaSynopsis = data.mangaSynopsis
    val mangaBackground = data.mangaBackground

    val authors = data.mangaAuthors.map { author -> author.name }
    val mangaAuthors = fromListToString(authors)

    val serializations = data.mangaSerializations.map { serialization -> serialization.name }
    val mangaSerializations = fromListToString(serializations)

    val genres = data.mangaGenres.map { genre -> genre.name }
    val mangaGenres = fromListToString(genres)

    val explicitGenres = data.mangaExplicitGenres.map { genre -> genre.name }
    val mangaExplicitGenres = fromListToString(explicitGenres)

    val themes = data.mangaThemes.map { theme -> theme.name }
    val mangaThemes = fromListToString(themes)

    val demographics = data.mangaDemographics.map { demographic -> demographic.name }
    val mangaDemographics = fromListToString(demographics)

    val createdDate = FormatDateUseCase().invoke(currentDateTime, DateFormat.DATE)
    val createdTime = FormatDateUseCase().invoke(currentDateTime, DateFormat.TIME)

    return MangaEntity(
        userId = userId,
        mangaUrl = mangaUrl,
        imageUrl = imageUrl,
        smallImageUrl = smallImageUrl,
        approvedByMal = approvedByMal,
        mangaTitle = mangaTitle,
        mangaKanjiTitle = mangaKanjiTitle,
        mangaOtherTitles = mangaOtherTitles,
        mangaType = mangaType,
        mangaChapters = mangaChapters,
        mangaVolumes = mangaVolumes,
        mangaStatus = mangaStatus,
        mangaPublishingStatus = mangaPublishingStatus,
        mangaPublishingPeriodFrom = mangaPublishingPeriodFrom,
        mangaPublishingPeriodTo = mangaPublishingPeriodTo,
        mangaMalScore = mangaMalScore,
        mangaMalRank = mangaMalRank,
        mangaMalPopularity = mangaMalPopularity,
        mangaSynopsis = mangaSynopsis,
        mangaBackground = mangaBackground,
        mangaAuthors = mangaAuthors,
        mangaSerializations = mangaSerializations,
        mangaGenres = mangaGenres,
        mangaExplicitGenres = mangaExplicitGenres,
        mangaThemes = mangaThemes,
        mangaDemographics = mangaDemographics,
        createdDate = createdDate,
        createdTime = createdTime
    )
}

