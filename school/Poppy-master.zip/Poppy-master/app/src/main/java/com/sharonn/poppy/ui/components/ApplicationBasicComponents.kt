package com.sharonn.poppy.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PersonRemoveAlt1
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.toUpperCase
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sharonn.poppy.R
import com.sharonn.poppy.ui.theme.dark_oncustom_color_2
import com.sharonn.poppy.ui.theme.md_theme_dark_errorContainer
import com.sharonn.poppy.ui.theme.md_theme_dark_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_onPrimary
import com.sharonn.poppy.ui.theme.md_theme_light_onSurface
import com.sharonn.poppy.ui.theme.md_theme_light_primary


@Composable
fun NoDataComponent() {
    Column(
        modifier = Modifier.padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.no_data_text),
            style = TextStyle(
                color = Color.Red,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            ),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun RatingParamSwitch(
    paramName: String,
    checked: Boolean,
    onSwitch: ((Boolean) -> Unit)? = null,
    enabled: Boolean = true
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = paramName,
            style = TextStyle(
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                fontStyle = FontStyle.Normal,
                color = md_theme_light_onPrimary
            ),
            textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.size(ButtonDefaults.IconSpacing))

        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onSwitch,
            thumbContent = if (checked) {
                {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = "Content description",
                        modifier = Modifier.size(SwitchDefaults.IconSize),
                    )
                }
            } else {
                null
            },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = md_theme_light_primary,
                checkedBorderColor = md_theme_dark_onPrimary,
                checkedIconColor = md_theme_dark_onPrimary,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = md_theme_light_primary,
                uncheckedBorderColor = md_theme_dark_onPrimary
            )
        )
    }
}

@Composable
fun ProfileInformation(
    infoTitle: String,
    information: String? = null,
    noDataText: String
) {
    Row(
        modifier = Modifier,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$infoTitle:",
            style = TextStyle(
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Normal,
                color = md_theme_light_onPrimary,
                textDecoration = TextDecoration.Underline
            ),
            textAlign = TextAlign.Center,
        )

        var color = md_theme_light_onPrimary
        if (information == null) {
            color = md_theme_dark_errorContainer
        }

        Text(
            text = information ?: noDataText.toUpperCase(Locale.current),
            style = TextStyle(
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                fontStyle = FontStyle.Normal,
                color = color
            ),
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun EntityDataCheckbox(
    checkValue: Boolean,
    checkTitle: String
) {
    Row(
        modifier = Modifier,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        var imageVector = Icons.Rounded.Check
        if (!checkValue) {
            imageVector = Icons.Rounded.Close
        }

        Box(
            modifier = Modifier
                .size(25.dp)
                .background(color = md_theme_light_primary, shape = RoundedCornerShape(5.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = imageVector,
                contentDescription = "",
                tint = Color.White
            )
        }

        Text(
            text = checkTitle,
            textAlign = TextAlign.Justify,
            style = TextStyle(
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                fontStyle = FontStyle.Normal,
                color = Color.White
            ),
        )
    }
}

@Composable
fun DialogComponent(
    onDismissRequest: () -> Unit,
    onConfirmation: () -> Unit,
    dialogTitle: String,
    dialogText: String,
    icon: ImageVector,
    contentDescription: String? = null
) {
    AlertDialog(
        icon = {
            Icon(
                icon,
                contentDescription = contentDescription,
                tint = Color.Red,
                modifier = Modifier.size(30.dp)
            )
        },
        title = {
            Text(
                text = dialogTitle
            )
        },
        text = {
            Text(
                text = dialogText
            )
        },
        onDismissRequest = {
            onDismissRequest()
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onConfirmation()
                }
            ) {
                Text(
                    text = stringResource(id = R.string.confirm_button_caption),
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    onDismissRequest()
                }
            ) {
                Text(
                    text = stringResource(id = R.string.cancel_button_caption)
                )
            }
        },
    )
}

@Composable
fun AccountDeletionComponent(
    onAccountDeletionRequest: () -> Unit
) {
    val openAlertDialog = remember { mutableStateOf(false) }
    val context = LocalContext.current
    val confirmationMessage = stringResource(id = R.string.confirmation_registered_caption)

    when {
        openAlertDialog.value -> {
            AccountDeletionDialog(
                onDismissRequest = { openAlertDialog.value = false },
                onConfirmation = {
                    openAlertDialog.value = false

                    Toast.makeText(
                        context,
                        confirmationMessage,
                        Toast.LENGTH_SHORT
                    ).show()

                    onAccountDeletionRequest()
                }
            )
        }
    }

    val deleteAccountImageVector = Icons.Rounded.PersonRemoveAlt1
    AuthenticationButtonComponent(
        imageVector = deleteAccountImageVector,
        value = context.getString(R.string.delete_account_button_text),
        onClickButton = { openAlertDialog.value = true }
    )
}

@Composable
fun NoteEntityInformation(
    entityId: String,
    entityType: String,
    entityDenomination: String,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start,
    ) {
        Text(
            text = stringResource(id = R.string.note_entity_info_title),
            textAlign = TextAlign.Left,
            style = TextStyle(
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Normal,
                color = dark_oncustom_color_2,
                textDecoration = TextDecoration.Underline
            ),
        )

        EntityStringDataColumn(
            dataTitle = stringResource(id = R.string.note_entity_info_id),
            data = entityId,
            textAlign = TextAlign.Left,
            textColor = md_theme_light_onSurface,
        )
        EntityStringDataColumn(
            dataTitle = stringResource(id = R.string.note_entity_info_denomination),
            data = entityDenomination,
            textAlign = TextAlign.Left,
            textColor = md_theme_light_onSurface,
        )
        EntityStringDataColumn(
            dataTitle = stringResource(id = R.string.note_entity_info_type),
            data = entityType,
            textAlign = TextAlign.Left,
            textColor = md_theme_light_onSurface,
        )
    }
}

fun cancellationToast(
    context: Context
) {
    Toast.makeText(
        context,
        context.getString(R.string.action_cancelled_message),
        Toast.LENGTH_SHORT
    ).show()
}
