package com.sharonn.poppy.utils

enum class ListType {
    ALL,
    FAVORITE
}