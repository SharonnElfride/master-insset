package com.sharonn.poppy.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.sharonn.poppy.data.repository.CharacterRepository
import com.sharonn.poppy.utils.REPO_ERROR_TAG
import com.sharonn.poppy.ui.model.CharacterItemUI
import com.sharonn.poppy.ui.model.toUi
import com.sharonn.poppy.ui.model.toUiSingle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class CharacterViewModel : ViewModel() {
    private val characterRepository: CharacterRepository by lazy { CharacterRepository() }

    private val auth = Firebase.auth
    private val userId = auth.currentUser?.uid ?: String()

    private val _characters: Flow<List<CharacterItemUI>>
        get() = characterRepository.getAllCharacters(userId = userId).map { list ->
            list.groupBy { character ->
                character.createdDate
            }.flatMap {
                buildList {
                    add(
                        CharacterItemUI.CompleteCharacter(
                            header = CharacterItemUI.Header(
                                createdDate = it.key
                            ),
                            items = it.value.toUi(),
                            footer = CharacterItemUI.Footer(
                                addedTotal = it.value.size
                            )
                        )
                    )
//                    add(
//                        CharacterItemUI.Header(
//                            createdDate = it.key,
//                        )
//                    )
//                    addAll(it.value.toUi())
//                    add(
//                        CharacterItemUI.Footer(
//                            addedTotal = it.value.size
//                        )
//                    )
                }
            }
        }

    val characters = _characters

    private val _favoriteCharacters: Flow<List<CharacterItemUI>>
        get() = characterRepository.getFavoriteCharacters(userId = userId).map { list ->
            list.groupBy { character ->
                character.createdDate
            }.flatMap {
                buildList {
                    add(
                        CharacterItemUI.CompleteCharacter(
                            header = CharacterItemUI.Header(
                                createdDate = it.key
                            ),
                            items = it.value.toUi(),
                            footer = CharacterItemUI.Footer(
                                addedTotal = it.value.size
                            )
                        )
                    )
                }
            }
        }

    val favoriteCharacters = _favoriteCharacters

    private val _firstThreeCharacters: Flow<List<CharacterItemUI.Item>>
        get() = characterRepository.getFirstThreeCharacters(userId = userId).map { list ->
            list.toUi()
        }

    val firstThreeCharacters = _firstThreeCharacters

    fun addCharacter(
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                characterRepository.addCharacter(userId = userId)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun getSingleCharacter(
        characterId: Long,
        onError: () -> Unit
    ): CharacterItemUI? {
        var character: CharacterItemUI? = null
        try {
            character =
                characterRepository.getSingleCharacter(characterId = characterId).toUiSingle()
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d(REPO_ERROR_TAG, e.message.toString())
            onError()
        }

        return character
    }

    fun updateCharacterIsFavorite(
        value: Boolean,
        characterId: Long,
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                characterRepository.updateCharacterIsFavorite(
                    characterId = characterId,
                    value = value
                )
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun deleteSingleCharacter(
        characterId: Long,
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                characterRepository.deleteSingleCharacter(characterId = characterId)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }

    fun deleteAllCharacters(
        onError: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                characterRepository.deleteAllCharacters(userId = userId)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d(REPO_ERROR_TAG, e.message.toString())
                onError()
            }
        }
    }
}