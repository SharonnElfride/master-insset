package com.sharonn.poppy.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sharonn.poppy.data.model.jikanapi.character.CharacterEntity
import com.sharonn.poppy.utils.CHARACTER_TABLE_NAME
import kotlinx.coroutines.flow.Flow

@Dao
interface CharacterDao {
    @Query("SELECT * FROM $CHARACTER_TABLE_NAME WHERE userId = :userId ORDER BY createdDate ASC")
    fun getAllCharacters(userId: String): Flow<List<CharacterEntity>>

    @Query("SELECT * FROM $CHARACTER_TABLE_NAME WHERE userId = :userId LIMIT 3")
    fun getFirstThreeCharacters(userId: String): Flow<List<CharacterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(character: CharacterEntity)

    @Query("SELECT * FROM $CHARACTER_TABLE_NAME WHERE id = :characterId")
    fun getSingleCharacter(characterId: Long): CharacterEntity

    @Query("UPDATE $CHARACTER_TABLE_NAME SET isFavorite = :isFavorite WHERE id = :characterId")
    fun updateCharacterIsFavorite(isFavorite: Boolean, characterId: Long): Int

    @Query("SELECT * FROM $CHARACTER_TABLE_NAME WHERE userId = :userId AND isFavorite = ${true} ORDER BY createdDate ASC")
    fun getFavoriteCharacters(userId: String): Flow<List<CharacterEntity>>

    @Query("DELETE FROM $CHARACTER_TABLE_NAME WHERE id = :characterId")
    fun deleteSingleCharacter(characterId: Long)

    @Query("DELETE FROM $CHARACTER_TABLE_NAME WHERE userId = :userId")
    fun deleteAll(userId: String)
}