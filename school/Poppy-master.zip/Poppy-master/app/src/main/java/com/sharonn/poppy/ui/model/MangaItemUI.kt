package com.sharonn.poppy.ui.model

import com.sharonn.poppy.data.model.jikanapi.manga.MangaObject
import com.sharonn.poppy.utils.SharedFunctions.Companion.fromStringToList

/**
 * The manga items are grouped by the manga type.
 *
 * The possible values are: "Manga", "Novel", "Light Novel", "One-shot", "Doujinshi", "Manhua", "Manhwa", "OEL"
 */
sealed interface MangaItemUI {
    data class Header(
        val mangaType: String?
    ) : MangaItemUI

    data class Item(
        val mangaId: Long,
        val mangaUrl: String,
        val imageUrl: String? = null,
        val smallImageUrl: String? = null,
        val mangaType: String? = null,
        val approvedByMal: Boolean,
        val mangaTitle: String,
        val mangaKanjiTitle: String? = null,
        val mangaOtherTitles: String? = null,
        val mangaChapters: Int? = null,
        val mangaVolumes: Int? = null,
        val mangaStatus: String? = null,
        val mangaPublishingStatus: Boolean,
        val mangaPublishingPeriodFrom: String? = null,
        val mangaPublishingPeriodTo: String? = null,
        val mangaMalScore: Float? = null,
        val mangaMalRank: Int? = null,
        val mangaMalPopularity: Int? = null,
        val mangaSynopsis: String? = null,
        val mangaBackground: String? = null,
        val mangaAuthors: List<String>,
        val mangaSerializations: String? = null,
        val mangaGenres: String? = null,
        val mangaExplicitGenres: String? = null,
        val mangaThemes: String? = null,
        val mangaDemographics: String? = null,
        val createdDate: String,
        val createdTime: String,
        val isFavorite: Boolean = false
    ) : MangaItemUI

    data class Footer(
        val addedTotal: Int
    ) : MangaItemUI

    data class CompleteManga(
        val header: Header,
        val items: List<Item>,
        val footer: Footer
    ) : MangaItemUI
}

fun List<MangaObject>.toUi(): List<MangaItemUI.Item> {
    return map { entity -> entity.toUiSingle() }
}

fun MangaObject.toUiSingle(): MangaItemUI.Item {
    return MangaItemUI.Item(
        mangaId = mangaId,
        mangaUrl = mangaUrl,
        imageUrl = imageUrl,
        smallImageUrl = smallImageUrl,
        approvedByMal = approvedByMal,
        mangaTitle = mangaTitle,
        mangaType = mangaType,
        mangaKanjiTitle = mangaKanjiTitle,
        mangaOtherTitles = mangaOtherTitles,
        mangaChapters = mangaChapters,
        mangaVolumes = mangaVolumes,
        mangaStatus = mangaStatus,
        mangaPublishingStatus = mangaPublishingStatus,
        mangaPublishingPeriodFrom = mangaPublishingPeriodFrom,
        mangaPublishingPeriodTo = mangaPublishingPeriodTo,
        mangaMalScore = mangaMalScore,
        mangaMalRank = mangaMalRank,
        mangaMalPopularity = mangaMalPopularity,
        mangaSynopsis = mangaSynopsis,
        mangaBackground = mangaBackground,
        mangaAuthors = fromStringToList(mangaAuthors),
        mangaSerializations = mangaSerializations,
        mangaGenres = mangaGenres,
        mangaExplicitGenres = mangaExplicitGenres,
        mangaThemes = mangaThemes,
        mangaDemographics = mangaDemographics,
        createdDate = createdDate,
        createdTime = createdTime,
        isFavorite = isFavorite
    )
}






