package com.sharonn.poppy.data.model.jikanapi.anime

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.sharonn.poppy.utils.DEFAULT_TITLE_IDENTIFIER
import com.sharonn.poppy.utils.DateFormat
import com.sharonn.poppy.utils.JAPANESE_TITLE_IDENTIFIER
import com.sharonn.poppy.utils.SharedFunctions.Companion.formatFromToPeriod
import com.sharonn.poppy.utils.SharedFunctions.Companion.fromListToString
import com.sharonn.poppy.domain.FormatDateUseCase
import java.util.Date

data class AnimeDto(
    @Expose
    @SerializedName("data")
    val data: AnimeData,

    // All the list attributes will be converted to String using .joinToString & converted back to array using .split
)

data class AnimeData(
    @Expose
    @SerializedName("url")
    val animeUrl: String,

    @Expose
    @SerializedName("images")
    val animeImages: AnimeImages,

    @Expose
    @SerializedName("approved")
    val approvedByMal: Boolean,

    @Expose
    @SerializedName("trailer")
    val animeTrailer: AnimeTrailer,

    @Expose
    @SerializedName("titles")
    val animeTitles: List<AnimeTitle>,

    @Expose
    @SerializedName("type")
    val animeType: String?,

    @Expose
    @SerializedName("source")
    val animeSource: String?,

    @Expose
    @SerializedName("episodes")
    val animeEpisodes: Int?,

    @Expose
    @SerializedName("status")
    val animeStatus: String?,

    @Expose
    @SerializedName("airing")
    val animeAiringStatus: Boolean,

    @Expose
    @SerializedName("aired")
    val animeAiringPeriod: AnimeAiringPeriod,

    @Expose
    @SerializedName("duration")
    val animeDuration: String?,

    @Expose
    @SerializedName("rating")
    val animeRating: String?,

    @Expose
    @SerializedName("score")
    val animeMalScore: Float?,

    @Expose
    @SerializedName("rank")
    val animeMalRank: Int?,

    @Expose
    @SerializedName("popularity")
    val animeMalPopularity: Int?,

    @Expose
    @SerializedName("synopsis")
    val animeSynopsis: String?,

    @Expose
    @SerializedName("background")
    val animeBackground: String?,

    @Expose
    @SerializedName("producers")
    val animeProducers: List<AnimeProducerStudio>,

    @Expose
    @SerializedName("studios")
    val animeStudios: List<AnimeProducerStudio>,

    @Expose
    @SerializedName("genres")
    val animeGenres: List<AnimeGenreTheme>,

    @Expose
    @SerializedName("explicit_genres")
    val animeExplicitGenres: List<AnimeGenreTheme>,

    @Expose
    @SerializedName("themes")
    val animeThemes: List<AnimeGenreTheme>,

    @Expose
    @SerializedName("demographics")
    val animeDemographics: List<AnimeDemographic>,
)

data class AnimeImages(
    @Expose
    @SerializedName("webp")
    val webpImages: AnimeWebpImages,
)

data class AnimeWebpImages(
    @Expose
    @SerializedName("image_url")
    val imageUrl: String?,

    @Expose
    @SerializedName("small_image_url")
    val smallImageUrl: String?,
)

data class AnimeTrailer(
    @Expose
    @SerializedName("url")
    val trailerUrl: String?,
)

data class AnimeTitle(
    @Expose
    @SerializedName("type")
    val titleType: String,

    @Expose
    @SerializedName("title")
    val title: String,
)

data class AnimeAiringPeriod(
    @Expose
    @SerializedName("from")
    val from: String?,

    @Expose
    @SerializedName("to")
    val to: String?,
)

data class AnimeProducerStudio(
    @Expose
    @SerializedName("name")
    val name: String?,
)

data class AnimeGenreTheme(
    @Expose
    @SerializedName("name")
    val name: String?,
)

data class AnimeDemographic(
    @Expose
    @SerializedName("name")
    val name: String?,
)


fun AnimeDto.toRoom(userId: String): AnimeEntity {
    val currentDateTime = Date()

    // Parsing json here !
    val animeUrl = data.animeUrl
    val imageUrl = data.animeImages.webpImages.imageUrl
    val smallImageUrl = data.animeImages.webpImages.smallImageUrl
    val approvedByMal = data.approvedByMal
    val trailerUrl = data.animeTrailer.trailerUrl

    val animeTitle = data.animeTitles.find { title ->
        title.titleType.equals(DEFAULT_TITLE_IDENTIFIER, ignoreCase = true)
    }?.title ?: ""

    val animeKanjiTitle = data.animeTitles.find { title ->
        title.titleType.equals(JAPANESE_TITLE_IDENTIFIER, ignoreCase = true)
    }?.title ?: ""

    val otherTitles = data.animeTitles.filter { title ->
        !title.titleType.equals(DEFAULT_TITLE_IDENTIFIER, ignoreCase = true) &&
                !title.titleType.equals(JAPANESE_TITLE_IDENTIFIER, ignoreCase = true)
    }.map { title -> title.title }

    val animeOtherTitles = fromListToString(otherTitles)

    val animeType = data.animeType
    val animeSource = data.animeSource
    val animeEpisodes = data.animeEpisodes
    val animeStatus = data.animeStatus
    val animeAiringStatus = data.animeAiringStatus

    val animeAiringPeriodFrom = formatFromToPeriod(data.animeAiringPeriod.from)
    val animeAiringPeriodTo = formatFromToPeriod(data.animeAiringPeriod.to)

    val animeDuration = data.animeDuration
    val animeRating = data.animeRating
    val animeMalScore = data.animeMalScore
    val animeMalRank = data.animeMalRank
    val animeMalPopularity = data.animeMalPopularity
    val animeSynopsis = data.animeSynopsis
    val animeBackground = data.animeBackground

    val producers = data.animeProducers.map { producer -> producer.name }
    val animeProducers = fromListToString(producers)

    val studios = data.animeStudios.map { studio -> studio.name }
    val animeStudios = fromListToString(studios)

    val genres = data.animeGenres.map { genre -> genre.name }
    val animeGenres = fromListToString(genres)

    val explicitGenres = data.animeExplicitGenres.map { genre -> genre.name }
    val animeExplicitGenres = fromListToString(explicitGenres)

    val themes = data.animeThemes.map { theme -> theme.name }
    val animeThemes = fromListToString(themes)

    val demographics = data.animeDemographics.map { demographic -> demographic.name }
    val animeDemographics = fromListToString(demographics)

    val createdDate = FormatDateUseCase().invoke(currentDateTime, DateFormat.DATE)
    val createdTime = FormatDateUseCase().invoke(currentDateTime, DateFormat.TIME)

    return AnimeEntity(
        userId = userId,
        animeUrl = animeUrl,
        imageUrl = imageUrl,
        smallImageUrl = smallImageUrl,
        approvedByMal = approvedByMal,
        trailerUrl = trailerUrl,
        animeTitle = animeTitle,
        animeKanjiTitle = animeKanjiTitle,
        animeOtherTitles = animeOtherTitles,
        animeType = animeType,
        animeSource = animeSource,
        animeEpisodes = animeEpisodes,
        animeStatus = animeStatus,
        animeAiringStatus = animeAiringStatus,
        animeAiringPeriodFrom = animeAiringPeriodFrom,
        animeAiringPeriodTo = animeAiringPeriodTo,
        animeDuration = animeDuration,
        animeRating = animeRating,
        animeMalScore = animeMalScore,
        animeMalRank = animeMalRank,
        animeMalPopularity = animeMalPopularity,
        animeSynopsis = animeSynopsis,
        animeBackground = animeBackground,
        animeProducers = animeProducers,
        animeStudios = animeStudios,
        animeGenres = animeGenres,
        animeExplicitGenres = animeExplicitGenres,
        animeThemes = animeThemes,
        animeDemographics = animeDemographics,
        createdDate = createdDate,
        createdTime = createdTime
    )
}


