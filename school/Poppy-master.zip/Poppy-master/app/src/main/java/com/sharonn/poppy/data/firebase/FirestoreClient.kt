package com.sharonn.poppy.data.firebase

import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.firestore
import com.sharonn.poppy.data.model.animepicturerating.AnimePictureRating
import com.sharonn.poppy.data.model.notes.Note
import com.sharonn.poppy.utils.ANIME_PICTURE_RATING_COLLECTION
import com.sharonn.poppy.utils.NOTES_COLLECTION
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirestoreClient {
    private val auth = Firebase.auth
    private val db = Firebase.firestore

    private val userId = auth.currentUser?.uid ?: String()

    // while creating an account, create a record for user's rating param

    // SHARED
    fun insertRecord(
        collectionName: String,
        entity: Map<String, String?>,
        onSuccessAction: (DocumentReference) -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: (() -> Unit)? = null,
    ) {
        db.collection(collectionName).add(
            entity
        ).addOnSuccessListener { result ->
            onSuccessAction(result)

            // Update ID here
            updateRecordId(
                collectionName = collectionName,
                entityId = result.id
            )
        }.addOnCanceledListener {
            if (onCanceledAction != null) {
                onCanceledAction()
            }
        }.addOnFailureListener { error ->
            error.printStackTrace()
            onFailureAction()
        }
    }

    private fun updateRecordId(
        collectionName: String,
        entityId: String
    ) {
        db.collection(collectionName)
            .document(entityId)
            .update(
                mapOf(
                    "id" to entityId
                )
            )
    }

    private fun deleteRecord(
        collectionName: String,
        entityId: String,
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: (() -> Unit)? = null,
    ) {
        db.collection(collectionName)
            .document(entityId)
            .delete().addOnSuccessListener {
                onSuccessAction()
            }.addOnCanceledListener {
                if (onCanceledAction != null) {
                    onCanceledAction()
                }
            }.addOnFailureListener { error ->
                error.printStackTrace()
                onFailureAction()
            }
    }

    // Delete some entities based on their id
    fun deleteMany(
        collectionName: String,
        entityIds: List<String>,
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: (() -> Unit)? = null,
    ) {
//        entityIds.forEach { id ->
//            deleteRecord(
//                collectionName = collectionName,
//                entityId = id,
//                onSuccessAction = onSuccessAction,
//                onFailureAction = onFailureAction,
//                onCanceledAction = onCanceledAction
//            )
//        }

        db.collection(collectionName).whereIn("id", entityIds).whereEqualTo("userId", userId).get()
            .addOnSuccessListener {
                it.documents.forEach { doc ->
                    deleteRecord(
                        collectionName = collectionName,
                        entityId = doc.id,
                        onSuccessAction = onSuccessAction,
                        onFailureAction = onFailureAction,
                        onCanceledAction = onCanceledAction
                    )
                }
            }.addOnFailureListener {
                onFailureAction()
            }.addOnCanceledListener {
                if (onCanceledAction != null) {
                    onCanceledAction()
                }
            }
    }

    // Delete all based on userId
    fun deleteAllByUserId(
        collectionName: String,
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: (() -> Unit)? = null,
    ) {
        db.collection(collectionName).whereEqualTo("userId", userId).get().addOnSuccessListener {
            it.documents.forEach { doc ->
                deleteRecord(
                    collectionName = collectionName,
                    entityId = doc.id,
                    onSuccessAction = onSuccessAction,
                    onFailureAction = onFailureAction,
                    onCanceledAction = onCanceledAction
                )
            }
        }.addOnFailureListener {
            onFailureAction()
        }.addOnCanceledListener {
            if (onCanceledAction != null) {
                onCanceledAction()
            }
        }
    }

    // NOTES
    fun retrieveNoteRecord(
        noteId: String,
        onFailureAction: () -> Unit,
    ): Flow<Note?> = callbackFlow {
        val listener = db.collection(NOTES_COLLECTION)
            .document(noteId)
            .addSnapshotListener { value, error ->
                if (error == null && value != null) {
                    val data = value.toObject(Note::class.java)
                    trySend(data)
                } else {
                    onFailureAction()
                }
            }

        awaitClose { listener.remove() }
    }

    fun retrieveAllNoteRecords(): Flow<List<Note?>> = callbackFlow {
        val listener = db.collection(NOTES_COLLECTION)
            .whereEqualTo("userId", userId)
            .addSnapshotListener { value, error ->
                if (error == null && value != null) {
                    val data = value.toObjects(Note::class.java)
                    trySend(data)
                } else {
                    //
                }
            }

        awaitClose { listener.remove() }
    }

    fun countNoteRecordsByUserId(
        linkedEntityId: String,
    ): Flow<Int?> = callbackFlow {
        val listener = db.collection(NOTES_COLLECTION)
            .whereEqualTo("userId", userId)
            .whereEqualTo("entityId", linkedEntityId).addSnapshotListener { value, error ->
                if (error == null && value != null) {
                    val dataII = value.documents.size
                    trySend(dataII)
                } else {
                    //
                }
            }

        awaitClose { listener.remove() }
    }

    fun updateNoteRecord(
        entity: Note,
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: (() -> Unit)? = null,
    ) {
        db.collection(NOTES_COLLECTION)
            .document(entity.id)
            .set(entity)
            .addOnSuccessListener {
                onSuccessAction()
            }.addOnCanceledListener {
                if (onCanceledAction != null) {
                    onCanceledAction()
                }
            }.addOnFailureListener { error ->
                error.printStackTrace()
                onFailureAction()
            }
    }

    // ANIME PICTURE RATING
    fun retrieveAnimePictureRatingRecord(
        ratingId: String,
        onFailureAction: () -> Unit,
    ): Flow<AnimePictureRating?> = callbackFlow {
        val listener = db.collection(ANIME_PICTURE_RATING_COLLECTION)
            .document(ratingId)
            .addSnapshotListener { value, error ->
                if (error == null && value != null) {
                    val data = value.toObject(AnimePictureRating::class.java)
                    trySend(data)
                } else {
                    onFailureAction()
                }
            }

        awaitClose { listener.remove() }
    }

    fun updateAnimePictureRatingRecord(
        entity: AnimePictureRating,
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: (() -> Unit)? = null,
    ) {
        db.collection(ANIME_PICTURE_RATING_COLLECTION)
            .document(entity.id)
            .set(entity)
            .addOnSuccessListener {
                onSuccessAction()
            }.addOnCanceledListener {
                if (onCanceledAction != null) {
                    onCanceledAction()
                }
            }.addOnFailureListener { error ->
                error.printStackTrace()
                onFailureAction()
            }
    }

    // Delete rating for specific user => Calls delete
//        fun deleteAllByUserId(
//        collectionName: String,
//        onSuccessAction: () -> Unit,
//        onFailureAction: () -> Unit,
//        onCanceledAction: (() -> Unit)? = null,
//    ) {

    suspend fun ratingAlreadyExists() : Boolean {
        return db.collection(ANIME_PICTURE_RATING_COLLECTION).whereEqualTo("userId", userId).get().await().isEmpty
    }

    /*
    suspend fun isUserExists(element1: String, element2: String) = callbackFlow {
        try {
            val db: FirebaseFirestore = FirebaseFirestore.getInstance()
            val dbUsers: CollectionReference = db.collection("user")

            dbUsers.whereEqualTo(element1, element2).get()
                .addOnSuccessListener {
                    trySendBlocking(it.documents.isNotEmpty())
                }.addOnFailureListener {
                    // your error action
                }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
     */
}