package com.sharonn.poppy.ui.screen

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sharonn.poppy.R
import com.sharonn.poppy.ui.components.AuthenticationButtonComponent
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.md_theme_dark_primaryContainer
import com.sharonn.poppy.ui.theme.md_theme_light_surface


@Composable
fun ErrorScreen(
    context: Context,
    onActionButtonClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = dark_custom_color_2),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.padding(bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                modifier = Modifier.size(50.dp),
                imageVector = Icons.Rounded.Error,
                contentDescription = "Error icon",
                tint = md_theme_dark_primaryContainer
            )

            Text(
                text = stringResource(id = R.string.error_screen_title),
                style = TextStyle(
                    fontSize = 50.sp,
                    fontWeight = FontWeight.Light,
                    fontStyle = FontStyle.Normal,
                    color = Color.Black
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .background(color = md_theme_light_surface, shape = RoundedCornerShape(6.dp))
                    .padding(8.dp)
            )
        }

        AuthenticationButtonComponent(
            imageVector = Icons.Filled.Login,
            value = context.getString(R.string.error_screen_access_app_button_text),
            onClickButton = onActionButtonClick
        )
    }
}
