package com.sharonn.poppy.ui.components

import android.widget.Toast
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.sharonn.poppy.R
import com.sharonn.poppy.utils.AvailableScreens
import com.sharonn.poppy.utils.VISUALIZE_IMAGE
import com.sharonn.poppy.ui.model.AnimePictureItemUI
import com.sharonn.poppy.ui.viewmodel.AnimePictureViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PictureGridItemUI(
    pictures: List<AnimePictureItemUI>,
    navController: NavController
) {
    val context = LocalContext.current
    val pictureViewModel: AnimePictureViewModel = viewModel()
    val openAlertDialog = remember { mutableStateOf(false) }
    val currentPictureId = remember { mutableLongStateOf(0) }
    val errorMessage = stringResource(id = R.string.an_error_occurred_caption)
    val confirmationMessage = stringResource(id = R.string.confirmation_registered_caption)

    when {
        openAlertDialog.value -> {
            DeletionDialog(
                onDismissRequest = { openAlertDialog.value = false },
                onConfirmation = {
                    openAlertDialog.value = false

                    Toast.makeText(
                        context,
                        confirmationMessage,
                        Toast.LENGTH_SHORT
                    ).show()

                    pictureViewModel.deleteSinglePicture(
                        pictureId = currentPictureId.longValue,
                        onError = {
                            Toast.makeText(
                                context,
                                errorMessage,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    )
                }
            )
        }
    }

    LazyVerticalStaggeredGrid(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
//    columns = StaggeredGridCells.Adaptive(200.dp),
        columns = StaggeredGridCells.Fixed(2),
        state = rememberLazyStaggeredGridState(),
        verticalItemSpacing = 5.dp,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        content = {
            items(pictures.size) { index ->
                val picture = pictures[index]

                Card(
                    modifier = Modifier.fillMaxSize(),
                    onClick = {
                        navController.navigate(
                            "${AvailableScreens.VISUALIZE_SINGLE_IMAGE_SCREEN.getScreenIdentification()}/{$VISUALIZE_IMAGE}".replace(
                                "{$VISUALIZE_IMAGE}",
                                "${picture.imageId}"
                            )
                        )
                    }
                ) {
                    AsyncImage(
                        model = picture.imageUrl,
                        contentScale = ContentScale.Crop,
                        contentDescription = "Content description",
                        error = painterResource(R.drawable.round_broken_image_white_24),
                        placeholder = painterResource(R.drawable.loading),
                        modifier = Modifier
                            .fillMaxWidth()
                            .wrapContentHeight()
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onLongPress = {
                                        openAlertDialog.value = true
                                        currentPictureId.longValue = picture.imageId
                                    },
                                    onTap = {
                                        navController.navigate(
                                            "${AvailableScreens.VISUALIZE_SINGLE_IMAGE_SCREEN.getScreenIdentification()}/{$VISUALIZE_IMAGE}".replace(
                                                "{$VISUALIZE_IMAGE}",
                                                "${picture.imageId}"
                                            )
                                        )
                                    }
                                )
                            }
                    )
                }
            }
        },
    )
}
