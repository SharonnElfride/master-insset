package com.sharonn.poppy.utils

enum class RatingParamType {
    SAFE,
    BORDERLINE,
    SUGGESTIVE
}