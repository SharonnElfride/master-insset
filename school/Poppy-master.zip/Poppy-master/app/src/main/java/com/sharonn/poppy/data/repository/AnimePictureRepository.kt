package com.sharonn.poppy.data.repository

import com.sharonn.poppy.architecture.CustomApplication
import com.sharonn.poppy.architecture.RetrofitBuilder
import com.sharonn.poppy.data.model.nekoapi.AnimePictureObject
import com.sharonn.poppy.data.model.nekoapi.toDomain
import com.sharonn.poppy.data.model.nekoapi.toDomainSingle
import com.sharonn.poppy.data.model.nekoapi.toRoom
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class AnimePictureRepository {
    private val animePictureDao = CustomApplication.instance.poppyDatabase.animePictureDao()

    private suspend fun fetchData(categories: List<String>, userId: String) {
        val result =
            RetrofitBuilder.getAnimePictures().generateRandomPicture(categories = categories)
        if (result != null) {
            val pictures = listOf(result)
            pictures.forEach { pic ->
                animePictureDao.insert(pic.toRoom(userId = userId))
            }
        }
    }

    fun deleteAll(userId: String) {
        animePictureDao.deleteAll(userId = userId)
    }

    fun getAllPictures(userId: String): Flow<List<AnimePictureObject>> {
        return animePictureDao.getAllPictures(userId = userId).map { list ->
            list.toDomain()
        }
    }

    fun getSinglePicture(pictureId: Long): AnimePictureObject {
        return animePictureDao.getSinglePicture(pictureId = pictureId).toDomainSingle()
    }

    suspend fun generateRandomPicture(categories: List<String>, userId: String) {
//        deleteAll()
        fetchData(categories = categories, userId = userId)
    }

    fun deleteSinglePicture(pictureId: Long) {
        animePictureDao.deleteSinglePicture(pictureId = pictureId)
    }
}