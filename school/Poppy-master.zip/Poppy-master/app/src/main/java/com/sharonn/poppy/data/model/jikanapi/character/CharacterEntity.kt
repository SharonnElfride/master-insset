package com.sharonn.poppy.data.model.jikanapi.character

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sharonn.poppy.utils.CHARACTER_TABLE_NAME

@Entity(tableName = CHARACTER_TABLE_NAME)
class CharacterEntity(
    @ColumnInfo(name = "userId")
    val userId: String,

    @ColumnInfo(name = "url")
    val characterUrl: String,

    @ColumnInfo(name = "imageUrl")
    val imageUrl: String? = null,

    @ColumnInfo(name = "smallImageUrl")
    val smallImageUrl: String? = null,

    @ColumnInfo(name = "name")
    val characterName: String,

    @ColumnInfo(name = "kanjiName")
    val characterKanjiName: String? = null,

    @ColumnInfo(name = "nicknames")
    val characterNicknames: String? = null,

    @ColumnInfo(name = "about")
    val characterAbout: String? = null,

    @ColumnInfo(name = "createdDate")
    val createdDate: String,

    @ColumnInfo(name = "createdTime")
    val createdTime: String,

    @ColumnInfo(name = "isFavorite")
    val isFavorite: Boolean = false
) {
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0
}