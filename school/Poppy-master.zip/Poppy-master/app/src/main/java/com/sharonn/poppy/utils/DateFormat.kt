package com.sharonn.poppy.utils

enum class DateFormat {
    DATE,
    TIME,
    ALL
}