package com.sharonn.poppy.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.sharonn.poppy.R


@Composable
fun DeletionDialog(
    onDismissRequest: () -> Unit,
    onConfirmation: () -> Unit,
) {
    DialogComponent(
        onDismissRequest = onDismissRequest,
        onConfirmation = onConfirmation,
        dialogTitle = stringResource(id = R.string.deletion_dialog_title_caption),
        dialogText = stringResource(id = R.string.deletion_dialog_message),
        icon = Icons.Rounded.Warning,
        contentDescription = "Warning icon"
    )
}

@Composable
fun AccountDeletionDialog(
    onDismissRequest: () -> Unit,
    onConfirmation: () -> Unit,
) {
    DialogComponent(
        onDismissRequest = onDismissRequest,
        onConfirmation = onConfirmation,
        dialogTitle = stringResource(id = R.string.account_deletion_dialog_title_caption),
        dialogText = stringResource(id = R.string.account_deletion_dialog_message),
        icon = Icons.Rounded.Warning,
        contentDescription = "Warning icon"
    )
}

@Composable
fun AllItemsPermanentDeletionDialog(
    onDismissRequest: () -> Unit,
    onConfirmation: () -> Unit,
) {
    DialogComponent(
        onDismissRequest = onDismissRequest,
        onConfirmation = onConfirmation,
        dialogTitle = stringResource(id = R.string.permanent_item_deletion_dialog_title),
        dialogText = stringResource(id = R.string.permanent_item_deletion_dialog_message),
        icon = Icons.Rounded.Warning,
        contentDescription = "Warning icon"
    )
}
