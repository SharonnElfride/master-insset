package com.sharonn.poppy.data.repository

import com.google.firebase.firestore.DocumentReference
import com.sharonn.poppy.data.firebase.FirestoreClient
import com.sharonn.poppy.data.model.notes.Note
import com.sharonn.poppy.utils.NOTES_COLLECTION
import kotlinx.coroutines.flow.Flow

class NoteRepository {
    private val firestoreClient = FirestoreClient()

    fun insertNote(
        entity: Map<String, String?>,
        onSuccessAction: (DocumentReference) -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: (() -> Unit)? = null,
    ) {
        firestoreClient.insertRecord(
            collectionName = NOTES_COLLECTION,
            entity = entity,
            onSuccessAction = onSuccessAction,
            onFailureAction = onFailureAction,
            onCanceledAction = onCanceledAction
        )
    }

    fun getAllNotes(): Flow<List<Note?>> {
        return firestoreClient.retrieveAllNoteRecords()
    }

    fun getNote(
        noteId: String,
        onFailureAction: () -> Unit
    ): Flow<Note?> {
        return firestoreClient.retrieveNoteRecord(
            noteId = noteId,
            onFailureAction = onFailureAction
        )
    }

    fun countNotes(
        linkedEntityId: String,
    ): Flow<Int?> {
        return firestoreClient.countNoteRecordsByUserId(
            linkedEntityId = linkedEntityId
        )
    }

    fun updateNote(
        note: Note,
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: () -> Unit,
    ) {
        firestoreClient.updateNoteRecord(
            entity = note,
            onSuccessAction = onSuccessAction,
            onFailureAction = onFailureAction,
            onCanceledAction = onCanceledAction
        )
    }

    fun deleteManyNotes(
        entityIds: List<String>,
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: () -> Unit,
    ) {
        firestoreClient.deleteMany(
            collectionName = NOTES_COLLECTION,
            entityIds = entityIds,
            onSuccessAction = onSuccessAction,
            onFailureAction = onFailureAction,
            onCanceledAction = onCanceledAction
        )
    }

    fun deleteAllNotesByUserId(
        onSuccessAction: () -> Unit,
        onFailureAction: () -> Unit,
        onCanceledAction: () -> Unit,
    ) {
        firestoreClient.deleteAllByUserId(
            collectionName = NOTES_COLLECTION,
            onSuccessAction = onSuccessAction,
            onFailureAction = onFailureAction,
            onCanceledAction = onCanceledAction
        )
    }
}