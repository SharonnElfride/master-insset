package com.sharonn.poppy.utils

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiObjects
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LibraryBooks
import androidx.compose.material.icons.rounded.LocalFlorist
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.TextSnippet
import androidx.compose.ui.graphics.vector.ImageVector
import com.sharonn.poppy.R

interface IScreen {
    fun getScreenIdentification(): String
    fun getScreenTitle(): Int
    fun getScreenIcon(): ImageVector
}

enum class AvailableScreens : IScreen {
    GET_STARTED_SCREEN {
        override fun getScreenIdentification(): String = "get_started_screen"
        override fun getScreenTitle(): Int = 0
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LocalFlorist
    },
    LOG_IN_SCREEN {
        override fun getScreenIdentification(): String = "log_in_screen"
        override fun getScreenTitle(): Int = 0
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LocalFlorist
    },
    SIGN_UP_SCREEN {
        override fun getScreenIdentification(): String = "sign_up_screen"
        override fun getScreenTitle(): Int = 0
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LocalFlorist
    },
    HOME_SCREEN {
        override fun getScreenIdentification(): String = "home_screen"
        override fun getScreenTitle(): Int = R.string.app_name
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LocalFlorist
    },
    LIBRARY_SCREEN {
        override fun getScreenIdentification(): String = "library_screen"
        override fun getScreenTitle(): Int = R.string.library_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LibraryBooks
    },
    SECRET_GALLERY_SCREEN {
        override fun getScreenIdentification(): String = "secret_gallery_screen"
        override fun getScreenTitle(): Int = R.string.secret_gallery_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.PhotoLibrary
    },
    FAVORITE_SCREEN {
        override fun getScreenIdentification(): String = "favorite_screen"
        override fun getScreenTitle(): Int = R.string.favorites_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.Favorite
    },
    PROFILE_SCREEN {
        override fun getScreenIdentification(): String = "profile_screen"
        override fun getScreenTitle(): Int = R.string.profile_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.Face
    },
    NOTES_SCREEN {
        override fun getScreenIdentification(): String = "notes_screen"
        override fun getScreenTitle(): Int = R.string.notes_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.TextSnippet
    },
    MOTIVATION_QUOTE_SCREEN {
        override fun getScreenIdentification(): String = "motivation_quote_screen"
        override fun getScreenTitle(): Int = R.string.motivation_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.EmojiObjects
    },
    ERROR_SCREEN {
        override fun getScreenIdentification(): String = "error_screen"
        override fun getScreenTitle(): Int = R.string.error_screen_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.Error
    },
    VISUALIZE_SINGLE_IMAGE_SCREEN {
        override fun getScreenIdentification(): String =
            "${VISUALIZE_SINGLE_SCREEN_PREFIX}_image_screen"

        override fun getScreenTitle(): Int = R.string.visualize_image
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LocalFlorist
    },
    VISUALIZE_SINGLE_ANIME_SCREEN {
        override fun getScreenIdentification(): String =
            "${VISUALIZE_SINGLE_SCREEN_PREFIX}_anime_screen"

        override fun getScreenTitle(): Int = R.string.anime_section_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LocalFlorist
    },
    VISUALIZE_SINGLE_MANGA_SCREEN {
        override fun getScreenIdentification(): String =
            "${VISUALIZE_SINGLE_SCREEN_PREFIX}_manga_screen"

        override fun getScreenTitle(): Int = R.string.manga_section_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LocalFlorist
    },
    VISUALIZE_SINGLE_CHARACTER_SCREEN {
        override fun getScreenIdentification(): String =
            "${VISUALIZE_SINGLE_SCREEN_PREFIX}_character_screen"

        override fun getScreenTitle(): Int = R.string.character_section_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LocalFlorist
    },
    VISUALIZE_SINGLE_NOTE_SCREEN {
        override fun getScreenIdentification(): String =
            "${VISUALIZE_SINGLE_SCREEN_PREFIX}_note_screen"

        override fun getScreenTitle(): Int = R.string.notes_title
        override fun getScreenIcon(): ImageVector = Icons.Rounded.LocalFlorist
    };

    companion object {
        fun canNav(currentDestination: String): Boolean {
            return (currentDestination == NOTES_SCREEN.getScreenIdentification() ||
                    currentDestination == SECRET_GALLERY_SCREEN.getScreenIdentification() ||
                    currentDestination == MOTIVATION_QUOTE_SCREEN.getScreenIdentification() ||
                    currentDestination.contains(VISUALIZE_SINGLE_SCREEN_PREFIX)
                    )
        }

        fun showTopAppBar(currentScreen: AvailableScreens): Boolean {
            return (currentScreen != GET_STARTED_SCREEN && currentScreen != LOG_IN_SCREEN && currentScreen != SIGN_UP_SCREEN && currentScreen != ERROR_SCREEN)
        }

        fun showBottomAppBar(currentScreen: AvailableScreens): Boolean {
            return (currentScreen == HOME_SCREEN ||
                    currentScreen == LIBRARY_SCREEN ||
                    currentScreen == FAVORITE_SCREEN ||
                    currentScreen == PROFILE_SCREEN
                    )
        }

        fun getScreen(currentDestination: String): AvailableScreens {
            return when {
                currentDestination.isEmpty() -> ERROR_SCREEN
                currentDestination == HOME_SCREEN.getScreenIdentification() -> HOME_SCREEN
                currentDestination == LIBRARY_SCREEN.getScreenIdentification() -> LIBRARY_SCREEN
                currentDestination == SECRET_GALLERY_SCREEN.getScreenIdentification() -> SECRET_GALLERY_SCREEN
                currentDestination == FAVORITE_SCREEN.getScreenIdentification() -> FAVORITE_SCREEN
                currentDestination == PROFILE_SCREEN.getScreenIdentification() -> PROFILE_SCREEN
                currentDestination == NOTES_SCREEN.getScreenIdentification() -> NOTES_SCREEN
                currentDestination == MOTIVATION_QUOTE_SCREEN.getScreenIdentification() -> MOTIVATION_QUOTE_SCREEN
                currentDestination.contains(VISUALIZE_SINGLE_ANIME_SCREEN.getScreenIdentification()) -> VISUALIZE_SINGLE_ANIME_SCREEN
                currentDestination.contains(VISUALIZE_SINGLE_MANGA_SCREEN.getScreenIdentification()) -> VISUALIZE_SINGLE_MANGA_SCREEN
                currentDestination.contains(VISUALIZE_SINGLE_CHARACTER_SCREEN.getScreenIdentification()) -> VISUALIZE_SINGLE_CHARACTER_SCREEN
                currentDestination.contains(VISUALIZE_SINGLE_IMAGE_SCREEN.getScreenIdentification()) -> VISUALIZE_SINGLE_IMAGE_SCREEN
                currentDestination.contains(VISUALIZE_SINGLE_NOTE_SCREEN.getScreenIdentification()) -> VISUALIZE_SINGLE_NOTE_SCREEN
                else -> ERROR_SCREEN
            }
        }
    }
}