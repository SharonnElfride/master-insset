package com.sharonn.poppy.domain

import com.sharonn.poppy.utils.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FormatDateUseCase {
    //    private  val formatterDate = SimpleDateFormat("EE, dd MMMM yyyy", Locale.getDefault())
    private val formatterDate = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
    private val formatterTime = SimpleDateFormat("HH:mm", Locale.getDefault())

    operator fun invoke(date: Date, format: DateFormat): String {
        return when (format) {
            DateFormat.DATE -> formatterDate.format(date)
            DateFormat.TIME -> formatterTime.format(date)
            else -> "${formatterDate.format(date)} ${formatterTime.format(date)}"
        }
    }
}