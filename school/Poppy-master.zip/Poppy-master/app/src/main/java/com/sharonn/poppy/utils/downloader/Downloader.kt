package com.sharonn.poppy.utils.downloader

interface Downloader {
    fun downloadFile(url: String, filename: String): Long
}