package com.sharonn.poppy.utils

class Validator {
    companion object {
        fun isValidEmail(email: String): Boolean {
            val emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+[a-z]+(\\.[a-z]{2,25})+\$"

            if (email.length < 3) {
                return false
            }

            // android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
//            val pattern = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
//                    "\\@" +
//                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
//                    "(" +
//                    "\\." +
//                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
//                    ")+"

            return email.matches(emailRegex.toRegex())
        }

        fun isValidPassword(password: String): Boolean {
            return password.length >= 6
        }

        fun isValidNoteTitle(title: String): Boolean {
            return title.length >= 3
        }

        fun isValidNoteContent(content: String): Boolean {
            return content.length >= 2
        }
    }
}