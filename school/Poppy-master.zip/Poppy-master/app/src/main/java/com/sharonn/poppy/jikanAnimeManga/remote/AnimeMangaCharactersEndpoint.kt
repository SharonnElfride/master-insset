package com.sharonn.poppy.jikanAnimeManga.remote

import com.sharonn.poppy.data.model.jikanapi.anime.AnimeDto
import com.sharonn.poppy.data.model.jikanapi.character.CharacterDto
import com.sharonn.poppy.data.model.jikanapi.manga.MangaDto
import retrofit2.http.GET

interface AnimeMangaCharactersEndpoint {
    // Documentation: https://docs.api.jikan.moe/#tag/random
    @GET("random/anime")
    suspend fun generateRandomAnime(): AnimeDto

    @GET("random/manga")
    suspend fun generateRandomManga(): MangaDto

    @GET("random/characters")
    suspend fun generateRandomCharacter(): CharacterDto

}