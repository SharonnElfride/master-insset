package com.sharonn.poppy.ui.screen

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.sharonn.poppy.R
import com.sharonn.poppy.utils.EntityType
import com.sharonn.poppy.ui.components.HomeIntroCardComponent
import com.sharonn.poppy.ui.components.HomeListComponent
import com.sharonn.poppy.ui.theme.dark_custom_color_2
import com.sharonn.poppy.ui.theme.md_theme_light_primary
import com.sharonn.poppy.ui.viewmodel.AnimeViewModel
import com.sharonn.poppy.ui.viewmodel.CharacterViewModel
import com.sharonn.poppy.ui.viewmodel.MangaViewModel


@Composable
fun HomeScreen(
    context: Context,
    navController: NavController = rememberNavController()
) {
    val animeViewModel: AnimeViewModel = viewModel()
    val animes = animeViewModel.firstThreeAnimes.collectAsState(emptyList()).value

    val mangaViewModel: MangaViewModel = viewModel()
    val mangas = mangaViewModel.firstThreeMangas.collectAsState(emptyList()).value

    val characterViewModel: CharacterViewModel = viewModel()
    val characters = characterViewModel.firstThreeCharacters.collectAsState(emptyList()).value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(md_theme_light_primary)
            .padding(top = 10.dp)
            .clip(shape = RoundedCornerShape(15.dp, 15.dp, 0.dp, 0.dp))
            .background(color = dark_custom_color_2)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {

        HomeIntroCardComponent(
            cardTitle = context.getString(R.string.about_me_title),
            value = context.getString(R.string.about_me_text)
        )

        HomeListComponent(
            listTitle = context.getString(R.string.anime_section_title),
            context = context,
            entityType = EntityType.ANIME,
            animes = animes,
            navController = navController
        )

        HomeListComponent(
            listTitle = context.getString(R.string.manga_section_title),
            context = context,
            entityType = EntityType.MANGA,
            mangas = mangas,
            navController = navController
        )

        HomeListComponent(
            listTitle = context.getString(R.string.character_section_title),
            context = context,
            entityType = EntityType.CHARACTER,
            characters = characters,
            navController = navController
        )
    }
}
