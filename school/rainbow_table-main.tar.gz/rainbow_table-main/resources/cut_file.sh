#!/bin/bash

echo "Let's do it"

filename='words_ccm_2023.txt'
echo "Started"

while read f; do
    echo "$f"
    firstLetter=${f:0:1}
    echo "$f" >> "./words/$firstLetter.txt"
done < "$filename"

echo "Done"

