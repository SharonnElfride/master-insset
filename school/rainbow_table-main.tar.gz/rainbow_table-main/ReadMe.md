# Rainbow Table Attack 
### Projet de cryptologie 

### Étudiantes : 
* Ahouefa Sharonn Zounon - 22209209
* Chorouq Laarouja - 22107023

### Description succinct 
Ce projet porte sur les attaques par rainbow table. \
Nous proposons donc notre approche du sujet.
***
L'arborescence du projet est la suivante : 
```
zounon_laarouja_rainbow_table/
├── ReadMe.md
├── report
│   └── rainbow_table_report.pdf
├── resources
│   ├── cut_file.sh
│   ├── hash_challenges.txt
│   ├── hash_sample.py
│   ├── img
│   │   └── func.png
│   ├── words
│   │   └── {a..z}.txt
│   └── words_ccm_2023.txt
└── src
    ├── attack_code.py
    ├── default_passwords_list.txt
    ├── encountered_passwords.txt
    ├── log_file.txt
    ├── main.py
    ├── rainbow_table_creation.py
    ├── rainbow_table.txt
    ├── reduction_function.py
    └── three_cases_test_log.txt

5 directories, 42 files
```
___
___

* Le fichier _**rainbow\_table\_report.txt**_ est le rapport de travail. 
* Le fichier _**cut\_file.sh**_ permet de ranger les différents mots anglais selon leur première lettre dans différents fichiers du dossier _**words**_. 
Le fichier est à exécuter une seule fois uniquement et si besoin. 
* Le fichier _**hash\_challenges.txt**_ est l'ensemble des hachés fournis à attaquer. 
* Le fichier _**hash\_sample.txt**_ est le fichier contenant la fonction permettant de hasher un mot de passe clair. 
* Le fichier _**func.png**_ est un exemple de l'énoncé. 
* Le dossier _**words**_ contient tous les mots anglais rangés dans différents documents en fonction de leur première lettre.
* Le fichier _**words\_ccm\_2023.txt**_ est l'ensemble des mots anglais fournis.
* Le fichier _**attack\_code.py**_ contient la fonction d'attaque et d'autres fonctions utilisées par celle-ci.
* Le fichier _**default_passwords_list.txt**_ contient la liste des mots de passe initiaux utilisés pour créer la rainbow table.
* Le fichier _**encountered\_passwords.txt**_ contient la liste des mots rencontrés lors d'un processus d'attaque.
* Le fichier _**log\_file.txt**_ est le fichier de log dans lequel sont renseignés les logs de l'attaque avec les valeurs fournies du challenge.
* Le fichier _**main.py**_ contient la fonction main. 2 différents de test d'attaque y sont inscrits. 
* Le fichier _**rainbow\_table\_creation.py**_ contient la fonction de création d'une rainbow table et d'autres fonctions utilisées par celle-ci.
* Le fichier _**rainbow\_table.txt**_ => **La Rainbow Table**.
* Le fichier _**reduction_function.py**_ contient la fonction de réduction et d'autres fonctions utilisées par celle-ci.
* Le fichier _**three_cases_test_log.txt**_ est le fichier de log dans lequel sont renseignés les logs de l'attaque avec les valeurs choisies.
___
___

##### _**Le code source du projet est disponible.**_
##### _**Vous pouvez exécuter le main, mais lisez les commentaires pour mieux comprendre.**_

