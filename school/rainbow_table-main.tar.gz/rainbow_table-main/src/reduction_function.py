# Zounon Ahouefa Sharonn Elfride - Chorouq Laarouja - Master CCM1 - INSSET 2022/2023
# Here are the reduction functions

# Imports

# Global variables
# The words directory pathname
words_directory_pathname = "./../resources/words/"

# The file containing all the seen passwords during the rainbow table creation
encountered_passwords = "./encountered_passwords.txt"

# The file containing all the words
words_file = "./../resources/words_ccm_2023.txt"


# Check if the given word is in the words list
def check_if_word_in_words(word: str):
    with open(words_file, "r") as words:
        if word in words:
            return True

    return False


# Check if the given value contains all the characters in 'characters' (list of characters - string)
def value_contains_all_characters(value, characters):
    for c in characters:
        if c not in value:
            return False

    return True


# Gets the word in the words file that contains all the characters in 'characters' (list of characters - string)
def get_string_containing_all_characters(characters):
    with open(words_file, "r") as words:
        for word in words:
            word = word.replace(" ", "").replace("\n", "")
            if value_contains_all_characters(word, characters):
                return word
    return ""


# Helps to make a password from the given part of the hash value
def make_password(hash_part_value, word):
    letter_number = 0
    letters_position = []

    for c in hash_part_value:
        if c.isalpha():
            letters_position.append(letter_number)
        letter_number += 1

    for c in word:
        pos = letters_position.pop(0)
        hash_part_value = hash_part_value[:pos] + c + hash_part_value[pos + 1:]

    return hash_part_value


# Gets the first word starting from the given letter (the words are in the directory 'words' in resources)
def get_first_word(letter):
    with open(words_directory_pathname + letter + ".txt", "r") as f:
        word = f.readline().strip("\n").strip(" ")
    return word


# Helps to generate a password from the given hash value
def generate_password(hash_value):
    digit_number = 0
    letter_number = 0
    hash_value_part = ""
    numbers = ""
    letters = ""

    for letter in hash_value:
        if len(hash_value_part) > 10:
            break
        else:
            if letter.isdigit():
                if digit_number >= 4:
                    continue
                else:
                    numbers += numbers.join(letter)
                    hash_value_part += hash_value_part.join(letter)
                    digit_number += 1

            if letter.isalpha():
                if letter_number >= 6:
                    continue
                else:
                    letters += letters.join(letter)
                    hash_value_part += hash_value_part.join(letter)
                    letter_number += 1

    if len(letters) < 6:
        for i in range(len(letters), 6):
            letters += letters.join("a")
            hash_value_part += hash_value_part.join("a")

    if len(numbers) < 4:
        for i in range(len(numbers), 1):
            letters += letters.join("1")
            hash_value_part += hash_value_part.join("1")

    if check_if_word_in_words(letters):
        return hash_value_part
    else:
        distinct_letters = "".join(dict.fromkeys(letters).keys())
        word = get_string_containing_all_characters(distinct_letters)  # search the string having all the letters

        if word == "":
            word = get_first_word(distinct_letters[0])

        password = make_password(hash_value_part, word)
    return password


# The function of reduction used to make the rainbow table
def reduction_function(hash_value: str):
    password = generate_password(hash_value)
    with open(encountered_passwords, "a+") as passwords:
        if password in passwords:
            hash_value = hash_value[::-1]  # inverse the hash value
            password = generate_password(hash_value)

        # Move read cursor to the start of file.
        passwords.seek(0)
        # If file is not empty then append '\n'
        data = passwords.read(100)
        if len(data) > 0:
            passwords.write("\n")
        # Append text at the end of file
        passwords.write(password)

    return password
