# Zounon Ahouefa Sharonn Elfride - Master CCM1 - INSSET 2022/2023
# Here is the main code

# Imports
import time
from rainbow_table_creation import create_rainbow_table
from attack_code import attack_hash_value

if __name__ == '__main__':

    hash_challenges = "./../resources/hash_challenges.txt"

    # Rainbow table creation - Run only once because the rainbow table might change
    # start_time = time.time()
    # rb_tab_created = create_rainbow_table()
    # print("Time of rainbow table creation : ")
    # print("--- %s seconds ---" % (time.time() - start_time))
    #
    # if rb_tab_created:
    #     print("Done!")
    # else:
    #     print("Not created")

    print("\n *********************************************************************************** \n")

    # ATTACK TESTS

    # With chosen values 
    three_cases_log = "three_cases_test_log.txt"
    open(three_cases_log, "w").close()  # Clear the log file

    with open(three_cases_log, "a+") as file:
        file.write("First case : \n")
        file.write("The hash value to crack is already in the rainbow table \n")

        hash_value = "bf8bdf2e60e8afafd361b139e777d857"  # returns the password : 1abc218ess
        start_time = time.time()
        attack_value = attack_hash_value(hash_value, hash_value)
        attack_time = time.time() - start_time
        file.write(hash_value + " => " + attack_value + " / attack time = %s \n\n" % attack_time)

        file.write("Second case : \n")
        file.write("The hash value to crack is not in the rainbow table but is in one of the multiple chains \n")
        # In our example, the hash is in the chain of '1vir47ol6e' password
        hash_value = "c3eac90282c577b5b4838a8cbbbb20d3"
        start_time = time.time()
        # Finds "bf8bdf2e60e8afafd361b139e777d857" through the loop and returns the password : 127a3faced
        attack_value = attack_hash_value(hash_value, hash_value)
        attack_time = time.time() - start_time
        file.write(hash_value + " => " + attack_value + " / attack time = %s \n\n" % attack_time)

        file.write("Third case : \n")
        file.write("The hash value to crack is not in the rainbow table and is not in one of the multiple chains \n")
        # In this example we chose one of the challenge hash values
        hash_value = "b8469b90f19f77b14a63e3900fbd2ea3"
        start_time = time.time()
        # Returns 'Password not found !' after trying the 100th time
        attack_value = attack_hash_value(hash_value, hash_value)
        attack_time = time.time() - start_time
        file.write(hash_value + " => " + attack_value + " / attack time = %s \n" % attack_time)

    # With the hash values in hash_challenges.txt
    # log_file = "log_file.txt"
    # open(log_file, "w").close()  # Clear the log file
    #
    # attack_times = []
    # average_attack_time = 0
    #
    # with open(hash_challenges, "r") as hash_values, open(log_file, "a+") as file:
    #     for hash_value in hash_values:
    #         hash_value = hash_value.replace(" ", "").replace("\n", "")
    #         print("Hash to attack: " + hash_value)
    #         print("Attack result : ")
    #         start_time2 = time.time()
    #         attack_value = attack_hash_value(hash_value, hash_value)
    #         print(attack_value)
    #         print("Attack time : ")
    #         attack_time = time.time() - start_time2
    #         attack_times.append(attack_time)
    #         print("--- %s seconds ---" % attack_time)
    #         file.write(hash_value + " => " + attack_value + " / attack time = %s \n" % attack_time)
    #         print("\n")
    #
    #     average_attack_time = sum(attack_times)/len(attack_times)
    #     file.write("\n")
    #     file.write("The average attack time = %s \n" % round(average_attack_time, 3))
