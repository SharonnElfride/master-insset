# Zounon Ahouefa Sharonn Elfride - Chorouq Laarouja - Master CCM1 - INSSET 2022/2023
# Here are the functions used to create the rainbow table

# Imports
import os
import random
import shutil

from reduction_function import reduction_function

# Global variables
# The complete list of words
words_list_pathname = "./../resources/words_ccm_2023.txt"

# The default list of passwords used in the rainbow table
default_passwords_list = "./default_passwords_list.txt"

# The list of encountered passwords
encountered_passwords = "./encountered_passwords.txt"

# The rainbow table
rainbow_table = "./rainbow_table.txt"

# The default number of passwords
default_passwords_number = 200

# The chain length
chain_length = 15


# Mixes the numbers with the letters (randomly)
def mixing_number_and_word(word, number):
    w = [x for x in word]
    n = [x for x in number]
    result = "".join(x.pop(0) for x in random.sample([w] * len(w) + [n] * len(n), len(w) + len(n)))

    return result


# Generates a password (randomly)
def generate_default_password(chosen_word: str, chosen_number: str):
    chosen_word = chosen_word.replace(" ", "").replace("\n", "")

    passwords = open(encountered_passwords).read()
    for i in range(10):
        password = mixing_number_and_word(chosen_word, chosen_number)

        # verify if password is in the encountered passwords list
        if password in passwords:
            continue
        else:
            with open(encountered_passwords, "a+") as passwd_file:  # Open in append & read mode
                if password not in passwd_file:  # .read():
                    # Move read cursor to the start of file.
                    passwd_file.seek(0)
                    # If file is not empty then append '\n'
                    data = passwd_file.read(100)
                    if len(data) > 0:
                        passwd_file.write("\n")
                    # Append text at the end of file
                    passwd_file.write(password)

            return password

    return ""


# Hashes a password
def hash_password(password):
    test = os.popen("python3 ./../resources/hash_sample.py " + password).read()
    test = test.replace("\n", "")
    hash_value = test.split(": ")[-1]

    return hash_value


# Creates the default passwords used in the rainbow table
def create_passwords_list():
    # Clear the default passwords
    open(default_passwords_list, "w").close()

    for i in range(default_passwords_number):
        word = random.choice(list(open(words_list_pathname)))
        nb = random.randint(0, 9999)
        number = f'{nb:04}'

        while True:
            password = generate_default_password(word, number)
            if password != "":
                with open(default_passwords_list, "a+") as passwd_file:  # Open in append & read mode
                    if password not in passwd_file.read():
                        # Move read cursor to the start of file.
                        passwd_file.seek(0)
                        # If file is not empty then append '\n'
                        data = passwd_file.read(100)
                        if len(data) > 0:
                            passwd_file.write("\n")
                        # Append text at the end of file
                        passwd_file.write(password)

                break

    return True


# Makes one chain and returns the final hash value
def make_one_chain(password):
    passwd = password.replace(" ", "").replace("\n", "")
    current_passwd = passwd
    hash_value = ""

    for i in range(chain_length):
        # hash it
        hash_value = hash_password(current_passwd)
        new_pwd = reduction_function(hash_value)
        current_passwd = new_pwd

    return hash_value


# Creates the rainbow table
def create_rainbow_table():
    # Clear all the files used in the process
    open(rainbow_table, "w").close()
    open(encountered_passwords, "w").close()

    if os.stat(default_passwords_list).st_size == 0:
        create_passwords_list()

    # Copy the passwords from the default list to the encountered ones file
    shutil.copyfile(default_passwords_list, encountered_passwords)
    with open(default_passwords_list, "r") as passwords:
        for password in passwords:
            password = password.replace(" ", "").replace("\n", "")
            while True:
                if password != "":
                    hash_value = make_one_chain(password)
                    # put both in rainbow_table.txt
                    with open(rainbow_table, "a+") as passwd_file:  # Open in append & read mode
                        if password not in passwd_file.read():
                            # Move read cursor to the start of file.
                            passwd_file.seek(0)
                            # If file is not empty then append '\n'
                            data = passwd_file.read(100)
                            if len(data) > 0:
                                passwd_file.write("\n")
                            # Append text at the end of file
                            passwd_file.write(password + "=>" + hash_value)

                    break
    return True


