# Zounon Ahouefa Sharonn Elfride - Chorouq Laarouja - Master CCM1 - INSSET 2022/2023
# Here are the functions used to proceed to the attack
import shutil

# Imports
from rainbow_table_creation import hash_password
from reduction_function import reduction_function

# Global variables
# The rainbow table
rainbow_table = "./rainbow_table.txt"

# The file containing all the seen passwords during the rainbow table creation
encountered_passwords = "./encountered_passwords.txt"

# The default list of passwords used in the rainbow table
default_passwords_list = "./default_passwords_list.txt"

# The chain length
chain_length = 15

# The number of times we're trying to decrypt a password
attack_times_max = 100
attack_times = 0


# Checks if the given hash value is in the rainbow table. If yes, returns the password. Otherwise, returns ""
def check_if_hash_in_rainbow_table(hash_value):
    with open(rainbow_table, "r") as rb_table:
        for line in rb_table:
            line = line.replace(" ", "").replace("\n", "")
            info = line.split("=>")
            if info[-1] == hash_value:
                return info[0]

    return ""


# Gets a password from the given hash value using the function of reduction
def get_password(hash_value):
    new_pwd = reduction_function(hash_value)
    return new_pwd


# Attacks one hash value
def attack_hash_value(hash_value: str, original_hash_value: str):
    open(encountered_passwords, "w").close()
    # Copy the passwords from the default list to the encountered ones file
    shutil.copyfile(default_passwords_list, encountered_passwords)

    global attack_times
    attack_times += 1
    if attack_times <= attack_times_max:  # We stop trying after the 100th time
        rainbow_table_value = check_if_hash_in_rainbow_table(hash_value)

        if rainbow_table_value != "":
            print("Hash found in rainbow table")
            current_passwd = rainbow_table_value
            # If the password can't be recovered in one complete chain, we stop the loop and exit
            for i in range(chain_length):
                current_hash_value = hash_password(current_passwd)
                if current_hash_value == original_hash_value:
                    password_found = current_passwd
                    return password_found
                else:
                    rb_psswd = check_if_hash_in_rainbow_table(current_hash_value)
                    if rb_psswd != "":
                        new_passwd = rb_psswd
                    else:
                        new_passwd = get_password(current_hash_value)
                    current_passwd = new_passwd

        else:
            current_passwd = get_password(hash_value)
            current_hash_value = hash_password(current_passwd)
            return attack_hash_value(current_hash_value, original_hash_value)

    if attack_times == 100:
        attack_times = 0

    return "Password not found !"

