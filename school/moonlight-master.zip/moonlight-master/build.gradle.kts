// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.1.1" apply false
    id("org.jetbrains.kotlin.android") version "1.8.10" apply false

    // Added by Sharonn - 15/09/2023
    id("com.google.devtools.ksp") version "1.8.10-1.0.9" apply false

    // Added by Sharonn on October 20th of 2023
    // Add the dependency for the Google services Gradle plugin
    id("com.google.gms.google-services") version "4.4.0" apply false
}
true // Needed to make the Suppress annotation work for the plugins block