package com.sharonn.moonlight.data.repository

import com.sharonn.moonlight.architecture.CustomApplication
import com.sharonn.moonlight.architecture.RetrofitBuilder
import com.sharonn.moonlight.data.model.chucknorris.ChuckNorrisObject
import com.sharonn.moonlight.data.model.chucknorris.toDomain
import com.sharonn.moonlight.data.model.chucknorris.toRoom
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.reduce
import kotlinx.coroutines.runBlocking

class ChuckNorrisRepository {
    private val chuckNorrisDao = CustomApplication.instance.moonLightDatabase.chuckNorrisDao()

    suspend fun fetchData() {
        chuckNorrisDao.insert(RetrofitBuilder.getChuckNorrisQuote().getRandomQuote().toRoom())
    }

    fun deleteAll() {
        chuckNorrisDao.deleteAll()
    }

    fun selectAll(): Flow<List<ChuckNorrisObject>> {
        return chuckNorrisDao.selectAll().map { list ->
            list.toDomain()
        }
    }

//    fun countAll(): Int {
//        return chuckNorrisDao.countAll()
//    }

//    fun countAll(): Int = runBlocking {
//        val count = async {
//            chuckNorrisDao.countAll()
//        }
//        count.start()
//        count.await()
//    }
}