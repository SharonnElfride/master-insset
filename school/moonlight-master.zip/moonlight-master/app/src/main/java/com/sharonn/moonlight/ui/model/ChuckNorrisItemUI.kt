package com.sharonn.moonlight.ui.model

import com.sharonn.moonlight.data.model.chucknorris.ChuckNorrisObject

data class ChuckNorrisItemUI(
    val quote: String,
    val iconUrl: String,
)

fun List<ChuckNorrisObject>.toUi(): List<ChuckNorrisItemUI> {
    return map { chuckItem ->
        ChuckNorrisItemUI(
            quote = chuckItem.title,
            iconUrl = chuckItem.url
        )
    }
}