package com.sharonn.moonlight.data.model.chucknorris

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sharonn.moonlight.architecture.DatabaseKeyName.Companion.CHUCK_NORRIS_TABLE_NAME

@Entity(tableName = CHUCK_NORRIS_TABLE_NAME)
data class ChuckNorrisEntity(
    // Insomnia to see network calls

    @ColumnInfo(name = "quote")
    val quote: String,

    @ColumnInfo(name = "icon")
    val iconUrl: String
) {
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0
}