package com.sharonn.moonlight.data.model.androidversion

data class AndroidVersion(
    val versionName: String,
    val versionNumber: String,
    val publisher: String? = null
)