package com.sharonn.moonlight.ui.model

import com.sharonn.moonlight.data.model.androidversion.AndroidVersion

sealed interface AndroidVersionItemUI {
    data class Item(
        val versionNumber: String,
        val publisher: String? = null
    ) : AndroidVersionItemUI

    data class Header(
        val title: String
    ) : AndroidVersionItemUI

    data class Footer(
        val amount: Int,
        val distributionYear: String? = null,
    ) : AndroidVersionItemUI


    data class CompleteItem(
        val versionName: String,
        val androidVersions: List<AndroidVersion>,
        val amount: Int,
        val distributionYear: String? = null,
    ) : AndroidVersionItemUI
}

fun List<AndroidVersion>.toUi(): List<AndroidVersionItemUI.Item> {
    return map { androidVersion ->
        AndroidVersionItemUI.Item(
            versionNumber = androidVersion.versionNumber,
            publisher = androidVersion.publisher
        )
    }
}
