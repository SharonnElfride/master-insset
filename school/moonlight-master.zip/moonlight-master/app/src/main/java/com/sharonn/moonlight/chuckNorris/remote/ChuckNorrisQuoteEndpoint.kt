package com.sharonn.moonlight.chuckNorris.remote

import com.sharonn.moonlight.data.model.chucknorris.ChuckNorrisDto
import retrofit2.http.GET

interface ChuckNorrisQuoteEndpoint {
    @GET("random")
    suspend fun getRandomQuote() : ChuckNorrisDto
}