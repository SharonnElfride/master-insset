package com.sharonn.moonlight.data.model.chucknorris

data class ChuckNorrisObject(
    val title: String,
    val url: String,
)


fun List<ChuckNorrisEntity>.toDomain(): List<ChuckNorrisObject> {
    return map { eachEntity ->
        ChuckNorrisObject(
            title = eachEntity.quote,
            url = eachEntity.iconUrl,
        )
    }
}