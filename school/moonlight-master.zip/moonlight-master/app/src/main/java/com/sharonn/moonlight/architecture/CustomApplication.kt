package com.sharonn.moonlight.architecture

import android.app.Application
import androidx.room.Room

class CustomApplication : Application() {
    companion object {
        lateinit var instance: CustomApplication
    }

    val moonLightDatabase: CustomRoomDatabase by lazy {
        Room.databaseBuilder(
            applicationContext,
            CustomRoomDatabase::class.java,
//            "moonlightDatabase"
            DatabaseKeyName.MOONLIGHT_DATABASE_NAME
//        ).fallbackToDestructiveMigration().allowMainThreadQueries().build()
        ).fallbackToDestructiveMigration().build()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}