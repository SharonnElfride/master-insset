package com.sharonn.moonlight.architecture


class DatabaseKeyName {
    companion object {
        const val MOONLIGHT_DATABASE_NAME = "moonlightDatabase"

        const val ANDROID_VERSION_TABLE_NAME = "android_version_table"
        const val CHUCK_NORRIS_TABLE_NAME = "chuck_norris_table"
    }
}