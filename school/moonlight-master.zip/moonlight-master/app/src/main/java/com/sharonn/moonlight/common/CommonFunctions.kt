package com.sharonn.moonlight.common

import androidx.compose.ui.graphics.Color
import com.sharonn.moonlight.common.CommonData.Companion.publisherNames
import com.sharonn.moonlight.common.CommonData.Companion.publisherSurnames
import com.sharonn.moonlight.data.model.androidversion.AndroidVersion
import com.sharonn.moonlight.ui.navigation.NavigationPath
import com.sharonn.moonlight.ui.viewmodel.AndroidVersionViewModel
import com.sharonn.moonlight.ui.viewmodel.ChuckNorrisQuoteViewModel
import kotlin.random.Random

class CommonFunctions {
    companion object {
        private val androidVersionViewModel = AndroidVersionViewModel()
        private val chuckNorrisQuoteViewModel = ChuckNorrisQuoteViewModel()

        fun providerListOfAndroidVersion(): List<AndroidVersion> {
            return listOf(
                AndroidVersion(
                    versionName = "HoneyComb", versionNumber = "3.0", publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Ice Cream Sandwich",
                    versionNumber = "4.0",
                    publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Ice Cream Sandwich",
                    versionNumber = "4.0.1",
                    publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Ice Cream Sandwich",
                    versionNumber = "4.0.2",
                    publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Ice Cream Sandwich",
                    versionNumber = "4.0.3",
                    publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Jelly Bean", versionNumber = "4.1", publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Jelly Bean", versionNumber = "4.2", publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Jelly Bean", versionNumber = "4.3", publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Kitkat", versionNumber = "4.4", publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Lollipop", versionNumber = "5.0", publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Lollipop", versionNumber = "5.1", publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Marshmallow",
                    versionNumber = "6.0",
                    publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Nougat", versionNumber = "7.0", publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Oreo", versionNumber = "8.0", publisher = randomPublisher()
                ),
                AndroidVersion(
                    versionName = "Oreo", versionNumber = "8.1", publisher = randomPublisher()
                ),
            )
        }

        fun String.toColor() = Color(android.graphics.Color.parseColor(this))

        fun randomPublisher(): String {
            val untilNumber =
                if (publisherSurnames.size < publisherNames.size) publisherSurnames.size else publisherNames.size
            return Random.nextInt(from = 0, until = untilNumber)
                .let { randomNumber -> "${publisherNames[randomNumber]} ${publisherSurnames[randomNumber]}" }
        }

        fun addNewItem(currentDestination: String): Boolean {
            when (currentDestination) {
                NavigationPath.ANDROID_VERSION_LIST_SCREEN -> {
                    androidVersionViewModel.insertAndroidVersion()
                    return true
                }

                NavigationPath.EXPERIMENTAL_ANDROID_VERSION_LIST_SCREEN -> {
                    androidVersionViewModel.insertAndroidVersion()
                    return true
                }

                NavigationPath.CHUCK_NORRIS_QUOTE_SCREEN -> {
                    chuckNorrisQuoteViewModel.insertNewQuote()
                    return true
                }
            }

            return false
        }

        fun allItemsDeletion(currentDestination: String): Boolean {
            when (currentDestination) {
                NavigationPath.ANDROID_VERSION_LIST_SCREEN -> {
//                    if(androidVersionViewModel.androidVersionCount >= 1) {
                    androidVersionViewModel.deleteAllAndroidVersion()
                    return true
//                    }
                }

                NavigationPath.EXPERIMENTAL_ANDROID_VERSION_LIST_SCREEN -> {
                    androidVersionViewModel.deleteAllAndroidVersion()
                    return true
                }

                NavigationPath.CHUCK_NORRIS_QUOTE_SCREEN -> {
//                    if (chuckNorrisQuoteViewModel.quotesCount >= 1) {
                    chuckNorrisQuoteViewModel.deleteAllQuote()
                    return true
//                    }
                }
            }

            return false
        }
    }
}