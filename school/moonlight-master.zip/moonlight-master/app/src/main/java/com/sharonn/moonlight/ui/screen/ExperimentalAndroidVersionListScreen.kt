package com.sharonn.moonlight.ui.screen

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sharonn.moonlight.R
import com.sharonn.moonlight.ui.model.AndroidVersionItemUI
import com.sharonn.moonlight.ui.viewmodel.AndroidVersionViewModel

@Composable
fun ExperimentalAndroidVersionListScreen() {
    val viewModel: AndroidVersionViewModel = viewModel()
    val list = viewModel.experimentalAndroidVersionList.collectAsState(emptyList()).value

    LazyColumn(
        modifier = Modifier.padding(15.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        items(count = list.size) { number ->
            AndroidVersionItemCard(list[number])
        }
    }
}

@Composable
private fun AndroidVersionItemCard(currentItem: AndroidVersionItemUI) {
    Card(
        modifier = Modifier
            .fillMaxSize(),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        )
    ) {
        var expanded by remember { mutableStateOf(false) }
        Column(
            modifier = Modifier.clickable { expanded = !expanded }
        ) {
            when (currentItem) {
                is AndroidVersionItemUI.CompleteItem -> {
                    Column(
                        verticalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                                contentDescription = "Favorite icon",
                                modifier = Modifier.padding(start = 10.dp)
                            )

                            Text(
                                text = "${currentItem.versionName} - click here",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }

                        Divider(
                            color = MaterialTheme.colorScheme.onSurface,
                            thickness = 1.dp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }

                    AnimatedVisibility(visible = expanded) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            currentItem.androidVersions.forEach { av ->
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    val itemText = "${av.versionNumber} by ${av.publisher ?: "X"}"

                                    Text(
                                        text = itemText,
                                        fontSize = 20.sp,
                                    )
                                }
                            }

                            Divider(
                                color = MaterialTheme.colorScheme.onSurface,
                                thickness = 1.dp,
                                modifier = Modifier.padding(horizontal = 10.dp)
                            )
                        }
                    }

                    Column(
                        modifier = Modifier.padding(10.dp),
                    ) {
                        val existingVersions = pluralStringResource(
                            id = R.plurals.number_of_existing_android_versions,
                            count = currentItem.amount,
                            currentItem.amount
                        )

                        Text(
                            text = "$existingVersions on ${currentItem.distributionYear}",
                            fontWeight = FontWeight.Medium,
                            fontSize = 17.sp,
                            fontStyle = FontStyle.Italic
                        )
                    }
                }

                else -> {}
            }
        }
    }
}
