package com.sharonn.moonlight.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sharonn.moonlight.common.CommonData.Companion.androidVersionNames
import com.sharonn.moonlight.common.CommonData.Companion.distributionYear
import com.sharonn.moonlight.common.CommonFunctions
import com.sharonn.moonlight.data.model.androidversion.AndroidVersion
import com.sharonn.moonlight.data.repository.AndroidVersionRepository
import com.sharonn.moonlight.ui.model.AndroidVersionItemUI
import com.sharonn.moonlight.ui.model.toUi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.random.Random

class AndroidVersionViewModel : ViewModel() {
    // Instance du repository
    private val androidVersionRepository: AndroidVersionRepository by lazy { AndroidVersionRepository() }

    private val _androidVersionList: Flow<List<AndroidVersionItemUI>>
        get() = androidVersionRepository.selectAllAndroidVersion().map { androidVersionList ->
            androidVersionList.groupBy { androidVersion ->
                androidVersion.versionName
            }
                .flatMap {
                    buildList {
                        add(
                            AndroidVersionItemUI.Header(
                                title = it.key, // versionName
                            )
                        )

                        addAll(it.value.toUi()) // List of android version number for the given name

                        add(
                            AndroidVersionItemUI.Footer(
                                amount = it.value.size
                            )
                        )
                    }
                }
        }

    // On rend accessible uniquement en lecture la valeur de la variable mutable afin de bloquer l'accès
    val androidVersionList = _androidVersionList


//    private val _androidVersionCount
//        get() = androidVersionRepository.countAll()
//    val androidVersionCount = _androidVersionCount


    private val _experimentalAndroidVersionList: Flow<List<AndroidVersionItemUI>>
        get() = androidVersionRepository.selectAllAndroidVersion().map { androidVersionList ->
            androidVersionList.groupBy { androidVersion ->
                androidVersion.versionName
            }
                .flatMap {
                    buildList {
                        add(
                            AndroidVersionItemUI.CompleteItem(
                                versionName = it.key,
                                androidVersions = it.value,
                                amount = it.value.size,
                                distributionYear = "${distributionYear[Random.nextInt(0, distributionYear.size)]}"
                            )
                        )

                        add(
                            AndroidVersionItemUI.Header(
                                title = it.key, // versionName
                            )
                        )

                        addAll(it.value.toUi()) // List of android version number for the given name

                        add(
                            AndroidVersionItemUI.Footer(
                                amount = it.value.size
                            )
                        )
                    }
                }
        }

    val experimentalAndroidVersionList = _experimentalAndroidVersionList

    fun insertAndroidVersion() {
        viewModelScope.launch(Dispatchers.IO) {
            val majVersion = Random.nextInt(1, 10)
            val minVersion = Random.nextInt(0, 10)
            val random = Random.nextInt(0, androidVersionNames.size)
            androidVersionRepository.insertAndroidVersion(
                AndroidVersion(
                    versionName = androidVersionNames[random],
                    versionNumber = "$majVersion.$minVersion",
                    publisher = CommonFunctions.randomPublisher()
                )
            )
        }
    }

    fun deleteAllAndroidVersion() {
        viewModelScope.launch(Dispatchers.IO) {
            androidVersionRepository.deleteAllAndroidVersion()
        }
    }
}