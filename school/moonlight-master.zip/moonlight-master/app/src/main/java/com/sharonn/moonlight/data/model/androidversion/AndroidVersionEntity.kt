package com.sharonn.moonlight.data.model.androidversion

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sharonn.moonlight.architecture.DatabaseKeyName

@Entity(tableName = DatabaseKeyName.ANDROID_VERSION_TABLE_NAME)
data class AndroidVersionEntity(
    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "code")
    val code: String,

    @ColumnInfo(name = "publisher")
    val publisher: String? = null,
) {
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0
}

fun AndroidVersion.toRoomObject(): AndroidVersionEntity {
    return AndroidVersionEntity(
        name = versionName,
        code = versionNumber,
        publisher = publisher
    )
}


fun List<AndroidVersionEntity>.toDomain(): List<AndroidVersion> {
    return map { eachItem ->
        AndroidVersion(
            versionName = eachItem.name,
            versionNumber = eachItem.code,
            publisher = eachItem.publisher
        )
    }
}