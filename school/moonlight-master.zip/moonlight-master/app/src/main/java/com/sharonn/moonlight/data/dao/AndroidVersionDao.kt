package com.sharonn.moonlight.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sharonn.moonlight.architecture.DatabaseKeyName.Companion.ANDROID_VERSION_TABLE_NAME
import com.sharonn.moonlight.data.model.androidversion.AndroidVersionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AndroidVersionDao {

    @Query("SELECT * FROM $ANDROID_VERSION_TABLE_NAME ORDER BY name ASC")
    fun selectAll(): Flow<List<AndroidVersionEntity>>

//    @Query("SELECT COUNT(*) FROM $ANDROID_VERSION_TABLE_NAME")
//    fun countAll(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(androidVersion: AndroidVersionEntity)


    @Query("DELETE FROM $ANDROID_VERSION_TABLE_NAME")
    fun deleteAll()
}
