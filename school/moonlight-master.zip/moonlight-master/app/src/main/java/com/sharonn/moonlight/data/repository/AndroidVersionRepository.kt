package com.sharonn.moonlight.data.repository

import com.sharonn.moonlight.architecture.CustomApplication
import com.sharonn.moonlight.data.model.androidversion.AndroidVersion
import com.sharonn.moonlight.data.model.androidversion.toDomain
import com.sharonn.moonlight.data.model.androidversion.toRoomObject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class AndroidVersionRepository {
    private val androidVersionDao =
        CustomApplication.instance.moonLightDatabase.androidVersionDao()

    fun selectAllAndroidVersion(): Flow<List<AndroidVersion>> {
        return androidVersionDao.selectAll().map {
            it.toDomain()
        }
    }

//    fun countAll(): Int {
//        return androidVersionDao.countAll()
//    }

    fun insertAndroidVersion(androidVersion: AndroidVersion) {
        androidVersionDao.insert(androidVersion.toRoomObject())
    }

    fun deleteAllAndroidVersion() {
        androidVersionDao.deleteAll()
    }
}