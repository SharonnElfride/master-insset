package com.sharonn.moonlight.ui.viewmodel

import androidx.compose.runtime.collectAsState
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sharonn.moonlight.data.repository.ChuckNorrisRepository
import com.sharonn.moonlight.ui.model.ChuckNorrisItemUI
import com.sharonn.moonlight.ui.model.toUi
import com.sharonn.moonlight.ui.screen.ChuckNorrisQuoteScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.count
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch

class ChuckNorrisQuoteViewModel : ViewModel() {
    private val chuckNorrisQuoteRepository: ChuckNorrisRepository by lazy { ChuckNorrisRepository() }
    private val _quotes: Flow<List<ChuckNorrisItemUI>>
        get() = chuckNorrisQuoteRepository.selectAll().map { list ->
            list.toUi()
        }

//    private val _quotesCount
//        get() = chuckNorrisQuoteRepository.countAll()

    val quotes = _quotes
//    val quotesCount = _quotesCount

    fun insertNewQuote() {
        viewModelScope.launch(Dispatchers.IO) {
            chuckNorrisQuoteRepository.fetchData()
        }
    }

    fun deleteAllQuote() {
        viewModelScope.launch(Dispatchers.IO) {
            chuckNorrisQuoteRepository.deleteAll()
        }
    }
}