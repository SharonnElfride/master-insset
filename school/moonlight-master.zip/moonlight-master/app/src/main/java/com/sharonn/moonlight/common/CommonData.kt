package com.sharonn.moonlight.common

class CommonData {
    companion object {
        val androidVersionNames = listOf(
            "Early Days",
            "Cupcake",
            "Donut",
            "Eclair",
            "Froyo",
            "Gingerbread",
            "Honeycomb",
            "Ice Cream Sandwich",
            "Jelly Bean",
            "KitKat",
            "Lollipop",
            "Marshmallow",
            "Nougat",
            "Oreo",
            "Pie",
            "10",
            "11",
            "12",
            "13",
            "14",
        )

        val publisherNames = listOf(
            "Mark",
            "Courtney",
            "Brooklynn",
            "Shyla",
            "Deacon",
            "Atticus",
            "Chanel",
            "Misael",
            "Nicholas",
            "Alisha",
            "Fletcher",
            "Reina",
            "Maru"
        )

        val publisherSurnames = listOf(
            "Bryan",
            "Long",
            "Chase",
            "Ball",
            "Hurley",
            "Wang",
            "Lopez",
            "Lee",
            "Elliott",
            "Song",
            "Lowery",
            "Kim",
            "Hendricks"
        )

        val funnyImagesLinks = listOf(
            "https://api.memegen.link/images/ds/small_file/high_quality.png",
            "https://api.memegen.link/images/gru/Learn_how_to_make_memes./Make_a_meme./No_one_likes_it./No_one_likes_it..png?watermark=memecomplete.com&token=gvdd2uupo6gb8xraaswq",
            "https://api.memegen.link/images/afraid/i_don't_know_what_this_meme_is_for/and_at_this_point_i'm_too_afraid_to_ask.png",
            "https://api.memegen.link/images/agnes/_/i_have_read_and_agree_to_the_terms_and_conditions.png",
            "https://api.memegen.link/images/away/life.../finds_a_way.png",
            "https://api.memegen.link/images/badchoice/milk/was_a_bad_choice.png",
            "https://api.memegen.link/images/bender/i'm_going_to_build_my_own_theme_park/with_blackjack_and_hookers.png",
            "https://api.memegen.link/images/bs/what_a_surprise.../you_caught_me_again.png",
            "https://api.memegen.link/images/bongo/Any_sound_when_you're_trying_to_sleep/Max_volume_alarm_when_you_have_to_wake_up.gif",
            "https://api.memegen.link/images/box/_/What's_in_the_box!~q.gif",
        )

        val distributionYear = (2008..2023).toList()
    }
}