package com.sharonn.moonlight.ui.screen

import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.text.HtmlCompat
import com.sharonn.moonlight.R


@Composable
fun HomeScreen(
    onAndroidListButtonClick: () -> Unit,
    onExperimentalAndroidListButtonClick: () -> Unit,
    onFunnyImageListButtonClick: () -> Unit,
    onChuckNorrisQuoteButtonClick: () -> Unit,
) {
    ScreenContent(
        onAndroidListButtonClick = onAndroidListButtonClick,
        onExperimentalAndroidListButtonClick = onExperimentalAndroidListButtonClick,
        onFunnyImageListButtonClick = onFunnyImageListButtonClick,
        onChuckNorrisQuoteButtonClick = onChuckNorrisQuoteButtonClick
    )
}

@Composable
private fun ScreenContent(
    onAndroidListButtonClick: () -> Unit,
    onExperimentalAndroidListButtonClick: () -> Unit,
    onFunnyImageListButtonClick: () -> Unit,
    onChuckNorrisQuoteButtonClick: () -> Unit,
) {
    val developedBy0 = stringResource(id = R.string.developed_by)
    val developedBy = HtmlCompat.fromHtml(developedBy0, HtmlCompat.FROM_HTML_MODE_LEGACY).toString()

    val welcomeText0 = stringResource(id = R.string.welcome_text)
    val welcomeText = HtmlCompat.fromHtml(welcomeText0, HtmlCompat.FROM_HTML_MODE_LEGACY).toString()

    val androidVersions = stringResource(id = R.string.see_android_versions)
    val experimentalAndroidVersions =
        stringResource(id = R.string.see_experimental_android_versions)
    val funnyImages = stringResource(id = R.string.see_funny_images)
    val chuckNorrisQuotes = stringResource(id = R.string.see_chuck_norris_quotes)

    Column(
        modifier = Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally

    ) {

        Column(
            modifier = Modifier.padding(10.dp)
        ) {
            ElevatedCard(
                Modifier.size(width = 300.dp, height = 350.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                elevation = CardDefaults.cardElevation(
                    defaultElevation = 6.dp
                )
            ) {
                Image(
                    modifier = Modifier
                        .height(height = 150.dp)
                        .clip(shape = RoundedCornerShape(size = 12.dp)),
                    painter = painterResource(id = R.drawable.room_moonlight),
                    contentDescription = "Picture of the moon",
                    contentScale = ContentScale.Crop
                )

                Text(
                    modifier = Modifier.padding(start = 12.dp, top = 12.dp, bottom = 16.dp),
                    text = welcomeText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                )

                Text(
                    modifier = Modifier.padding(start = 12.dp, bottom = 12.dp),
                    text = "The bottom app bar is still in progress! \nBut you can click on 'About' to see the about screen!",
                    fontSize = 17.sp,
                )

                Text(
                    modifier = Modifier.padding(start = 12.dp),
                    text = developedBy,
                    fontSize = 17.sp,
                )
            }
        }

        Button(
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            content = {
                Text(
                    text = androidVersions
                )
            },
            onClick = {
                onAndroidListButtonClick()
            },
            elevation = ButtonDefaults.elevatedButtonElevation(
                defaultElevation = 6.dp
            )
        )

        Button(
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            content = {
                Text(
                    text = experimentalAndroidVersions
                )
            },
            onClick = {
                onExperimentalAndroidListButtonClick()
            },
            elevation = ButtonDefaults.elevatedButtonElevation(
                defaultElevation = 6.dp
            )
        )

        Button(
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            content = {
                Text(
                    text = funnyImages
                )
            },
            onClick = {
                onFunnyImageListButtonClick()
            },
            elevation = ButtonDefaults.elevatedButtonElevation(
                defaultElevation = 6.dp
            )
        )

        Button(
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            content = {
                Text(
                    text = chuckNorrisQuotes
                )
            },
            onClick = {
                onChuckNorrisQuoteButtonClick()
            },
            elevation = ButtonDefaults.elevatedButtonElevation(
                defaultElevation = 6.dp
            )
        )

        val context = LocalContext.current

        FilledTonalButton(onClick = {
//            context.startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS))

//            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
//            with(intent) {
//                data = Uri.fromParts("package", context.packageName, null)
//                addCategory(CATEGORY_DEFAULT)
//                addFlags(FLAG_ACTIVITY_NEW_TASK)
//                addFlags(FLAG_ACTIVITY_NO_HISTORY)
//                addFlags(FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
//            }
//
//            context.startActivity(intent)

            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            with(intent) {
                addFlags(FLAG_ACTIVITY_NEW_TASK)
            }

            //for Android 5-7
            //for Android 5-7
            intent.putExtra("app_package", context.packageName)
            intent.putExtra("app_uid", context.applicationInfo.uid)

            // for Android 8 and above
            // for Android 8 and above
            intent.putExtra("android.provider.extra.APP_PACKAGE", context.packageName)

            context.startActivity(intent)

        }) {
            Text(text = "go to settings")
        }
    }
}