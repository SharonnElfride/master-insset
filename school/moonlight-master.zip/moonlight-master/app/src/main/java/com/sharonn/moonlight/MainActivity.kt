package com.sharonn.moonlight

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.sharonn.moonlight.common.CommonFunctions.Companion.addNewItem
import com.sharonn.moonlight.common.CommonFunctions.Companion.allItemsDeletion
import com.sharonn.moonlight.ui.navigation.HomeNavHost
import com.sharonn.moonlight.ui.navigation.NavigationPath
import com.sharonn.moonlight.ui.navigation.getScreenTitle
import com.sharonn.moonlight.ui.theme.MoonLightTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            MainScreen()
        }
    }
}

// Mine
@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true)
@Composable
private fun MainScreen() {
    MoonLightTheme {
        val navController = rememberNavController()

        val navBackStackEntry by navController.currentBackStackEntryAsState()
        var currentDestination = navBackStackEntry?.destination?.route
        var canNavigateBack = false

        if (currentDestination != null) {
            canNavigateBack = (currentDestination != NavigationPath.HOME_SCREEN)
        } else {
            currentDestination = ""
        }

        val contextForToast = LocalContext.current.applicationContext

        Scaffold(
            modifier = Modifier,
            topBar = {
                MoonLightTopAppBar(
                    canNavigateBack = canNavigateBack,
                    navigate = {
                        navController.popBackStack()
                    },
                    currentDestination = currentDestination,
                    contextForToast = contextForToast
                )
            },
            bottomBar = {
                MoonLightBottomAppBar(
                    currentDestination = currentDestination,
                    contextForToast = contextForToast,
                    navController = navController
                )
            }
//            floatingActionButton = {
//                MoonLightFloatingActionButton(
//                    currentDestination = currentDestination,
//                    contextForToast = contextForToast
//                )
//            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                HomeNavHost(
                    navController = navController
                )
            }
        }

    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MoonLightTopAppBar(
    canNavigateBack: Boolean,
    navigate: () -> Unit,
    modifier: Modifier = Modifier,
    currentDestination: String,
    contextForToast: Context
) {
    val screenTitle = stringResource(id = getScreenTitle(currentDestination = currentDestination))

    CenterAlignedTopAppBar(
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        ),
        title = {
            Row(
                modifier = Modifier,
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentDestination == NavigationPath.HOME_SCREEN) {
                    Icon(
                        painter = painterResource(id = R.drawable.round_moon_and_cloud_24),
                        contentDescription = "Moon icon",
                        modifier = Modifier.padding(5.dp)
                    )
                }
                Text(
                    text = screenTitle,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        modifier = modifier,
        navigationIcon = {
            if (canNavigateBack) {
                IconButton(onClick = navigate) {
                    Icon(
                        imageVector = Icons.Rounded.ArrowBack,
                        contentDescription = "Arrow back icon"
                    )
                }
            }
        },
        actions = {
            if (currentDestination == NavigationPath.ANDROID_VERSION_LIST_SCREEN || currentDestination == NavigationPath.EXPERIMENTAL_ANDROID_VERSION_LIST_SCREEN || currentDestination == NavigationPath.CHUCK_NORRIS_QUOTE_SCREEN) {
                IconButton(onClick = {
                    if (allItemsDeletion(currentDestination = currentDestination)) {
                        Toast.makeText(
                            contextForToast,
                            R.string.deletion_success,
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(
                            contextForToast,
                            R.string.deletion_error,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }) {
                    Icon(
                        imageVector = Icons.Rounded.Delete,
                        contentDescription = "Delete/Trash bin icon"
                    )
                }
            }
        }
    )
}

@Composable
private fun MoonLightBottomAppBar(
    currentDestination: String,
    contextForToast: Context,
    navController: NavHostController
) {
    BottomAppBar(
        actions = {
            Text(text = "Work in progress (")

            IconButton(onClick = { /* do something */ }) {
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Rounded.Home, contentDescription = "Home icon")
                    Text(text = stringResource(id = R.string.home_icon_title))
                }
            }

//            IconButton(onClick = { /* do something */ }) {
            IconButton(onClick = {
                if (currentDestination != NavigationPath.ABOUT_SCREEN) {
                    navController.navigate(route = NavigationPath.ABOUT_SCREEN)
                }
            }) {
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Rounded.Face, contentDescription = "About icon")
                    Text(text = stringResource(id = R.string.about_icon_title))
                }
            }

            Text(text = ")")
        },
        contentPadding = PaddingValues(15.dp),
        floatingActionButton = {
            MoonLightFloatingActionButton(
                currentDestination = currentDestination,
                contextForToast = contextForToast
            )
        }
    )
}

@Composable
private fun MoonLightFloatingActionButton(
    currentDestination: String,
    contextForToast: Context
) {
    if (
        currentDestination == NavigationPath.ANDROID_VERSION_LIST_SCREEN ||
        currentDestination == NavigationPath.EXPERIMENTAL_ANDROID_VERSION_LIST_SCREEN ||
        currentDestination == NavigationPath.CHUCK_NORRIS_QUOTE_SCREEN
    ) {
        SmallFloatingActionButton(
            onClick = {
                if (!addNewItem(currentDestination = currentDestination)) {
                    Toast.makeText(
                        contextForToast,
                        R.string.adding_error,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
//            shape = CircleShape,
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onSurface
        ) {
            Icon(
                imageVector = Icons.Rounded.Add,
                contentDescription = "Add floating button",
                modifier = Modifier.size(50.dp)
            )
        }

//        val actionText = when (currentDestination) {
//            NavigationPath.ANDROID_VERSION_LIST_SCREEN -> {
//                val androidVersionText = stringResource(id = R.string.add_android_version_text)
//                stringResource(R.string.add_item_custom, androidVersionText)
//            }
//
//            NavigationPath.CHUCK_NORRIS_QUOTE_SCREEN -> {
//                val chuckNorrisQuoteText = stringResource(id = R.string.add_chuck_norris_quote_text)
//                stringResource(R.string.add_item_custom, chuckNorrisQuoteText)
//            }
//
//            else -> {
//                stringResource(R.string.add_item_generic)
//            }
//        }
//
//        ExtendedFloatingActionButton(
//            onClick = {
//                if (!addNewItem(currentDestination = currentDestination)) {
//                    Toast.makeText(
//                        contextForToast,
//                        R.string.adding_error,
//                        Toast.LENGTH_SHORT
//                    ).show()
//                }
//            },
//            icon = {
//                Icon(
//                    imageVector = Icons.Rounded.Add,
//                    contentDescription = "Add floating button"
//                )
//            },
//            text = { Text(text = actionText) },
//        )
    }
}
