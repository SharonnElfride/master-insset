package com.sharonn.moonlight.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sharonn.moonlight.architecture.DatabaseKeyName.Companion.CHUCK_NORRIS_TABLE_NAME
import com.sharonn.moonlight.data.model.chucknorris.ChuckNorrisEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChuckNorrisDao {
    @Query("SELECT * FROM $CHUCK_NORRIS_TABLE_NAME ORDER BY quote ASC")
    fun selectAll(): Flow<List<ChuckNorrisEntity>>

//    @Query("SELECT COUNT(*) FROM $CHUCK_NORRIS_TABLE_NAME")
//    fun countAll(): Int
//    suspend fun countAll(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(chuckNorrisEntity: ChuckNorrisEntity)

    @Query("DELETE FROM $CHUCK_NORRIS_TABLE_NAME")
    fun deleteAll()
}