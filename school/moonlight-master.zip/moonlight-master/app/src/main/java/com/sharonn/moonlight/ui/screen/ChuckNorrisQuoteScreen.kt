package com.sharonn.moonlight.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import com.sharonn.moonlight.R
import com.sharonn.moonlight.ui.viewmodel.ChuckNorrisQuoteViewModel

@Composable
fun ChuckNorrisQuoteScreen() {
    val viewModel: ChuckNorrisQuoteViewModel = viewModel()
    val list = viewModel.quotes.collectAsState(emptyList()).value

    LazyColumn(
        modifier = Modifier.padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(space = 10.dp)
    ) {
        items(count = list.size) {
            Card(
                elevation = CardDefaults.cardElevation(
                    defaultElevation = 6.dp
                ),
            ) {
                Row {
                    val painter = rememberAsyncImagePainter(
                        ImageRequest
                            .Builder(LocalContext.current)
                            .data(data = "https://images.pexels.com/photos/6897497/pexels-photo-6897497.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2")
//                            .data(data = list[it].iconUrl)
                            .build()
                    )

                    Image(
                        modifier = Modifier
                            .width(150.dp)
                            .height(150.dp)
                            .clip(shape = RoundedCornerShape(size = 12.dp))
                            .background(
                                color = MaterialTheme.colorScheme.primary.copy(
                                    alpha = 0.5f
                                )
                            ),
                        painter = painter,
                        contentDescription = "Chuck Norris Picture",
                        contentScale = ContentScale.Crop
                    )

                    Column(
                        modifier = Modifier
                            .padding(all = 10.dp)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            text = "Quote",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            textDecoration = TextDecoration.Underline
                        )

                        Text(
                            text = list[it].quote,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
//        item {
//            Button(
//                content = { Text(text = stringResource(id = R.string.add_chuck_norris_quote_button)) },
//                onClick = { viewModel.insertNewQuote() },
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = MaterialTheme.colorScheme.primaryContainer,
//                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
//                ),
//            )
//            Button(
//                content = { Text(text = stringResource(R.string.delete_all_chuck_norris_quotes_button)) },
//                onClick = { viewModel.deleteAllQuote() },
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = MaterialTheme.colorScheme.primaryContainer,
//                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
//                ),
//            )
//        }
    }
}