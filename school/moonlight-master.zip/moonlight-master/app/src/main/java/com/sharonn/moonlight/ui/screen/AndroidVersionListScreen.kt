package com.sharonn.moonlight.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sharonn.moonlight.R
import com.sharonn.moonlight.ui.model.AndroidVersionItemUI
import com.sharonn.moonlight.ui.viewmodel.AndroidVersionViewModel

@Composable
fun AndroidVersionListScreen() {
    val viewModel: AndroidVersionViewModel = viewModel()
    val list = viewModel.androidVersionList.collectAsState(emptyList()).value

    LazyColumn(
        modifier = Modifier.padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        items(count = list.size) { number ->
            when (val currentItem = list[number]) {
                is AndroidVersionItemUI.Header -> Text(
                    modifier = Modifier
                        .padding(10.dp)
                        .background(
                            color = MaterialTheme.colorScheme.secondaryContainer
                                .copy(alpha = 0.7f), shape = CircleShape
                        )
                        .padding(5.dp)
                        .fillMaxWidth(),
                    text = currentItem.title,
                    textAlign = TextAlign.Center,
                    fontSize = MaterialTheme.typography.headlineSmall.fontSize,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )

                is AndroidVersionItemUI.Item -> Text(
                    modifier = Modifier
                        .padding(5.dp)
                        .background(
                            MaterialTheme.colorScheme.secondary
                                .copy(alpha = 0.5f),
                            shape = CircleShape
                        )
                        .padding(8.dp),
                    text = "${currentItem.versionNumber} - by ${currentItem.publisher ?: "X"}",
                    textAlign = TextAlign.Center,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.onSecondary
                )

                is AndroidVersionItemUI.Footer -> {
                    val existingVersions = pluralStringResource(
                        id = R.plurals.number_of_existing_android_versions,
                        count = currentItem.amount,
                        currentItem.amount
                    )

                    Text(
                        modifier = Modifier
                            .padding(10.dp)
                            .background(
                                color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.3f),
                                shape = CircleShape
                            )
                            .padding(5.dp)
                            .width(150.dp),
                        text = existingVersions,
                        textAlign = TextAlign.Center,
                        color = Color.White
                    )
                }

                else -> {}
            }

        }

//        item {
//            Button(
//                content = {
//                    Text(text = stringResource(id = R.string.add_android_version_button))
//                },
//                onClick = {
//                    viewModel.insertAndroidVersion()
//                },
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = MaterialTheme.colorScheme.primaryContainer,
//                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
//                ),
//            )
//
//            Button(
//                content = {
//                    Text(text = stringResource(id = R.string.delete_all_android_versions_button))
//                },
//                onClick = {
//                    viewModel.deleteAllAndroidVersion()
//                },
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = MaterialTheme.colorScheme.primaryContainer,
//                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
//                ),
//            )
//        }
    }
}
