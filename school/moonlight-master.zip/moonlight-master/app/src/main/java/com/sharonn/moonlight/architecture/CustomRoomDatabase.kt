package com.sharonn.moonlight.architecture

import androidx.room.Database
import androidx.room.RoomDatabase
import com.sharonn.moonlight.data.dao.AndroidVersionDao
import com.sharonn.moonlight.data.dao.ChuckNorrisDao
import com.sharonn.moonlight.data.model.androidversion.AndroidVersionEntity
import com.sharonn.moonlight.data.model.chucknorris.ChuckNorrisEntity

@Database(
    entities = [
        // TODO add entity classes (sql table)
        AndroidVersionEntity::class,
        ChuckNorrisEntity::class,
    ],
    version = 2,
    exportSchema = false
)

// Dao => Data Access Object
abstract class CustomRoomDatabase : RoomDatabase() {
    // TODO add dao classes

    abstract fun androidVersionDao(): AndroidVersionDao
    abstract fun chuckNorrisDao(): ChuckNorrisDao
}