package com.sharonn.moonlight.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sharonn.moonlight.R
import com.sharonn.moonlight.ui.screen.AboutScreen
import com.sharonn.moonlight.ui.screen.AndroidVersionListScreen
import com.sharonn.moonlight.ui.screen.ChuckNorrisQuoteScreen
import com.sharonn.moonlight.ui.screen.ExperimentalAndroidVersionListScreen
import com.sharonn.moonlight.ui.screen.FunnyImageListScreen
import com.sharonn.moonlight.ui.screen.HomeScreen

object NavigationPath {
    const val HOME_SCREEN = "home_screen"
    const val ANDROID_VERSION_LIST_SCREEN = "android_version_list_screen"
    const val EXPERIMENTAL_ANDROID_VERSION_LIST_SCREEN = "experimental_android_version_list_screen"
    const val FUNNY_IMAGE_LIST_SCREEN = "funny_image_list_screen"
    const val CHUCK_NORRIS_QUOTE_SCREEN = "chuck_norris_quote_screen"
    const val ABOUT_SCREEN = "about_screen"
}

enum class Screens {
    HOME,
    ANDROID_VERSIONS,
    EXPERIMENTAL_ANDROID_VERSIONS,
    FUNNY_IMAGES,
    CHUCK_NORRIS_QUOTES,
    ABOUT_SCREEN
}

fun getScreenTitle(currentDestination: String): Int {
    return when (currentDestination) {
        NavigationPath.HOME_SCREEN -> R.string.app_name
        NavigationPath.ANDROID_VERSION_LIST_SCREEN -> R.string.android_version_list_screen
        NavigationPath.EXPERIMENTAL_ANDROID_VERSION_LIST_SCREEN -> R.string.android_version_list_screen
        NavigationPath.FUNNY_IMAGE_LIST_SCREEN -> R.string.funny_image_list_screen
        NavigationPath.CHUCK_NORRIS_QUOTE_SCREEN -> R.string.chuck_norris_quotes_screen
        NavigationPath.ABOUT_SCREEN -> R.string.about_screen
        else -> R.string.app_name
    }
}


fun NavGraphBuilder.addHomeScreenNavigation(
    onAndroidListButtonClick: () -> Unit,
    onExperimentalAndroidListButtonClick: () -> Unit,
    onFunnyImageListButtonClick: () -> Unit,
    onChuckNorrisQuoteButtonClick: () -> Unit,
) {
    composable(
        route = NavigationPath.HOME_SCREEN
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            HomeScreen(
                onAndroidListButtonClick = { onAndroidListButtonClick() },
                onExperimentalAndroidListButtonClick = { onExperimentalAndroidListButtonClick() },
                onFunnyImageListButtonClick = { onFunnyImageListButtonClick() },
                onChuckNorrisQuoteButtonClick = { onChuckNorrisQuoteButtonClick() }
            )
        }
    }
}

fun NavGraphBuilder.addAndroidVersionListScreenNavigation() {
    composable(
        route = NavigationPath.ANDROID_VERSION_LIST_SCREEN,
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            AndroidVersionListScreen()
        }
    }
}

fun NavGraphBuilder.addExperimentalAndroidVersionListScreenNavigation() {
    composable(
        route = NavigationPath.EXPERIMENTAL_ANDROID_VERSION_LIST_SCREEN,
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            ExperimentalAndroidVersionListScreen()
        }
    }
}

fun NavGraphBuilder.addFunnyImageListScreenNavigation() {
    composable(
        route = NavigationPath.FUNNY_IMAGE_LIST_SCREEN,
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            FunnyImageListScreen()
        }
    }
}

fun NavGraphBuilder.addChuckNorrisQuoteScreenNavigation() {
    composable(
        route = NavigationPath.CHUCK_NORRIS_QUOTE_SCREEN,
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            ChuckNorrisQuoteScreen()
        }
    }
}

fun NavGraphBuilder.addAboutScreenNavigation() {
    composable(
        route = NavigationPath.ABOUT_SCREEN,
    ) {
        Surface(
            modifier = Modifier.fillMaxSize()
        ) {
            AboutScreen()
        }
    }
}

@Composable
fun HomeNavHost(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = NavigationPath.HOME_SCREEN,
    ) {
        addHomeScreenNavigation(
            onAndroidListButtonClick = {
                navController.navigate(NavigationPath.ANDROID_VERSION_LIST_SCREEN)
            },
            onExperimentalAndroidListButtonClick = {
                navController.navigate(NavigationPath.EXPERIMENTAL_ANDROID_VERSION_LIST_SCREEN)
            },
            onFunnyImageListButtonClick = {
                navController.navigate(NavigationPath.FUNNY_IMAGE_LIST_SCREEN)
            },
            onChuckNorrisQuoteButtonClick = {
                navController.navigate(NavigationPath.CHUCK_NORRIS_QUOTE_SCREEN)
            }
        )
        addAndroidVersionListScreenNavigation()
        addExperimentalAndroidVersionListScreenNavigation()
        addFunnyImageListScreenNavigation()
        addChuckNorrisQuoteScreenNavigation()
        addAboutScreenNavigation()
    }
}
