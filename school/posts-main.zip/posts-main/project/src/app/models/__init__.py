from project.src.app.models.post import Post
from project.src.app.models.tag import Tag
