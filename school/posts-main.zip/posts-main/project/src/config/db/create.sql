CREATE DATABASE picshare_db;
CREATE DATABASE picshare_test_db;