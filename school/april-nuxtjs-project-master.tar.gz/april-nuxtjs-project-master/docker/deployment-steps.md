# Create artifact repository on gcp

gcloud artifacts repositories create nuxtjs-proj-docker-repo --repository-format=docker --location=europe-west9 --description="Nuxtjs project docker repository" --project=paas-gcp-insset-2023

> Result
Create request issued for: [nuxtjs-proj-docker-repo]
Waiting for operation [projects/paas-gcp-insset-2023/locations/europe-west9/oper
ations/10355ec0-faee-46f7-b633-52463a12f978] to complete...done.                
Created repository [nuxtjs-proj-docker-repo].


