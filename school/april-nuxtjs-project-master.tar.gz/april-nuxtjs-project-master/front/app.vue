<!--
<template>
  <div>
    <NuxtWelcome />
  </div>
</template>
-->

<!-- meetingCollectionReference -->

<script setup lang="ts">
const version = 2 + 10
</script>

<template>
  <div>
    <h1>
      Fck off! <span>Splash</span>
    </h1>
  </div>

  <div class="hello">
    Hello Nuxt {{ version }}!
  </div>
</template>

<style scoped>
.hello {
  font-family: Arial, Helvetica, sans-serif;
  /* font-size: 3rem; */
  padding: 2rem;
}
</style>

