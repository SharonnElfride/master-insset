import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { SharedPicComponent } from './shared-pic/shared-pic.component';
import { SharedPicListComponent } from './shared-pic-list/shared-pic-list.component';
import { HeaderComponent } from './header/header.component';
import {AppRoutingModule} from "./app-routing.module";
import { LandingPageComponent } from './landing-page/landing-page.component';
import { SingleSharedPicComponent } from './single-shared-pic/single-shared-pic.component';

@NgModule({
  declarations: [
    AppComponent,
    SharedPicComponent,
    SharedPicListComponent,
    HeaderComponent,
    LandingPageComponent,
    SingleSharedPicComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, //Add the router to the app
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
