import {NgModule} from "@angular/core";
import {RouterModule, Routes} from "@angular/router";
import {SharedPicListComponent} from "./shared-pic-list/shared-pic-list.component";
import {LandingPageComponent} from "./landing-page/landing-page.component";
import {SingleSharedPicComponent} from "./single-shared-pic/single-shared-pic.component";

const routes : Routes =  [
  { path : 'sharedpics/:id', component : SingleSharedPicComponent },
  { path : 'sharedpics', component : SharedPicListComponent },
  //{ path : '', component : SharedPicListComponent },
  { path : '', component : LandingPageComponent },
];

@NgModule({
  imports : [
    RouterModule.forRoot(routes) //Save the routes in the angular router
  ],
  exports : [
    RouterModule
  ],
})
export class AppRoutingModule {

}
