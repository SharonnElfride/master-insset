import { Component, OnInit, Input } from '@angular/core';
import {SharedPic} from "../models/shared-pic.models";
import {SharedPicsService} from "../services/shared-pics.service";
import {Router} from "@angular/router";
/*
  @Component or @XXX is a decorator which add some modifications on the class declared after its calling
  selector ==> corresponds to the name we should use to insert the component as a tag/marker (remember app-root, it's the same operation)
    We have to add the selector in the app.component.html file because it's the root of the project
  template ==> corresponding html file
  style ==> corresponding style (css/less/..) files
 */
@Component({
  selector: 'app-shared-pic',
  templateUrl: './shared-pic.component.html',
  styleUrls: ['./shared-pic.component.scss']
})

export class SharedPicComponent implements OnInit {
  //Decorator for adding the possibility to add a pic from the app component
  @Input() sharedPic!: SharedPic;

  constructor(private sharePicsService : SharedPicsService,
              private route : Router) { }

  //For initializing the variables -- while initializing the component
  ngOnInit() {

  }

  onSeeSharedPic() {
    this.route.navigateByUrl(`sharedpics/${this.sharedPic.id}`); //Template literal for readability
  }

}
