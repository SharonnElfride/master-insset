//Instead of using the default method with properties and blah and blah, we can do like done down below
//snaps ==> Number of snaps -- a bit like the likes in other apps
//name? : type ==> optional property
export class SharedPic {
  id! : number;
  title! : string;
  description! : string;
  creationDate! : Date;
  snaps! : number;
  imageURL! : string;
  location? : string;

  // constructor(public title : string,
  //             public description : string,
  //             public imageURL : string,
  //             public creationDate : Date,
  //             public snaps : number,
  //             public location? : string) {
  // }
}
