import {Injectable} from "@angular/core";
import {SharedPic} from "../models/shared-pic.models";

@Injectable({
  providedIn: 'root' //To save the instance to the root of the project
})
export class SharedPicsService {
  //A service doesn't have a 'ngOnInit' method, so we have to declare and initiate the property in the same line
  sharedPics: SharedPic[] = [
    {
      id : 1,
      title : "Kitty - neko neko ne~ko!",
      description : "My little cat is soooo cute!",
      imageURL : "/assets/img/cat.jpg",
      creationDate : new Date(),
      snaps : 140,
      location : "Caen"
    },

    {
      id : 2,
      title : "Drops - plouf plouf!",
      description : "Cute art with icy water drops!",
      imageURL : "/assets/img/drops.jpg",
      creationDate : new Date(),
      snaps : 0
    },

    {
      id : 3,
      title : "Meal - miam miam!",
      description : "I'm starving and I want some meat with veggies!",
      imageURL : "/assets/img/meal.jpg",
      creationDate : new Date(),
      snaps : 60
    },

    {
      id : 4,
      title : "Mountain - fffff fffff!",
      description : "Wanna climb with me ?!",
      imageURL : "/assets/img/mountain.jpg",
      creationDate : new Date(),
      snaps : 0,
      location : "The mountain"
    },
  ];

  getAllSharedPics() : SharedPic[] {
    return this.sharedPics;
  }

  getSharedPicByID(searchedPicID : number) : SharedPic {
    const targetPic = this.sharedPics.find(pic => pic.id === searchedPicID);
    if(targetPic) return targetPic
    else throw new Error("Picture not found! \n Reason: There isn't any shared pic n°" + searchedPicID);
  }

  snapOrUnsnapSharedPicByID(searchedPicID : number, action : "snap" | "unsnap") : void {
    const targetPic = this.getSharedPicByID(searchedPicID);
    (action === "snap") ? targetPic.snaps++ : targetPic.snaps--;
  }
}
