import { Component, OnInit } from '@angular/core';
import {SharedPic} from "../models/shared-pic.models";
import {SharedPicsService} from "../services/shared-pics.service";

@Component({
  selector: 'app-shared-pic-list',
  templateUrl: './shared-pic-list.component.html',
  styleUrls: ['./shared-pic-list.component.scss']
})
export class SharedPicListComponent implements OnInit {
  sharedPics! : SharedPic[]; //Array of multiple shared pics

  //Adding private spService: spService, we're injecting the current service instance to the component
  constructor(private sharePicsService : SharedPicsService) { }

  ngOnInit(): void {
    this.sharedPics = this.sharePicsService.getAllSharedPics();
  }
}
