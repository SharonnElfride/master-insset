import { Component, OnInit, Input } from '@angular/core';
import {SharedPic} from "../models/shared-pic.models";
import {SharedPicsService} from "../services/shared-pics.service";
import {ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'app-single-shared-pic',
  templateUrl: './single-shared-pic.component.html',
  styleUrls: ['./single-shared-pic.component.scss']
})

export class SingleSharedPicComponent implements OnInit {
  sharedPic!: SharedPic;
  isSnapped! : boolean;
  buttonValue! : string;

  constructor(private sharePicsService : SharedPicsService,
              private activeRoute : ActivatedRoute) { }

  ngOnInit() {
    this.isSnapped = false;
    this.buttonValue = "Oh Snap!";

    const picID : number = +this.activeRoute.snapshot.params['id'];
    this.sharedPic = this.sharePicsService.getSharedPicByID(picID);
    //To cast from string of number to number ==> with "34", +"34" = 34
  }

  onSnap() {
    if(!this.isSnapped) {
      this.sharePicsService.snapOrUnsnapSharedPicByID(this.sharedPic.id, "snap");
      this.buttonValue = "Oops, Unsnap!";
    }
    else {
      this.sharePicsService.snapOrUnsnapSharedPicByID(this.sharedPic.id, "unsnap");
      this.buttonValue = "Oh Snap!";
    }

    this.isSnapped = !this.isSnapped;
  }
}
